# SEO GEO AEO and Social Metadata — Research Draft

Exported November 12, 2026. Research window: May 11–November 11, 2026.

Extract the ZIP. Provide seo-geo-aeo/SKILL.md and its references to your agent. Includes the full research draft and five-loop review record.

Five research/refinement rounds and two synthetic scenario checks completed. This is not an installed or officially runtime-validated skill. Documentation gaps remain explicitly flagged. Historical runtime-blocker notes describe the original build; this export was subsequently created and archive contents verified. No new platform research or installation was performed during export.
