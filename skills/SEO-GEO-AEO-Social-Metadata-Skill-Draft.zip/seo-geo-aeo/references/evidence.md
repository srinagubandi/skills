# Evidence review and decisions

Research cutoff: November 11, 2026. Main publication window: May 11–November 11, 2026. Evergreen specifications are retained separately because current requirements are not necessarily newly published. Publication, update and crawl dates are not interchangeable.

This is a research-backed draft, not an installed or runtime-validated skill. The previous SEO-AEO-GEO-Skill-v1.1.0 ZIP was located, but its contents could not be extracted in this session. No merger or replacement of that package is claimed.

## Recent primary sources

| Source and date | Evidence type and scope | Decision for the skill |
| --- | --- | --- |
| [Google generative AI optimization guide](https://developers.google.com/search/docs/fundamentals/ai-optimization-guide), introduced May 15; page updated July 10, 2026 | Official Google-specific guidance | Keep SEO foundations. Do not require llms.txt, special schema or fixed chunk lengths for Google AI visibility. Do not generalize Google's rules to every engine |
| [Google documentation updates](https://developers.google.com/search/updates), reviewed November 11 | Official change log | Recheck feature retirement and support. FAQ rich results ceased May 7, just before the research window; do not sell them as a current Google benefit |
| [Google AI reporting announcement](https://developers.google.com/search/blog/2026/06/gen-ai-performance-reports), June 3 | Official product announcement | Replace old assumptions that there is no dedicated AI reporting; consult the current help page for actual dimensions and metrics |
| [Google AI report help](https://support.google.com/webmasters/answer/16984139), states global rollout August 31 | Official report specification | Measure documented impressions; preserve property/page aggregation and missing-data semantics. No invented query-level or conversion report |
| [Google social and video reporting](https://developers.google.com/search/docs/monitor-debug/analyze-social-video-content), July 29 | Official platform-property workflow | Connect social discovery to Google data without conflating it with native social reach |
| [Google video learning paths](https://developers.google.com/search/blog/2026/10/seo-learning-paths), October 6 | Official curriculum announcement | Useful technical syllabus; the newly curated playlist is not proof every included video was published in the last six months |
| [Google shared AI training control](https://developers.google.com/search/blog/2026/10/ai-training-control), October 30 | Announcement of plans | Track as an evolving control; do not present planned cross-provider support as fully deployed |
| [Bing AI visibility insights](https://blogs.bing.com/search/2026/6/New-AI-Visibility-Insights-in-Bing-Webmaster-Tools-Intents-Topics-Citation-Share-Compare/), June 16 | Official preview announcement | Include intent/topic analysis and compare periods; citation share is not traffic share |
| [Bing Topics Portfolio](https://blogs.bing.com/webmaster/2026/10/introducing-topics-portfolio-beta-in-ai-performance/), October 13 | Official beta with approximate ecosystem measures | Treat opportunity queries and topic volumes as directional and account-dependent |
| [Ahrefs schema study](https://ahrefs.com/blog/schema-ai-citations/), May 11 | Original vendor study: 1,885 pages adding JSON-LD versus 4,000 controls, across three AI surfaces | No universal schema citation-lift promise. Observational matched analysis is not a randomized trial; retain schema for appropriate documented uses |
| [What Gets Cited](https://arxiv.org/html/2605.25517v1), May 25 | Controlled two-document setup, six models, 252,000 repeated trials over constructed scenarios | Test relevance and useful factual completeness. First-citation preference in supplied context does not establish live-web discovery or a universal lift |
| [AEO versus platform growth](https://arxiv.org/abs/2606.04362), June 3 | Single-domain natural experiment using logs; abstract reviewed, full HTML unavailable | Separate platform growth from intervention. Abstract reports a conservative placebo test p=0.16, so do not describe the effect as conclusive |
| [Common Crawl llms.txt analysis](https://commoncrawl.org/blog/a-content-analysis-of-llms-txt-files-from-the-july-2026-crawl-archive), August 31 | Original content audit of 584,107 nonempty files from a seeded crawl | Adoption and contents do not establish use or effectiveness. Check for catch-all HTML, wrong MIME, empty maps, stale links and model-directed instructions |
| [What Drives AI Citations](https://arxiv.org/html/2610.15033v1), October 10 | Two US-English commercial datasets, within-site comparisons, later API replay and controlled probes | Separate retrieval from selection and brand mentions. Missing page data, client-selected questions and API/consumer differences limit generalization |
| [Fragility of AI Search](https://arxiv.org/html/2610.11932v1), October 8 | Cross-platform security study of publication and citation pathways | Validate cited claims and source provenance. Do not turn demonstrated misinformation uptake into a spam publishing strategy |
| [Ahrefs citation stability](https://ahrefs.com/blog/how-stable-are-ai-citations/), October 29 | Original vendor tracking of about 37,500 citations across five tools over 20 days | Use repeated observations and separate no-citation answers. Short windows and selected question panels limit universal rates |

## Video and course review

Video research used available publisher transcripts and written lesson material. Full audiovisual playback, every chapter and every linked study were not verified. Do not report these videos as fully watched.

| Resource | What was inspected | Adopt or challenge |
| --- | --- | --- |
| [Question Marketing citation-platform comparison](https://question.marketing/library/proof-google-chatgpt-not-reading-same-internet-2026), September 16, 16:26 | Publisher transcript and stated GEOforge sample; publisher discloses commercial partnership | Adopt engine-specific channel testing. Challenge universal statements that YouTube cannot help ChatGPT based on one monitored corpus; rare citations and zero effectiveness are different claims |
| [Question Marketing complete AEO guide](https://question.marketing/library/the-complete-guide-to-aeo-in-2026-answer-engine-optimisation-explained), upload September 4, 1:06:40 | Accessible transcript passages; page update date precedes stated upload date | Useful practical customer-question framing. Do not adopt unsupported exact-match ranking, top-third extraction or universal conversion multipliers |
| [Ahrefs AEO introduction](https://ahrefs.com/academy/aeo-course/lesson-0-1), publication date not established | Written lesson and linked video/course outline | Useful separation of strategy, execution and measurement. Its company-specific conversion example is not a client forecast; some underlying data predates the research window |
| [Ahrefs how AI search works](https://ahrefs.com/academy/aeo-course/lesson-1-1), publication date not established | Available lesson page | Use as an explainer and follow its primary references; keep retrieval behavior product-specific |
| [Google curated technical playlists](https://developers.google.com/search/blog/2026/10/seo-learning-paths), October 6 | Official description of curriculum | Add crawl, indexing, rendering and measurement to audit coverage; do not count unviewed playlist items as reviewed videos |

## Public skill review

Public skills are workflow examples, not platform policy. Do not execute remote installation commands or copy source code blindly. If later reusing code or substantial text, inspect and preserve the actual license and attribution.

| Public skill | Inspected material | Useful pattern | Excluded or qualified |
| --- | --- | --- | --- |
| [Corey Haines AI SEO](https://github.com/coreyhaines31/marketingskills/blob/main/skills/ai-seo/SKILL.md) | Actual skill body and selected source-linked instructions | Modular references; connect technical, content and distribution tasks | Fixed 40–60-word optimum, generalized percentage lifts, universal extraction claims and mandatory file recipes are not adopted |
| [Corey Haines SEO audit](https://github.com/coreyhaines31/marketingskills/blob/main/skills/seo-audit/SKILL.md) | Retrieved skill content | Raw/rendered inspection warning and separation of audit domains | Reverify named tools and current feature availability; do not inherit stale test tools |
| [SNLabat SEO GEO AEO](https://github.com/SNLabat/SEO-GEO-AEO-Skill/blob/main/SKILL.md) | Actual audit rubric and report instructions | Explicit findings and prioritization | Do not infer a penalty from a low checklist score; no blanket FAQ/HowTo/Speakable requirement; avoid environment-specific report paths |
| [Mike Zupper Google SEO skill](https://github.com/mikezupper/google-seo-skill) | Repository overview only; direct SKILL.md fetch failed | Primary-source packaging is a useful direction | Not counted as a fully inspected skill or represented as an official Google-authored skill |

## Evergreen and current operator references

These sources were reviewed as specifications or operating references, not all as recent publications.

| Area | Source | Use |
| --- | --- | --- |
| Open Graph | https://ogp.me/ | Core and optional fields |
| LinkedIn | https://www.linkedin.com/help/linkedin/answer/a521928 | Website sharing requirements, distinct from ad image specifications |
| Pinterest | https://help.pinterest.com/en/business/article/rich-pins | Article, product and recipe synchronization and overrides |
| YouTube tags | https://support.google.com/youtube/answer/146402 | Tags are a minor discovery aid compared with title, thumbnail and description |
| YouTube search | https://support.google.com/youtube/answer/16090438 | Relevance, engagement and quality context |
| TikTok | https://newsroom.tiktok.com/creator-search-insights?lang=en | Creator Search Insights purpose; 2024 background, current account availability needs checking |
| Bluesky | https://docs.bsky.app/docs/tutorials/creating-a-post | Native post records, image alt text and external embeds |
| Mastodon | https://docs.joinmastodon.org/user/profile/ | rel=me verification and fediverse creator attribution |
| Snapchat | https://help.snapchat.com/hc/en-us/articles/7012288096532-How-do-I-post-Snaps-to-Spotlight | Description, location and topics |
| Slack | https://api.slack.com/methods/chat.unfurl | Custom application unfurls, separate from website metadata |
| OpenAI | https://developers.openai.com/api/docs/bots | Independent search, training and user-action controls |
| Anthropic | https://support.claude.com/en/articles/8896518-does-anthropic-crawl-data-from-the-web-and-how-can-site-owners-block-the-crawler | Separate bot purposes |
| Perplexity | https://docs.perplexity.ai/docs/resources/perplexity-crawlers | Search/user fetch distinction and WAF identity guidance |
| Google robots | https://developers.google.com/search/docs/crawling-indexing/robots-meta-tag | Page/header directives and fetchability |
| Google canonicalization | https://developers.google.com/search/docs/crawling-indexing/consolidate-duplicate-urls | Canonical signals, language and consistency |
| Google local | https://support.google.com/business/answer/7091 | Verified business data and local relevance |
| Google products | https://developers.google.com/search/docs/appearance/structured-data/product | Product snippets versus merchant listings |
| Google video | https://developers.google.com/search/docs/appearance/video | Discovery, rendering and video indexing |
| IndexNow | https://www.indexnow.org/documentation | Change notification, not guaranteed indexing |
| Google Indexing API | https://developers.google.com/search/apis/indexing-api/v3/using-api | Restricted supported page types |

## Unresolved evidence and access

Meta sharing, Instagram help and Threads documentation returned rate limits; X's legacy card URL redirected without the specification; some TikTok help pages yielded no readable body. The platform registry therefore marks exact current limits and selected fields for live verification. Regional ecosystems are an extension checklist, not a completed country-by-country evidence review.

No actual client site, analytics property, paid research dataset or social account was audited. No live previews, browser rendering tests or code tests were run. Research does not substantiate a promised ranking, citation or conversion lift.

The installable package still needs initialization in the personal skill checkout, placement of the core and references, metadata generation, validation, and verified saving. No shell or Node execution succeeded in this session, so those steps remain blocked.
