# Social metadata and distribution reference

Distinguish four layers: website preview metadata; native publishing fields; accessibility; discovery and business measurement. Do not invent proprietary HTML tags for platforms that provide only native fields. A website Open Graph image does not replace a Reel cover, native alt text or video captions.

## Website metadata contract

For every indexable page, record final URL, canonical URL, locale, page purpose, title, description, robots directives, preview title and description, preview image URL, image width/height/MIME/bytes/alt, page type, author and dates where applicable, and applicable structured data. Render stable preview metadata in the initial HTML head. Escape attribute values, use public absolute HTTPS URLs, and prevent conflicting duplicates from plugins and templates.

Open Graph's core fields are og:title, og:type, og:image and og:url. Add og:description, og:site_name, og:locale and image descriptors where relevant. Use article properties for actual editorial pages. Locale metadata is separate from hreflang. Source: https://ogp.me/

Use the following as an engineering starting point, not as a verified universal platform specification:

- 1200 × 630 JPG/PNG link-preview master with important content away from crop edges.

- Separate square, portrait and vertical native assets.

- Measure actual bytes and dimensions. Never assume changing the filename converts the image.

- Test preview delivery without cookies, login, JavaScript or an expiring signed URL.

- Metadata text must accurately describe the destination; do not put a misleading promotion in a generic fallback.

- Match og:url to the intended canonical landing URL; keep campaign parameters in shared links without changing the canonical.

- Keep essential content out of images alone. Alt text describes the image rather than stuffing keywords.

- Store a dated requirement entry for each target surface; hard limits must come from current official documentation or the actual composer.

## Platform registry

These rows define implementation and verification tasks. A row marked verification pending is coverage, not a claim that every current field or limit has been verified.

| Platform or surface | Website layer | Native field sheet | Verification |
| --- | --- | --- | --- |
| Facebook and Messenger | Open Graph base; verify Meta-specific requirements | Post text, destination, media, accessibility fields and video captions where supported | Meta documentation fetch was rate-limited; validate using current Sharing Debugger and a draft preview |
| Instagram feed, carousel, Reels and Stories | Do not invent instagram:* site tags | Caption, actual visual content, cover, per-image alt text where supported, video captions, relevant location/product tags, profile identity and destination | Current help fetch blocked; verify account-specific fields and public-search eligibility before applying |
| Threads | Use standard preview metadata as a test baseline | Text, link, media, alt text and topic/location fields only where current composer/API supports them | Current Meta API source rate-limited; no hardcoded quotas or character limits |
| LinkedIn | Official guidance specifies og:title, og:image, og:description and og:url | Post copy, link, image descriptions, captions; article headline, cover and author; document title and accessible document | Official sharing help reviewed; test Post Inspector and actual draft. Guidance lists 5 MB max and 1200 × 627 minimum for sharing image, separate from ad specs |
| X | Conventional twitter:card, twitter:title, twitter:description, twitter:image, twitter:image:alt; optional real site/creator handles | Post text, link, attached-media alt text, video captions | Legacy documentation redirected; exact current limits and card rendering require live verification. Do not silently rename twitter:* tags to x:* |
| YouTube and Shorts | For owned watch pages, assess applicable VideoObject and video indexing separately | Title, description, thumbnail, corrected subtitles/transcript, language, chapters, playlist, disclosures; use tags sparingly | Official YouTube guidance prioritizes title/thumbnail/description over tags. Review native search terms, retention and destination conversions |
| TikTok | No invented tiktok:* HTML SEO tags | Caption, cover, spoken/on-screen topic, corrected captions, accessibility text where available, relevant tags, location and product fields | Creator Search Insights is documented by TikTok; current help body unavailable. Verify feature access and current field limits |
| Pinterest | Applicable article/product/recipe Rich Pin metadata | Pin title, description, destination URL, board context, image alt text, product/catalog data | Official Rich Pin help reviewed. Native edits can override some synced fields; verify price and stock against the site |
| Reddit | Test normal link previews; do not assume every subreddit renders the same card | Accurate title, body or destination, relevant flair, source links and disclosed affiliation | Verify subreddit rules and composer. No fabricated customers, covert endorsements or bulk reposting |
| Quora | Test destination previews where offered | Question/answer fit, credentials, cited evidence and affiliation | Account and content-format verification pending; do not treat answer count as authority |
| Bluesky | Clients can construct external embeds using URL, title, description and thumbnail | Text, language, rich-text links/mentions and image alt text | Official protocol tutorial reviewed; an API publisher must populate the external embed rather than assume a pasted URL creates one |
| Mastodon and fediverse | Preview metadata; optional fediverse:creator; rel=me for identity linkage | Text, language, media descriptions, content warnings as appropriate | Official profile documentation reviewed. Author attribution needs allowed publication domains; rel=me verification is separate |
| Snapchat Spotlight | Do not invent snapchat:* website ranking tags | Description, relevant location and topic, captions/accessibility and required AI disclosure | Official posting guidance reviewed; verify account and region eligibility |
| WhatsApp | Test public OG-based preview behavior rather than promise a card | Message or channel copy, destination and catalog/product details where used | Composer/client verification pending; do not send test messages without authorization |
| Telegram | Test preview and cache behavior | Channel/message text, destination, preview display settings | User reports reveal cache failures but do not establish a universal fix; verify in an authorized test context |
| Discord | Test URL previews; bot embeds are a separate implementation | Message text, destination and optional authorized application embeds | Official/current constraints and client behavior require verification |
| Slack and Teams | Classic link previews and app-powered unfurls are distinct | Message text, link, optional authorized app card | Slack custom unfurl API reviewed; Teams and ordinary previews require account-specific verification |
| Tumblr, Medium and Substack | Check publisher-managed share and canonical options | Title, subtitle/description, tags/topics, cover, byline and source links | Verify each editor and syndication setting; do not promise cross-platform canonical support |
| Twitch and other live-video channels | Test profile/channel preview | Stream title, category, relevant tags, language, accessibility and archive descriptions | Verify current native interface; do not substitute YouTube rules |
| Google Business Profile, Bing Places and Apple Business Connect | Entity data and canonical destinations | Real business name, categories, service areas, hours, contact, photos, services/products and actions where supported | Separate local listings from social networks; confirm verified account facts |
| Regional extensions | No assumed Open Graph parity | Evaluate WeChat, Weibo, Xiaohongshu, Douyin, LINE, Kakao/Naver, VK and Zalo only for relevant markets | Native-language official research and actual composer checks required before recommendations |

Sources for verified rows: https://www.linkedin.com/help/linkedin/answer/a521928 ; https://support.google.com/youtube/answer/146402 ; https://support.google.com/youtube/answer/16090438 ; https://newsroom.tiktok.com/creator-search-insights?lang=en ; https://help.pinterest.com/en/business/article/rich-pins ; https://docs.bsky.app/docs/tutorials/creating-a-post ; https://docs.joinmastodon.org/user/profile/ ; https://help.snapchat.com/hc/en-us/articles/7012288096532-How-do-I-post-Snaps-to-Spotlight ; https://api.slack.com/methods/chat.unfurl .

## Preview failure diagnosis

1. Resolve the exact shared URL, redirects, final response status and canonical. Compare desktop/browser and actual platform-fetch behavior where observable.

2. Inspect response HTML for tags and conflicts. Compare with rendered head.

3. Fetch the exact image URL independently; check authentication, MIME, actual dimensions, file size, redirects, CDN and firewall restrictions.

4. Check robots rules applicable to the preview fetcher, response headers and logs. A spoofed user-agent test alone does not prove the genuine crawler can access the page.

5. Recheck platform cache through its current supported debugger or inspector. Use versioned image assets when warranted; do not randomize every public page URL to evade caching.

6. Test actual crop, truncation, alt behavior and mobile layout. A third-party preview simulator is insufficient proof.

7. Record pass, fail, unknown or not applicable. Never convert an unavailable preview into a pass.

## Reusable native field record

For each platform capture account, market/language, format, objective, audience question, first-line hook, full caption/body, native title if available, destination, campaign parameters, asset IDs, cover, per-image alt text, subtitle/transcript file, chapters where supported, topics/hashtags, relevant location and product tags, disclosures, field-limit source/date, reviewer, preview evidence, publishing authorization and measurement plan.

Avoid identical cross-posts. Preserve the underlying facts while adapting the format and useful answer to each platform. Use native search and audience evidence to choose topics; treat hashtags as organization/discovery aids, not a universal ranking switch.
