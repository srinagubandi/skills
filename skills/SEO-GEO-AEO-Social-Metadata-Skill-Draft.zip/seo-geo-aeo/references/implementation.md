# Technical and vertical execution reference

## Decision pipeline

For an absent page, work through access → discovery → index eligibility → retrieval relevance → source selection → accurate answer → qualified action. Each stage needs its own evidence. An API returning a citation is not evidence of the consumer app doing so, and an HTML 200 is not proof of indexation.

Use search-engine URL inspection and webmaster reports where available. Treat site: queries as clues, not complete index inventories. Inspect sitemaps and internal links, but do not assume submitted URLs are indexed.

Google's robots documentation says page/header directives must be crawlable to be read. A robots.txt block is not a substitute for noindex. For sensitive content, use authentication rather than indexing directives as access control. Source: https://developers.google.com/search/docs/crawling-indexing/robots-meta-tag

Google canonical guidance treats redirects and rel=canonical as strong signals, not guarantees; sitemaps are weaker signals. Keep canonical targets, internal links and sitemap URLs consistent. For genuine language variants, assess same-language canonicals and reciprocal hreflang; do not canonicalize every translated page to English by default. Source: https://developers.google.com/search/docs/crawling-indexing/consolidate-duplicate-urls

IndexNow notifies participating engines of added, changed or deleted URLs; receipt is not an indexing guarantee. Google's Indexing API has a restricted JobPosting and livestream BroadcastEvent use case. Do not use it as a generic service-page indexing tool. Sources: https://www.indexnow.org/documentation ; https://developers.google.com/search/apis/indexing-api/v3/using-api

## Crawler controls

| Operator | Separate decisions | Operational check |
| --- | --- | --- |
| OpenAI | OAI-SearchBot search; GPTBot training; ChatGPT-User user actions | Read current bot documentation; verify actual responses and published identities |
| Anthropic | Claude-SearchBot search; ClaudeBot training; Claude-User user requests | Preserve independent controls; hosted browser-agent traffic is another category |
| Perplexity | PerplexityBot search; Perplexity-User user-directed fetches | Verify published ranges; documentation notes user fetches generally ignore robots.txt |
| Google | Googlebot search, Search generative AI control, Google-Extended and announced shared training controls have distinct scopes | Read current documentation and account settings; distinguish announced plans from implemented standards |
| Bing | Bing crawling and its documented index/snippet controls | Verify current guidance; do not paste outdated nocache/noarchive recipes without review |
| Other AI products | Grok, Meta AI, DeepSeek, Qwen, Kimi and regional products may expose different search integrations | Record exact product and mode. A model name or OpenRouter endpoint alone does not identify the consumer search corpus |

Sources: https://developers.openai.com/api/docs/bots ; https://support.claude.com/en/articles/8896518-does-anthropic-crawl-data-from-the-web-and-how-can-site-owners-block-the-crawler ; https://docs.perplexity.ai/docs/resources/perplexity-crawlers ; https://support.google.com/webmasters/answer/16908024 ; https://developers.google.com/search/blog/2026/10/ai-training-control .

Maintain a matrix of intended policy, robots result, verified HTTP response, WAF evidence and last check. Keep unknowns explicit. Do not enable training access merely because the business wants search visibility.

## Page and template QA

For each representative template:

- Compare source HTML with rendered DOM for canonical, robots, headings, essential text, links and JSON-LD.

- Inspect response headers for accidental X-Robots-Tag exclusions, redirect loops, soft 404s and authentication.

- Check titles for distinct meaning and honest intent; descriptions for accurate summaries. Character counts are editorial aids, not ranking pass/fail laws.

- Validate structured data against current vocabulary and the specific consumer's supported feature. Syntactically valid schema does not guarantee eligibility or display.

- Match visible prices, inventory, hours, authors and dates to schema and feeds.

- Test image loading, accessible alternatives, responsive behavior, real mobile performance and form/checkout success.

- Check orphan pages, excessive faceted combinations, duplicate routes and obsolete redirects.

- Preserve existing URLs and high-value internal links unless a migration is justified; map redirects before changing routes.

- Use staging and a reversible diff for template changes. Check a small representative set before broad rollout.

- After deployment, record live response evidence and analytics continuity. A successful build alone is not verification.

## Local services

Prioritize real service availability, locations, hours, contact methods and inquiry outcomes. Build location pages only when they add substantive local evidence: projects, staff, service details, logistics and authentic customer questions.

Audit Google Business Profile alongside relevant Bing and Apple listings. Google's local guidance identifies relevance, distance and popularity; accurate business details support matching, but no agency can promise a map position. Source: https://support.google.com/business/answer/7091

For a builder, add verifiable project details, construction methods, actual service areas, documented capabilities and clear next steps. Do not manufacture city offices or generic location variations. Evaluate local partnerships and trade citations based on customer relevance rather than directory count.

Acceptance: authoritative fact sheet matches site/listings; phone and inquiry flow work; no false locations; sampled local intent pages contain unique evidence; reporting separates maps, organic web and AI observations.

## Healthcare and dental

Use licensed reviewer input for clinical claims; preserve meaningful risk, candidacy and treatment limitations. Distinguish practice marketing from personalized medical advice. Record who reviewed material and when the review actually occurred.

Separate factual service pages, educational questions and appointment actions. Avoid claims such as guaranteed results, painless treatment or universal suitability without appropriate evidence. Use genuine credentials and authorized patient material. Do not put identifiable patient data in prompts, research fixtures or public logs.

For a dental practice, useful content may answer practical questions about appointment process, treatment options, verified financing arrangements, accessibility and aftercare resources. Add price ranges only when the practice can substantiate their scope and exclusions.

Acceptance: no invented outcomes/reviews; accurate clinician identities; factual hours and contacts; meaningful reviewer approval for clinical content; forms collect only needed information; educational content routes to appropriate professional care.

## B2B

Map the buying committee: end user, evaluator, security/procurement and budget owner. Prioritize evidence buyers need to decide: scope, integrations, implementation effort, limitations, pricing logic, documentation and case studies with explicit denominators and time periods.

Use honest comparisons with current competitor evidence and declared selection criteria. Distinguish customer-reported outcomes from controlled results. Publish meaningful proof rather than unsupported best-in-category pages.

Create a discoverability record for company, product, category and use cases; map aliases and renamed products. Seek corrections to inaccurate third-party descriptions through authorized outreach. Do not seed covert praise.

Acceptance: each major claim has evidence; comparison dates and criteria are visible; demo/contact conversion works; product documentation and commercial pages agree; success is measured in qualified pipeline as well as visibility.

## Ecommerce

Align visible product information, Product structured data, merchant feeds and social catalogs. Maintain identifiers, variants, stock, price/currency, shipping and returns from a reliable source of truth. Check out-of-stock and discontinued behavior without blanket redirects.

Google distinguishes product snippets from merchant listings; use requirements suitable to whether the page supports purchase. Source: https://developers.google.com/search/docs/appearance/structured-data/product

For marketplaces or extensive catalogs, prioritize high-value templates and feed discrepancies. Avoid copying supplier text at scale without adding useful product knowledge. Provide original images, specifications, compatibility and meaningful comparisons where justified.

Acceptance: correct selected variant and offer, consistent prices/stock, usable mobile checkout, valid canonical strategy, feed diagnostics reviewed, no fabricated reviews and no misleading sale metadata.

## Video and image discovery

Create a video because it demonstrates something useful, not merely to acquire a citation. Provide an accurate title, a representative thumbnail, edited transcript/captions and meaningful context. An owned watch page and a YouTube upload are separate indexable objects.

Google video guidance includes discovery and rendering requirements. Inspect actual video presence in rendered HTML and the relevant video indexing report. Do not apply video markup to a decorative background and promise a video result. Source: https://developers.google.com/search/docs/appearance/video

Test whether important facts survive transcript extraction, muted viewing and thumbnail cropping. Do not assert that every AI system only reads transcripts or that every system watches video; multimodal capabilities and retrieval paths differ.

## International extensions

Localize customer intent, examples, currency, terminology, support hours and policy details, not only strings. Validate hreflang, locale routing and canonical behavior. Keep region-specific prices and availability consistent with local landing pages.

For a relevant regional platform, research native-language official documentation and the actual publishing interface. Record account eligibility, content discovery, link behavior, native metadata, accessibility and measurement before recommending an integration. Do not treat US results as global evidence.

## Portability

Keep the core skill in plain Markdown with small topic references. Use generic capability requirements: web research, raw HTTP inspection, browser rendering, local file edits, tests and analytics access. Map those capabilities to the host agent at runtime rather than hardcoding tools.

ChatGPT/Codex, Claude and Manus must each report what they can actually access. OpenRouter models need an explicit search/browser tool to gather live evidence; a model call by itself is not live research. Select models based on tested task quality, budget and current availability. Do not hardcode a supposedly latest model.

Load only the needed reference module. Cache source records during a run, batch independent retrievals, and re-fetch when a version or claim changes. Preserve evidence and status between small implementation slices.
