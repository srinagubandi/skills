# Measurement and experiment reference

Use this operating design for agency projects. Defaults below are practical starting points, not statistically guaranteed sample sizes.

## Separate outcomes and denominators

| Metric | Definition | Interpretation |
| --- | --- | --- |
| Collection success | Valid completed responses / attempted runs | Keep tool errors, refusals, timeouts and unavailable features separate |
| Answer rate | Substantive answers / valid completed responses | A no-answer response is observed behavior, not a missing record |
| Brand mention rate | Responses naming the verified brand / valid completed responses | A negative mention still counts; classify sentiment and correctness separately |
| Recommendation rate | Responses positively recommending the brand for the task / valid completed responses | Define recommendation before coding; a citation alone is insufficient |
| Owned citation rate | Responses with at least one verified owned-domain citation / valid completed responses | Deduplicate within a response |
| Citation share | Owned citations / all eligible citations | Declare whether the unit is marker, unique URL or domain; do not mix units |
| Citation fidelity | Checked claims actually supported by their cited source / checked cited claims | Inspect source content rather than count link presence |
| Brand factual accuracy | Correct assessable brand facts / assessable brand facts checked | Report unknown, outdated, ambiguous and incorrect separately |
| Prompt coverage | Distinct panel prompts with observed presence / distinct panel prompts successfully tested | Do not confuse repeated runs with new prompts |
| Referral conversion | Qualified conversions / attributable human referral sessions | State source matching, bot filtering, consent and attribution limits |
| Business return | Attributable gross profit less program cost | When attribution is weak, present contribution evidence rather than causal ROI |

Always report numerator, denominator, period, engine, market and collection method. Zero citations can coexist with frequent brand mentions. A source can be cited without its business being recommended.

## Baseline design

Create a buyer-question panel from actual sales questions, support logs, site search and first-party query data where available. Supplement with interviews and carefully chosen competitor gaps. Keep a discovery panel separate from the fixed measurement panel.

A starting panel can contain 30–60 prompts across brand verification, category discovery, comparisons, objections, local needs and purchase decisions. Use at least three observation dates for exploratory diagnosis; expand based on volatility, cost and the decision being made. This is not a claim of statistical power.

Store prompt ID and version, exact prompt, intent, locale, language, user location, engine/product, model when exposed, UI/API, search mode, account/session conditions, time, response text, cited URLs, recommendation classification, factual errors and failure state. Normalize brand aliases carefully; generic words matching a brand are not automatically mentions.

Do not make prompts name the client's brand unless measuring branded intent. Keep discovery prompts neutral. Keep follow-up conversation tests separate from fresh-session tests.

Compare time periods using the same panel and collection conditions. Treat engine/model changes as possible discontinuities. Report results per engine; do not average away meaningful differences. A composite business-weighted index requires declared weights and must not be called market share.

## First-party reports

Google's current Generative AI performance report documents impressions for AI Overviews and AI Mode, dimensions such as pages, countries, dates and devices, and text versus multimodal search filters. It does not justify promising query-level prompts, AI conversion counts or an AI-only CTR in this skill. Property/page aggregation can differ, and exported unavailable values may appear as zero; retain original missing-value semantics. Source: https://support.google.com/webmasters/answer/16984139

Google also documents platform properties for Instagram, TikTok, X and YouTube. Their Google discovery data is separate from native-platform reach and engagement. Verify the actual account/property and available reports before planning exports. Source: https://developers.google.com/search/docs/monitor-debug/analyze-social-video-content

Bing's June 2026 announcement describes Intents, Topics, Citation Share and Compare in preview; citation share is observational and is not traffic share or a quality score. The October Topics Portfolio beta uses approximate aggregates and can be absent for insufficient activity. Sources: https://blogs.bing.com/search/2026/6/New-AI-Visibility-Insights-in-Bing-Webmaster-Tools-Intents-Topics-Citation-Share-Compare/ ; https://blogs.bing.com/webmaster/2026/10/introducing-topics-portfolio-beta-in-ai-performance/

For analytics, preserve existing channel rules and conversions before editing. Inspect real referral hosts and redirect behavior instead of trusting a static universal regex. Separate crawler logs from human sessions. Add self-reported discovery to forms only when useful, and distinguish it from last-click attribution.

## Experiments

Predefine hypothesis, intervention, eligible pages, control group, primary outcome, observation window, minimum meaningful effect, guardrails and stopping rule. Match pages by template, intent, prior performance, geography and seasonality where possible.

For a controlled agent-reading test, randomize source order and anonymize brand names when testing wording. Report that the experiment tests supplied-context comprehension or selection, not live discovery.

For a real website test, ship one coherent change per comparable cohort where feasible; preserve an untreated group. Record release and crawl/index timing. Do not backdate content or change published dates without substantive changes.

Estimate uncertainty at the prompt/page cluster level when observations repeat. Avoid treating 1,000 runs on ten prompts as 1,000 independent customer questions. If statistical analysis is unavailable, report descriptive counts and label causal conclusions unproven.

Investigate losses in this order: data failure; changed report availability; no-answer behavior; collection-mode change; crawler/indexing problem; site changes; competitor/engine changes; content relevance. Do not rewrite a working page because a single citation vanished.

## Acceptance examples

If 20 valid runs contain 8 brand mentions, 3 recommendations, 5 runs with owned citations, 7 unique owned citations and 40 total unique citations, report 40% mention rate, 15% recommendation rate, 25% owned citation rate and 17.5% citation share. Do not label 17.5% as traffic share.

If only 15 of 20 attempted runs complete, calculate response metrics on those 15 and report 75% collection success separately. Keep a valid answer with no citations in the response denominator; distinguish a failed request from a genuine no-answer.

## Operating cadence

Days 1–30: establish evidence, entity record, access/measurement baseline, fix verified blockers, prepare high-value content.
Days 31–60: publish authorized evidence-led assets, correct inconsistent profiles/feeds, run bounded experiments, inspect previews and data quality.
Days 61–90: compare stable cohorts and business outcomes, expand winners, retire unsupported experiments, document next priorities.
Refresh fast-changing platform requirements before implementation and whenever documentation changes. A suggested three-week review interval is an operating recommendation, not an automation created by this skill.
