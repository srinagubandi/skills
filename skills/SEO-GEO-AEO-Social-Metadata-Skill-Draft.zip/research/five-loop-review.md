# Five round review record

| Round | Research and challenge | Concrete revision | Result |
| --- | --- | --- | --- |
| 1 | Current Google/Bing rules, crawler purposes and reporting | Diagnostic pipeline; dated platform requirements | Draft built |
| 2 | Original papers, observational studies and public skill content | Evidence grades; reject generalized lift claims and fixed content recipes | Draft refined |
| 3 | Social specifications, native fields, image delivery and inaccessible documentation | Platform registry with verification states and preview diagnosis | Draft expanded; blocked specifications explicitly marked |
| 4 | Report definitions, volatility, attribution and implementation risks | Metric denominators, failure handling, experiment design, vertical playbooks and acceptance criteria | Draft refined |
| 5 | Independent dental and ecommerce scenario applications plus contradiction review | Clarify overlapping rates, title types, source-of-truth values and verification status | Scenario checks passed; runtime validation remains blocked |

## Dental scenario result

A separate agent received the core instructions and supplied facts without a diagnosis. It prioritized a verified search-bot CDN block and incorrect Saturday hours; preserved independent training restrictions; did not infer missing schema from text extraction; rejected a guaranteed 40% citation lift; and distinguished Instagram native captions from website previews.

For 20 attempted runs and 15 completed valid responses, it calculated 75% collection success, 53.3% mention rate (8/15), 20% recommendation rate (3/15), 33.3% owned citation rate (5/15), and 17.5% citation share (7/40). It noted that these overlapping outcomes cannot be added.

## Ecommerce scenario result

A second agent received metadata instructions and raw facts. It identified a generic response-HTML preview title, an expiring image returning 403 without a session, inconsistent price/stock, and incorrect French canonical/hreflang. It rejected instagram:title and provided separate acceptance criteria for raw HTML, image access, product facts, language URLs, tracking and a real LinkedIn preview.

It also correctly distinguished an unspecified JavaScript title change from a verified og:title change. This distinction was added to the core.

## Validation limits

These were two behavioral checks using draft instruction excerpts and synthetic cases. They were not executions of an installed skill, real-site audits, live social preview checks, code tests or independent replications of research datasets.

The local shell failed during sandbox initialization, and the alternative Node runtime required approval unavailable in this session. Consequently initialization, package generation, validator execution and installation remain incomplete. The draft does not claim otherwise.

## Remaining release work

1. Recover a working authorized runtime and inspect the existing skill package before replacing or merging it.

2. Initialize or resolve the intended personal skill, retain a concise SKILL.md and split these references into separate files.

3. Add the host's skill metadata and run its official validation.

4. Forward-test the actual installed package, including reference loading, not just instruction excerpts.

5. Finish blocked Meta/X and account-specific field verification; retain explicit unknowns when documentation remains unavailable.

6. Verify saving and installation before labeling the skill installed. Create a ZIP only if requested.
