import test from 'node:test';
import assert from 'node:assert/strict';
import { mkdtempSync, writeFileSync, readFileSync, rmSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { spawnSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';
import { evaluate } from './check-lighthouse.mjs';

function fixture(action) {
  const dir = mkdtempSync(join(tmpdir(), 'page-speed-test-'));
  const write = (name, data) => writeFileSync(join(dir, name), JSON.stringify(data));
  const reports = [];
  for (let i = 0; i < 6; i++) {
    const candidate = i >= 3;
    const lcp = candidate ? [2100, 2200, 9000][i - 3] : [2300, 2400, 2500][i];
    const report = {
      lighthouseVersion: '13.0.0', userAgent: 'fixture-Chrome-150',
      requestedUrl: 'https://example.com/', finalDisplayedUrl: 'https://example.com/',
      fetchTime: new Date(Date.UTC(2026, 10, 15, 0, 0, i)).toISOString(),
      configSettings: {formFactor: 'mobile', throttlingMethod: 'simulate', throttling: {rttMs: 150}},
      audits: {
        'largest-contentful-paint': {numericValue: lcp},
        'cumulative-layout-shift': {numericValue: 0.05},
        'total-blocking-time': {numericValue: 100},
      },
    };
    reports.push(report);
    write(`${i}.json`, report);
  }
  const spec = {schemaVersion: 1, minRuns: 3,
    baseline: {url: 'https://example.com/', files: ['0.json', '1.json', '2.json']},
    candidate: {url: 'https://example.com/', files: ['3.json', '4.json', '5.json']},
    budgets: {lcp_ms: {max: 2500, maxIncrease: 100}, cls: {max: 0.1, maxIncrease: 0.01}}};
  const manifest = join(dir, 'manifest.json');
  const save = () => write('manifest.json', spec);
  save();
  try { return action({dir, write, reports, spec, manifest, save}); }
  finally { rmSync(dir, {recursive: true, force: true}); }
}

test('median resists outlier while range retains it', () => fixture(({manifest}) => {
  const result = evaluate(manifest);
  assert.equal(result.status, 'pass');
  assert.equal(result.checks[0].candidate, 2200);
  assert.equal(result.groups.candidate.metrics.lcp_ms.max, 9000);
}));
test('absolute failure cannot be rescued by improving a poor baseline', () => fixture(({spec, save, manifest}) => {
  spec.budgets.lcp_ms.max = 2000; save();
  assert.equal(evaluate(manifest).status, 'fail');
}));
test('regression delta fails even under absolute cap', () => fixture(({reports, write, manifest}) => {
  for (let i = 3; i < 6; i++) {
    reports[i].audits['cumulative-layout-shift'].numericValue = 0.08; write(`${i}.json`, reports[i]);
  }
  assert.equal(evaluate(manifest).status, 'fail');
}));
test('equality at limits passes', () => fixture(({spec, save, manifest}) => {
  spec.budgets.lcp_ms = {max: 2200, maxIncrease: 0}; save();
  assert.equal(evaluate(manifest).status, 'pass');
}));
test('PSI wrapper accepted and warnings retained', () => fixture(({reports, write, manifest}) => {
  reports[3].runWarnings = ['Review fixture warning'];
  write('3.json', {lighthouseResult: reports[3]});
  assert.equal(evaluate(manifest).warnings.length, 1);
}));
test('even run counts use arithmetic middle pair', () => fixture(({spec, reports, write, save, manifest}) => {
  reports[5].fetchTime = '2026-11-15T00:01:00Z';
  reports[5].audits['largest-contentful-paint'].numericValue = 2400;
  write('extra.json', reports[5]); spec.candidate.files.push('extra.json'); save();
  assert.equal(evaluate(manifest).groups.candidate.metrics.lcp_ms.median, 2300);
}));

const badReports = [
  ['missing metric', r => { delete r.audits['largest-contentful-paint']; }],
  ['null numeric metric', r => { r.audits['largest-contentful-paint'].numericValue = null; }],
  ['negative metric', r => { r.audits['largest-contentful-paint'].numericValue = -1; }],
  ['string metric', r => { r.audits['largest-contentful-paint'].numericValue = '2200'; }],
  ['runtime error', r => { r.runtimeError = {code: 'FAILED_DOCUMENT_REQUEST'}; }],
  ['audit error', r => { r.audits['largest-contentful-paint'].scoreDisplayMode = 'error'; }],
  ['wrong URL', r => { r.requestedUrl = 'https://example.com/other'; }],
  ['redirect', r => { r.finalDisplayedUrl = 'https://example.com/login'; }],
  ['missing timestamp', r => { delete r.fetchTime; }],
  ['version drift', r => { r.lighthouseVersion = '14.0.0'; }],
  ['browser drift', r => { r.userAgent = 'fixture-Chrome-151'; }],
  ['throttle drift', r => { r.configSettings.throttling.rttMs = 200; }],
];
for (const [name, mutate] of badReports) test(`rejects ${name}`, () => fixture(({reports, write, manifest}) => {
  mutate(reports[3]); write('3.json', reports[3]);
  assert.throws(() => evaluate(manifest));
}));
test('rejects duplicate paths', () => fixture(({spec, save, manifest}) => {
  spec.candidate.files[1] = './3.json'; save(); assert.throws(() => evaluate(manifest), /duplicate/);
}));
test('rejects copied reports', () => fixture(({reports, write, manifest}) => {
  write('4.json', reports[3]); assert.throws(() => evaluate(manifest), /duplicate/);
}));
test('rejects field INP budget', () => fixture(({spec, save, manifest}) => {
  spec.budgets.inp_ms = {max: 200}; save(); assert.throws(() => evaluate(manifest), /unsupported metric/);
}));
test('rejects malformed limits, unknown keys, insufficient samples', () => fixture(({spec, save, manifest}) => {
  spec.budgets.lcp_ms.max = '2500'; save(); assert.throws(() => evaluate(manifest));
  spec.budgets.lcp_ms.max = 2500; spec.typo = true; save(); assert.throws(() => evaluate(manifest));
  delete spec.typo; spec.candidate.files.pop(); save(); assert.throws(() => evaluate(manifest));
}));
test('CLI returns distinct 0, 1, 2 exit codes and parseable output', () => fixture(({spec, save, manifest}) => {
  const script = fileURLToPath(new URL('./check-lighthouse.mjs', import.meta.url));
  let result = spawnSync(process.execPath, [script, manifest], {encoding: 'utf8'});
  assert.equal(result.status, 0); assert.equal(JSON.parse(result.stdout).status, 'pass');
  spec.budgets.lcp_ms.max = 2000; save();
  result = spawnSync(process.execPath, [script, manifest], {encoding: 'utf8'});
  assert.equal(result.status, 1); assert.equal(JSON.parse(result.stdout).status, 'fail');
  writeFileSync(manifest, '{broken');
  result = spawnSync(process.execPath, [script, manifest], {encoding: 'utf8'});
  assert.equal(result.status, 2); assert.equal(JSON.parse(result.stderr).status, 'error');
}));
test('can evaluate outside manifest working directory without modifying inputs', () => fixture(({manifest}) => {
  const before = readFileSync(manifest, 'utf8');
  evaluate(manifest);
  assert.equal(readFileSync(manifest, 'utf8'), before);
}));
