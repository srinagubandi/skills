#!/usr/bin/env node
// Offline only. Node.js 18+; no packages, network, or file writes.
import { readFileSync } from 'node:fs';
import { resolve, dirname } from 'node:path';
import { createHash } from 'node:crypto';
import { pathToFileURL } from 'node:url';

const metrics = {
  lcp_ms: 'largest-contentful-paint',
  cls: 'cumulative-layout-shift',
  tbt_ms: 'total-blocking-time',
  fcp_ms: 'first-contentful-paint',
  speed_index_ms: 'speed-index',
  total_bytes: 'total-byte-weight',
};
const fail = message => { throw new Error(message); };
const object = value => value !== null && typeof value === 'object' && !Array.isArray(value);
function keys(value, allowed, where) {
  if (!object(value)) fail(`${where}: expected object`);
  for (const key of Object.keys(value)) if (!allowed.includes(key)) fail(`${where}: unknown key ${key}`);
}
function number(value, where) {
  if (typeof value !== 'number' || !Number.isFinite(value) || value < 0) fail(`${where}: expected finite nonnegative number`);
  return value;
}
function canonical(value) {
  if (Array.isArray(value)) return value.map(canonical);
  if (object(value)) return Object.fromEntries(Object.keys(value).sort().map(key => [key, canonical(value[key])]));
  return value;
}
function median(values) {
  const v = [...values].sort((a, b) => a - b);
  const mid = Math.floor(v.length / 2);
  return v.length % 2 ? v[mid] : (v[mid - 1] + v[mid]) / 2;
}
function url(value, where) {
  if (typeof value !== 'string') fail(`${where}: expected absolute HTTP(S) URL`);
  let parsed;
  try { parsed = new URL(value); } catch { fail(`${where}: invalid URL`); }
  if (!['https:', 'http:'].includes(parsed.protocol) || parsed.username || parsed.password) fail(`${where}: expected HTTP(S) URL without credentials`);
  return parsed.href;
}
function json(path) {
  try { return JSON.parse(readFileSync(path, 'utf8').replace(/^\uFEFF/, '')); }
  catch (error) { fail(`${path}: ${error.message}`); }
}

export function evaluate(manifestPath) {
  const file = resolve(manifestPath);
  const spec = json(file);
  keys(spec, ['schemaVersion', 'minRuns', 'baseline', 'candidate', 'budgets'], 'manifest');
  if (spec.schemaVersion !== 1) fail('schemaVersion must be 1');
  if (!Number.isInteger(spec.minRuns) || spec.minRuns < 3) fail('minRuns must be an integer >= 3');
  if (!object(spec.budgets) || !Object.keys(spec.budgets).length) fail('budgets must be a nonempty object');
  for (const [name, rule] of Object.entries(spec.budgets)) {
    if (!Object.hasOwn(metrics, name)) fail(`unsupported metric ${name}; field INP is not measured here`);
    keys(rule, ['max', 'maxIncrease'], `budgets.${name}`);
    number(rule.max, `${name}.max`);
    if (Object.hasOwn(rule, 'maxIncrease')) number(rule.maxIncrease, `${name}.maxIncrease`);
  }
  let signature;
  const seenPaths = new Set();
  const seenReports = new Set();
  const groups = {};
  const warnings = [];
  for (const group of ['baseline', 'candidate']) {
    const cfg = spec[group];
    keys(cfg, ['url', 'files'], group);
    const expectedUrl = url(cfg.url, `${group}.url`);
    if (!Array.isArray(cfg.files) || cfg.files.length < spec.minRuns) fail(`${group}: insufficient runs`);
    const values = Object.fromEntries(Object.keys(spec.budgets).map(key => [key, []]));
    for (const relative of cfg.files) {
      if (typeof relative !== 'string' || !relative.trim()) fail(`${group}: invalid report path`);
      const path = resolve(dirname(file), relative);
      const pathKey = process.platform === 'win32' ? path.toLowerCase() : path;
      if (seenPaths.has(pathKey)) fail(`duplicate report path: ${relative}`);
      seenPaths.add(pathKey);
      const data = json(path);
      const lhr = data.lighthouseResult ?? data;
      if (!object(lhr)) fail(`${relative}: missing Lighthouse result`);
      const digest = createHash('sha256').update(JSON.stringify(canonical(lhr))).digest('hex');
      if (seenReports.has(digest)) fail(`${relative}: duplicate report content`);
      seenReports.add(digest);
      if (lhr.runtimeError) fail(`${relative}: Lighthouse runtime error`);
      if (!Number.isFinite(Date.parse(lhr.fetchTime))) fail(`${relative}: missing/invalid fetchTime`);
      if (url(lhr.requestedUrl, relative) !== expectedUrl || url(lhr.finalDisplayedUrl ?? lhr.finalUrl, relative) !== expectedUrl) fail(`${relative}: unexpected URL or redirect; use the final canonical URL`);
      if (typeof lhr.lighthouseVersion !== 'string' || !lhr.lighthouseVersion) fail(`${relative}: missing Lighthouse version`);
      const settings = lhr.configSettings;
      if (!object(settings) || !['mobile', 'desktop'].includes(settings.formFactor) || typeof settings.throttlingMethod !== 'string') fail(`${relative}: missing test settings`);
      if (typeof lhr.userAgent !== 'string' || !lhr.userAgent) fail(`${relative}: missing browser userAgent`);
      const current = JSON.stringify(canonical({
        version: lhr.lighthouseVersion, settings, userAgent: lhr.userAgent,
        hostUserAgent: lhr.environment?.hostUserAgent ?? null,
        networkUserAgent: lhr.environment?.networkUserAgent ?? null,
      }));
      if (signature === undefined) signature = current;
      if (signature !== current) fail(`${relative}: incompatible Lighthouse/browser versions or configSettings`);
      if (lhr.runWarnings !== undefined && !Array.isArray(lhr.runWarnings)) fail(`${relative}: invalid runWarnings`);
      for (const warning of lhr.runWarnings ?? []) warnings.push({group, file: relative, warning});
      for (const [name, auditId] of Object.entries(metrics)) {
        if (!Object.hasOwn(values, name)) continue;
        const audit = lhr.audits?.[auditId];
        if (!audit || audit.errorMessage || ['error', 'notApplicable'].includes(audit.scoreDisplayMode)) fail(`${relative}: missing/failed audit ${auditId}`);
        values[name].push(number(audit.numericValue, `${relative}:${auditId}`));
      }
    }
    groups[group] = {
      url: expectedUrl, runs: cfg.files.length,
      metrics: Object.fromEntries(Object.entries(values).map(([name, v]) => [name, {
        median: median(v), min: Math.min(...v), max: Math.max(...v),
      }])),
    };
  }
  const checks = Object.entries(spec.budgets).map(([name, rule]) => {
    const baseline = groups.baseline.metrics[name].median;
    const candidate = groups.candidate.metrics[name].median;
    const increase = candidate - baseline;
    return {metric: name, baseline, candidate, increase, limit: rule.max,
      maxIncrease: rule.maxIncrease ?? null,
      pass: candidate <= rule.max && (rule.maxIncrease === undefined || increase <= rule.maxIncrease)};
  });
  return {schemaVersion: 1, status: checks.every(check => check.pass) ? 'pass' : 'fail',
    scope: 'Lighthouse lab budgets only; field CWV and environment comparability require separate verification',
    groups, checks, warnings};
}

if (process.argv[1] && import.meta.url === pathToFileURL(resolve(process.argv[1])).href) {
  try {
    if (process.argv.length !== 3) fail('Usage: node check-lighthouse.mjs manifest.json');
    const result = evaluate(process.argv[2]);
    process.stdout.write(`${JSON.stringify(result, null, 2)}\n`);
    process.exitCode = result.status === 'pass' ? 0 : 1;
  } catch (error) {
    process.stderr.write(`${JSON.stringify({status: 'error', message: error.message})}\n`);
    process.exitCode = 2;
  }
}
