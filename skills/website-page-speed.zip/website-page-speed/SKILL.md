---
name: website-page-speed
description: Diagnose and improve website loading, responsiveness, and visual stability using traces, Lighthouse, field data, and regression checks. Use for page speed audits, Core Web Vitals fixes, and performance budgets in existing websites.
---

# Website page speed

Improve the user's actual experience with evidence-backed, scoped changes. Work with the existing stack and the requested audit or implementation scope. A score alone is not proof of success.

## Establish evidence

1. Identify representative routes and critical journeys, production build, framework/version, hosting, audience devices/regions, and available reports or code. Discover these from the project before asking. With only a URL, provide a measured audit; with only code, label unmeasured hypotheses. Never invent measurements or claim a production improvement from a local result.
2. Read [measurement.md](references/measurement.md) for baselines, lab/field distinctions, and RUM. Record URL, release, timestamp, environment, versions, device, network/CPU conditions, cache/consent/auth state, and sample count. Test mobile and desktop separately. Save raw reports and representative traces.
3. Rank bottlenecks by affected users, measured critical-path or interaction cost, confidence, implementation cost, and regression risk. For each proposed fix identify evidence, mechanism, expected metric, and validation. Do not sum overlapping audit savings or promise exact gains.

## Diagnose and change

- For LCP, INP, CLS, media, fonts, JS, and CSS, read [rendering.md](references/rendering.md). Follow the observed critical path or slow interaction instead of applying every optimization.
- For TTFB, compression, caching, CDN, servers, and third parties, read [delivery.md](references/delivery.md).
- For hydration, rendering modes, framework components, and version-specific behavior, read [frameworks.md](references/frameworks.md). Verify installed versions and current official docs before changing APIs or cache behavior.
- Implement small coherent changes with a measurable hypothesis. Preserve content, required scripts, consent, authentication, analytics meaning, accessibility, SEO, and critical journeys. Favor removal of proven waste over speculative architecture changes. Respect existing deployment authorization; an audit does not authorize publishing.

## Verify and report

Read [verification.md](references/verification.md) for budgets, matched reruns, functional checks, staged rollout, and production verification. The optional offline helper in [budget-tool.md](references/budget-tool.md) evaluates repeated Lighthouse JSON reports; it does not measure field INP or certify Core Web Vitals.

Report the baseline and candidate by route/device, evidence of root cause, changes made, comparable results with variability, checks passed, remaining risks, and next action. Distinguish implemented, locally verified, deployed, and field-confirmed. If evidence or access is missing, say exactly what remains unverified.

## Freshness

This package was researched on **2026-11-15** using the official sources in [sources.md](references/sources.md). An access date is not a publication date. Recheck metric definitions, browser support, PSI/Lighthouse output, framework APIs, and provider configuration when applying it. Do not assume a feature is stable because it appears in experimental tooling. The five package-development loops are documented in [research-validation.md](references/research-validation.md); users do not need to repeat five loops for every task.
