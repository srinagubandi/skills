# Network, servers, caches, and third parties

## Follow the request path

Measure real navigation TTFB including redirects, DNS/connection setup, network distance, and origin work. Use waterfall and server timing/logs to separate backend latency from delivery. Investigate redirect chains, serial API calls, database/query indexes, cache misses, cold starts, region placement, and origin capacity. Profile before tuning. A rough 800 ms TTFB target is diagnostic, not a Core Web Vital or a substitute for visible content. Streaming an empty shell quickly can leave LCP unchanged. [TTFB](https://web.dev/articles/optimize-ttfb)

For geographically distributed users, benchmark CDN/edge and origin placement from representative regions. Check hit/miss and stale behavior, not just the nearest warm edge. HTTP/2 or HTTP/3 can help under suitable conditions but do not erase dependency waterfalls, payload cost, or origin latency. Avoid domain sharding as a default. Test resource hints and Early Hints only when the relevant browser/provider supports them and the resource is actually critical. [Connection guidance](https://web.dev/learn/performance/resource-hints)

Minify and negotiate compression for text assets, typically Brotli or gzip with correct `Content-Encoding` and cache variation. Avoid recompressing already compressed media. Compare transferred bytes with decoded size and CPU cost; precompress static files where useful instead of imposing high compression cost on every response. Verify actual responses rather than assuming a hosting toggle took effect. [Encoding and transfer](https://web.dev/articles/optimizing-content-efficiency-optimize-encoding-and-transfer)

## Cache by content semantics

For content-hashed public assets, long freshness with `immutable` is useful only if every content change produces a new URL. Keep old assets available for old HTML and open sessions. HTML and data need explicit freshness/revalidation rules matching product needs. `no-cache` permits storage but requires validation before reuse; `no-store` forbids storage. `private` prevents shared-cache storage. Validators can enable 304 responses. Do not apply immutable caching to mutable HTML or cache authenticated/personalized content publicly. [HTTP caching](https://developer.mozilla.org/en-US/docs/Web/HTTP/Guides/Caching)

Check provider rules, cache keys, cookies, authorization, query parameters, locale, encoding, status codes, `Vary`, and `Set-Cookie`. Explicitly test two users and logged-out state after cache warming. A broad override or ignored query can serve incorrect or private content. Use `s-maxage` and stale-while-revalidate only for responses safe for shared reuse and acceptable staleness. Provider overrides may differ from origin headers; inspect response headers and provider diagnostics. [Cloudflare origin cache control](https://developers.cloudflare.com/cache/concepts/cache-control/)

Document TTLs, invalidation/revalidation, purge scope, deploy ordering, rollback, and cache warming. Do not purge unrelated caches as a generic fix. Test fresh, stale, expired, bypassed, and failed-origin behavior as relevant. Inspect service-worker update and cache strategies separately from browser and CDN caches; verify old clients can still load required chunks. Adding a service worker solely to boost a benchmark can create freshness and lifecycle problems. [Service-worker lifecycle](https://web.dev/articles/service-worker-lifecycle)

## Third-party cost and tradeoffs

Inventory tags, owner/purpose, transfer and CPU cost, request chains, layout impact, consent category, and interaction need. Compare controlled traces with a vendor disabled to estimate attribution, but retain a realistic all-required-vendors test. Remove duplicate or valueless tags within scope. Defer noncritical work, avoid parser blocking, and check dependency order. `async` does not eliminate execution cost or guarantee good INP. [Third-party JavaScript](https://web.dev/articles/efficiently-load-third-party-javascript)

Use accessible click-to-load facades for heavy video/maps/chat when suitable; preserve names, keyboard operation, reserved geometry, focus behavior, and the intended action after activation. Test the first interaction: delaying a large widget until a click may transfer the cost into INP. Worker/proxy integrations need vendor compatibility checks; they do not automatically preserve cookies, attribution, security policy, or consent. [Facades](https://web.dev/articles/third-party-facades)

Measure consent accepted/rejected and important ad/experiment states separately. Keep required payments, fraud checks, consent enforcement, and accessibility functions working. Do not hide third parties from audits while shipping the expensive path to users. Report business tradeoffs and responsible owners for changes requiring product decisions.
