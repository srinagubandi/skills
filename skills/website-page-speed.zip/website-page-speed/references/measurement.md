# Measurement and diagnosis

## Choose the right population

Field targets are p75 LCP <=2500 ms, INP <=200 ms, and CLS <=0.1, segmented by mobile/desktop. They are user experience targets, not Lighthouse score cutoffs. FID is historical. TTFB, FCP, TBT, Speed Index, bytes, and long tasks help diagnosis but are not additional Core Web Vitals. [Web Vitals](https://web.dev/articles/vitals)

PSI separates Lighthouse lab results from CrUX's trailing 28-day field window. Record whether field results describe this URL or an origin fallback; origin success does not prove this route succeeds. No field data means unknown. PSI can assess using LCP and CLS when INP lacks sufficient data; explicitly disclose that exception rather than calling missing INP good. Query CrUX directly if a PSI API response no longer embeds field data. [PSI](https://developers.google.com/speed/docs/insights/v5/about), [API](https://developers.google.com/speed/docs/insights/v5/get-started)

CrUX covers an eligible Chrome population, not every visitor. Its page aggregation can strip query parameters and fragments; check whether that merges distinct app pages. Search Console groups similar URLs. Never attribute a group or origin statistic to a single release or route without further evidence. [CrUX methodology](https://developer.chrome.com/docs/crux/methodology), [Search Console](https://support.google.com/webmasters/answer/9205520)

## Reproducible lab baseline

Use a production build and representative routes: landing, content, listing, detail, and a critical form/cart/search flow where applicable. Include query variants and authenticated states that change cost. Capture first/cold load and repeat/warm visits separately, plus soft navigation and back/forward restoration. Record service-worker control, cache clearing method, content/experiment variant, and third-party/consent state.

Pin Lighthouse and Chrome versions, viewport/form factor, CPU/network throttling method and values, runner hardware and geography. Avoid extensions and competing workloads. Run at least three comparable repetitions; five is a useful default, with more only if variability prevents a decision. Retain all runs, median and range per metric; never select the best score. A median of each metric is a synthetic summary, not necessarily one actual run. [Lighthouse variability](https://github.com/GoogleChrome/lighthouse/blob/main/docs/variability.md)

Use DevTools Performance traces, network waterfalls, coverage, screenshots, request initiators, and CPU profiles to explain the symptom. Coverage is specific to the exercised states: unused-at-load code may support a later feature. Audit identifiers and scoring weights can change between Lighthouse versions; use raw metrics and current report diagnostics. [Scoring](https://developer.chrome.com/docs/lighthouse/performance/performance-scoring), [Performance panel](https://developer.chrome.com/docs/devtools/performance)

## RUM and interaction evidence

Use an existing RUM system or the official `web-vitals` library with the installed version's APIs. Capture metric name/value/id, release, normalized route/template, device class, navigation type, timestamp, and sampling rate; add coarse geography/network only when appropriate. Attribution builds can identify the LCP target and INP phases. Avoid full URLs with secrets, user text, or raw DOM selectors containing personal data. Keep reporting small and respect the site's consent requirements. [Library](https://github.com/GoogleChrome/web-vitals)

Treat callbacks as updates to a metric: deduplicate/update by page-view and metric id, rather than counting every callback as a separate visit. Flush using supported lifecycle-safe transport; handle page hiding and bfcache restores according to the library. Do not average p75 values across routes or days: aggregate underlying samples with the sampling design accounted for. Report counts, missing/unsupported values, time window, and confidence; no interaction does not mean INP zero. Browser APIs can miss iframe contributions visible to CrUX. Document differing population and lifecycle semantics before declaring a disagreement a bug.

Reproduce slow taps/keyboard actions throughout the session, including consent, menus, search, filters, validation, cart, and modal dismissal. A normal Lighthouse navigation cannot establish field INP; TBT is a load-time diagnostic, not its replacement. [INP guidance](https://web.dev/articles/optimize-inp)

For SPAs, keep traditional hard-navigation CWV, custom route timing, and soft-navigation series distinct. Chrome's guidance updated September 20, 2026 describes APIs from Chrome 151 and experimental soft-navigation metrics in CrUX. Check active browser/library support and data-source semantics. Soft-navigation measurement can finalize/reset metrics at route boundaries, changing the population; never mix it into an existing hard-navigation baseline without labeling the change. [Soft navigations](https://developer.chrome.com/docs/web-platform/soft-navigations)

When lab and field disagree, compare device/network/region distributions, navigation and cache types, background visibility, session length, iframe visibility, content variants, consent, and the timing of interactions. Use field evidence to select a reproducible lab scenario instead of deciding that one tool is wrong. [Lab/field differences](https://web.dev/articles/lab-and-field-data-differences)
