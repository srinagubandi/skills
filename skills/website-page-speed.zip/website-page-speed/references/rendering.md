# Rendering, assets, and interactions

## LCP: identify the element and the limiting phase

Use the actual LCP element at each relevant viewport. For a resource-backed LCP, break the trace into TTFB, discovery/load delay, resource load duration, and element render delay. Improving download size may simply expose a render blocker. Text LCP needs no image preload. [LCP](https://web.dev/articles/optimize-lcp)

Make the critical image discoverable in initial HTML when feasible. Do not lazy-load the LCP image. Apply high fetch priority to the likely critical image only when contention warrants it. Preload only a late-discovered critical resource; match responsive candidate selection, URL, type, and CORS mode to avoid duplicate fetches. Preconnect only to a few critical origins. These are scheduling tools, not instructions to prioritize every resource. [Fetch priority](https://web.dev/articles/fetch-priority), [Lazy loading](https://web.dev/articles/browser-level-image-lazy-loading)

## Images and fonts

Use appropriately sized responsive candidates (`srcset`/`sizes`, or framework equivalent), meaningful dimensions/aspect ratio, and measured compression quality. Compare AVIF/WebP with fallback formats for actual content, decoder cost, transparency, and browser support. Avoid an oversized desktop asset on mobile and excess format variants without benefit. Native lazy loading suits offscreen images and embeds; check scroll behavior and layout reservation. Keep meaningful alt text and image discoverability. [Responsive images](https://web.dev/learn/images/responsive-images), [AVIF](https://web.dev/learn/images/avif), [WebP](https://web.dev/learn/images/webp)

Reduce unused font families, weights, and character ranges without breaking languages. Use WOFF2 where supported. Select `font-display` for the product: swap preserves eventual branding but can shift layout; optional may keep a fallback. Match fallback metrics using size/ascent/descent/line-gap adjustments where needed. Preload only actually used critical faces with correct CORS and check for double downloads. Measure text LCP and CLS together. Self-hosting is a deployment choice to benchmark, not an automatic win. [Fonts](https://web.dev/articles/font-best-practices)

## INP and main-thread work

Split latency into input delay, processing duration, and presentation delay. Trace the interaction and surrounding tasks; optimize the measured phase. Reduce unnecessary JS parsing and hydration, expensive handlers, repeated renders, synchronous storage, and forced layout. Batch DOM reads/writes and reduce DOM/rendering work. Use workers for suitable CPU-heavy work, accounting for messaging/serialization; workers cannot directly manipulate the DOM. Give immediate meaningful feedback before deferring expensive nonessential work. [INP](https://web.dev/articles/optimize-inp), [Workers](https://web.dev/articles/off-main-thread)

Break long tasks with supported scheduling primitives such as `scheduler.yield()` and a tested fallback. Awaiting an already-resolved Promise only creates a microtask and may still prevent rendering. Defer only work whose ordering can change safely; preserve error paths and user feedback. Do not enqueue unlimited tasks or move heavy work into the next click. [Long tasks](https://web.dev/articles/optimize-long-tasks)

## JS and CSS

Inspect the production bundle and request graph. Remove demonstrated unused dependencies, use modular imports and tree shaking supported by the build, split by route/feature, and defer noncritical widgets. Excessive splitting can add waterfalls; prefetch only likely useful navigation within bandwidth/device constraints. `async` may execute out of order and block the main thread when ready; `defer` preserves classic-script order after parsing, while modules have their own dependency behavior. Preserve required initialization. [JavaScript loading](https://web.dev/learn/performance/optimize-resource-loading)

Remove CSS unused across representative routes, responsive states, CMS content, and interactive variants; safelist generated classes as needed. Minify and reduce blocking styles. Inline only a small demonstrated critical subset when it helps, accounting for duplicated bytes, cache loss, CSP, and flash of unstyled content. Avoid `@import` chains. Apply containment or `content-visibility` only where rendering traces show value; test find-in-page, focus, anchors, accessibility exposure, and intrinsic-size placeholders. [CSS](https://web.dev/learn/performance/optimize-resource-loading), [Content visibility](https://web.dev/articles/content-visibility)

## CLS and rendering correctness

Find the shift source, which may differ from the displaced element. Reserve dimensions for images, video, ads, embeds, and asynchronously inserted content. Test font swaps, error banners, consent, accordions, late ads, and infinite scrolling after load. CLS uses session windows; load-only lab tests can miss session-long shifts. Expected-input exclusions do not justify delayed unstable UI. Keep skeletons close to final geometry. Use compositor-friendly animations where suitable and honor reduced motion. [CLS](https://web.dev/articles/optimize-cls)
