# Budgets, correctness, and deployment verification

## Set useful gates

Build a route/device matrix with owners and a production baseline. Set user-facing field SLOs separately from repeatable lab budgets. Use p75 LCP/INP/CLS for meaningful field cohorts; use measured lab LCP/CLS/TBT and build/network budgets for early regressions. Define JS/CSS transfer bytes, decoded bundle size, image weight, and third-party request/CPU allowances when those control real costs. A universal byte cap is not appropriate for every product. [Budgets](https://web.dev/articles/performance-budgets-101)

Combine absolute targets with allowed regression versus a matched baseline. Establish tolerance from observed noise, including an absolute floor near zero rather than percentage-only CLS rules. A poor baseline still needs an improvement target. Document gate owner, severity, exceptions with expiry, environment, and required sample count. Do not automatically replace the baseline after a failure. Configure Lighthouse CI collection and assertions with pinned versions if it is already suitable for the project. [LHCI configuration](https://github.com/GoogleChrome/lighthouse-ci/blob/main/docs/configuration.md)

The included `scripts/check-lighthouse.mjs` is an optional offline, dependency-free gate for existing LHR/PSI JSON files. It uses per-metric medians, explicit absolute limits and regression deltas; see [budget-tool.md](budget-tool.md). It rejects incomplete configured metrics and incompatible report versions/settings. It cannot establish statistical significance, infer backend safety, or certify user experience from a Lighthouse score.

## Before publishing

1. Rebuild and run relevant repository checks; compare baseline/candidate on the same route, viewport, browser, throttling, state, content, and infrastructure. Preserve raw runs, medians, ranges, and traces. Investigate new bottlenecks or differences within noise. Do not keep rerunning until a favorable score appears.
2. Exercise navigation, search/filter, consent, forms/validation, sign-in, cart/payment where relevant, and third-party activation. Check console/network errors, hydration mismatch, and missing chunks. Test slow/failed requests and cache transitions where the change affects them.
3. Check keyboard focus/order, accessible names, screen-reader exposure for changed controls, zoom/reflow, reduced motion, and reserved space. Automated accessibility checks help but cannot prove accessibility. Lazy or virtualized content must remain usable and discoverable. [WAI evaluation](https://www.w3.org/WAI/test-evaluate/)
4. Preserve crawlable content, links, image alt text, metadata, canonical/robots directives, structured data, and correct status codes. Confirm server and rendered output for changed rendering/lazy-loading behavior. Good CWV helps page experience but does not guarantee ranking; a Lighthouse SEO score is not an indexing or ranking guarantee. [Search page experience](https://developers.google.com/search/docs/appearance/page-experience), [Search CWV](https://developers.google.com/search/docs/appearance/core-web-vitals)

## Production verification

Publish only within existing authorization. Prepare a reviewable change and rollback steps; use a preview or canary where available. Record release identifier/time, affected routes, cache changes, checks, owners, alert thresholds, and rollback conditions. Conditions should cover functional failures, privacy/cache mistakes, error rate, and performance regressions appropriate to the site.

After rollout, verify the actual public release and relevant regions/devices: HTML/asset versions, status/redirects, encoding, caching/age/hit-miss, resource scheduling, server timing, service-worker lifecycle, and old-session asset availability. Rerun representative journeys and matched lab checks against the deployed URL. A successful build is not deployment verification.

Monitor RUM by release and route/device, with sample counts and an observation window covering relevant traffic cycles. Compare like populations and consider experiments, traffic mix, bots, and consent bias. Choose minimum samples and uncertainty treatment for the site's traffic before asserting a change. Roll back or investigate meaningful regressions according to the prepared conditions. CrUX's rolling window mixes releases and will not immediately show a clean before/after; use release-tagged RUM for early feedback and later CrUX/Search Console for corroboration. If traffic is insufficient, report provisional lab verification and the pending field check rather than waiting indefinitely or claiming field success.

## Compact handoff

Deliver a table with route/device, baseline/candidate median and range, field p75/window/count if available, metric unit, evidence link, and verification status. Include the few highest-priority remaining actions with owner, expected mechanism, effort/risk, and the check that will establish success. Label estimates and missing evidence explicitly.
