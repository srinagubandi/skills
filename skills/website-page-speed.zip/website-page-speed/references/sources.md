# Official source ledger

All sources below were accessed **2026-11-15**. This records verification time, not a claim that every page was published in 2026. These are live documents; recheck version-sensitive details. References contain original operational synthesis with links, not copied manuals. No unverified future release schedule is assumed.

## Measurement and tooling

| Source | Decision it supports |
| --- | --- |
| [Web Vitals](https://web.dev/articles/vitals) | Metric set, thresholds, p75 and device segmentation |
| [About PSI](https://developers.google.com/speed/docs/insights/v5/about) | Lab/field distinction, origin fallback, 28-day window, missing-INP exception |
| [PSI API getting started](https://developers.google.com/speed/docs/insights/v5/get-started) | Planned removal of embedded CrUX data; use CrUX APIs for field collection |
| [PSI release notes](https://developers.google.com/speed/docs/insights/release_notes) | API version does not freeze Lighthouse version |
| [CrUX methodology](https://developer.chrome.com/docs/crux/methodology) | Eligibility, population and aggregation limitations |
| [Search Console CWV](https://support.google.com/webmasters/answer/9205520) | Grouped field reports and threshold interpretation |
| [web-vitals library](https://github.com/GoogleChrome/web-vitals) | APIs, attribution, lifecycle, callback updates and support |
| [Lab/field differences](https://web.dev/articles/lab-and-field-data-differences) | Reconcile population and session differences |
| [Lighthouse scoring](https://developer.chrome.com/docs/lighthouse/performance/performance-scoring) | Score is version-sensitive diagnostic aggregation |
| [Lighthouse variability](https://github.com/GoogleChrome/lighthouse/blob/main/docs/variability.md) | Repeated matched collection rather than best-run selection |
| [DevTools Performance](https://developer.chrome.com/docs/devtools/performance) | Trace and interaction diagnosis |
| [Soft navigations](https://developer.chrome.com/docs/web-platform/soft-navigations) | Updated September 20, 2026; Chrome 151 APIs and experimental CrUX series |

## Rendering and assets

| Source | Decision it supports |
| --- | --- |
| [Optimize LCP](https://web.dev/articles/optimize-lcp) | Element-specific phases and critical path |
| [Optimize INP](https://web.dev/articles/optimize-inp) | Interaction attribution and delay phases |
| [Optimize CLS](https://web.dev/articles/optimize-cls) | Sources, post-load shifts, geometry reservation |
| [Fetch priority](https://web.dev/articles/fetch-priority) | Distinguish scheduling from resource discovery |
| [Native image lazy loading](https://web.dev/articles/browser-level-image-lazy-loading) | Offscreen loading versus critical image loading |
| [Responsive images](https://web.dev/learn/images/responsive-images) | Appropriate source selection |
| [AVIF](https://web.dev/learn/images/avif), [WebP](https://web.dev/learn/images/webp) | Format tradeoffs and support |
| [Font best practices](https://web.dev/articles/font-best-practices) | Text rendering and font-induced shifts |
| [Optimize long tasks](https://web.dev/articles/optimize-long-tasks) | Yielding and task scheduling |
| [Web workers](https://web.dev/articles/off-main-thread) | Suitable work off the main thread |
| [Resource loading](https://web.dev/learn/performance/optimize-resource-loading) | CSS/JS blocking and script ordering |
| [Content visibility](https://web.dev/articles/content-visibility) | Render skipping with containment tradeoffs |

## Delivery and dependencies

| Source | Decision it supports |
| --- | --- |
| [Optimize TTFB](https://web.dev/articles/optimize-ttfb) | Navigation/server latency and rendering tradeoffs |
| [Resource hints](https://web.dev/learn/performance/resource-hints) | Limited, purposeful early connections/discovery |
| [Encoding and transfer](https://web.dev/articles/optimizing-content-efficiency-optimize-encoding-and-transfer) | Minification and content-appropriate compression |
| [HTTP caching](https://developer.mozilla.org/en-US/docs/Web/HTTP/Guides/Caching) | Storage, validation, freshness and shared/private semantics |
| [Cloudflare origin cache control](https://developers.cloudflare.com/cache/concepts/cache-control/) | Provider overrides; page updated June 30, 2026 |
| [Service-worker lifecycle](https://web.dev/articles/service-worker-lifecycle) | Version transitions and old-client correctness |
| [Third-party JS](https://web.dev/articles/efficiently-load-third-party-javascript) | Loading tradeoffs and execution cost |
| [Third-party facades](https://web.dev/articles/third-party-facades) | Demand-loaded embeds |

## Frameworks and verification

| Source | Decision it supports |
| --- | --- |
| [Next production checklist](https://nextjs.org/docs/app/guides/production-checklist) | Production behavior and rendering choices |
| [Next caching](https://nextjs.org/docs/app/getting-started/caching) | Updated October 6, 2026; current versus previous cache models |
| [Next Image](https://nextjs.org/docs/app/api-reference/components/image) | Next 16 priority deprecation and distinct preload/loading choices |
| [React Profiler](https://react.dev/reference/react/Profiler) | Rendering cost and profiling overhead |
| [Vue performance](https://vuejs.org/guide/best-practices/performance) | Architecture, update, bundle and list costs |
| [Angular incremental hydration](https://angular.dev/guide/incremental-hydration) | Hydration triggers, defaults and event replay |
| [Astro islands](https://docs.astro.build/en/concepts/islands/) | Isolated interactive components |
| [Performance budgets](https://web.dev/articles/performance-budgets-101) | Project-specific constraints |
| [Lighthouse CI configuration](https://github.com/GoogleChrome/lighthouse-ci/blob/main/docs/configuration.md) | Collection and assertions |
| [WAI evaluation](https://www.w3.org/WAI/test-evaluate/) | Automated plus manual accessibility verification |
| [Google page experience](https://developers.google.com/search/docs/appearance/page-experience) | Page experience without ranking guarantees |
| [Google Search CWV](https://developers.google.com/search/docs/appearance/core-web-vitals) | Search and CWV relationship |
