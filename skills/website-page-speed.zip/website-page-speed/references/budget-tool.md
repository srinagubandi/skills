# Offline Lighthouse budget helper

Use when a project needs a small gate for saved JSON reports and does not already have an adequate CI gate. Requires Node.js 18+. It reads local files only and writes JSON to stdout; no dependencies, browser launch, network, telemetry, or deployment. Lighthouse CI remains an alternative for collection and assertions.

Capture at least three independent runs per group, preferably five, using the same pinned browser/Lighthouse settings and manually matched runner/state/content conditions. Export Lighthouse JSON (LHR) or a PSI v5 response containing `lighthouseResult`. Supply one route/device/state per manifest. These are captured reports, not a list of URLs to fetch. Keep reports private if they contain sensitive URLs or content.

Create a manifest beside those reports, adapting these **illustrative lab limits** to the project:

```json
{
  "schemaVersion": 1,
  "minRuns": 3,
  "baseline": {
    "url": "https://example.com/",
    "files": ["before-1.json", "before-2.json", "before-3.json"]
  },
  "candidate": {
    "url": "https://preview.example.com/",
    "files": ["after-1.json", "after-2.json", "after-3.json"]
  },
  "budgets": {
    "lcp_ms": {"max": 2500, "maxIncrease": 100},
    "cls": {"max": 0.1, "maxIncrease": 0.01},
    "tbt_ms": {"max": 200, "maxIncrease": 30},
    "total_bytes": {"max": 1500000, "maxIncrease": 50000}
  }
}
```

Run from the skill directory, quoting paths with spaces:

```text
node scripts/check-lighthouse.mjs /absolute/path/to/manifest.json
```

Files resolve relative to the manifest, not the current directory; absolute paths also work. The expected URL must match both requested and final URL (normalize redirects before collection). Different preview origins are allowed, but equivalent content, paths, infrastructure, and response behavior must be checked manually. Do not compare a local server to a remote CDN and attribute the difference solely to code.

Supported keys: `lcp_ms`, `cls` (unitless), `tbt_ms`, `fcp_ms`, `speed_index_ms`, `total_bytes` (bytes from total-byte-weight, not decoded bundle size). Every configured metric requires a finite nonnegative numeric value in every report. Rules require `max`; optional `maxIncrease` is a nonnegative absolute delta in the same unit, not a percentage. Candidate median must satisfy both limits; equality passes. Missing values never become zero. Unknown keys, duplicate reports, runtime errors, insufficient runs, or mismatched versions/settings are errors.

Exit codes: **0** all configured lab checks pass; **1** a budget fails; **2** invalid/incomparable input. Output preserves per-metric median/min/max and all run warnings. Review warnings before relying on a pass. It compares reported configuration exactly and does not auto-coerce reports from different versions; recollect matched reports instead of deleting settings to force agreement.

The helper cannot verify actual hardware, network route, consent/cache state, report authenticity, or statistical confidence. It neither downloads Lighthouse nor infers field INP. Add independent RUM/CrUX and functional/accessibility checks described in [verification.md](verification.md). Run its deterministic fixture suite with `node --test scripts/check-lighthouse.test.mjs` after modifying it.
