# Five research and refinement loops

Performed on **2026-11-15**. Each pass used official sources, checked decision risks, and revised the package. This is a development record, not a required five-pass workflow for the skill's future users. Source links and freshness details are in [sources.md](sources.md).

| Loop | Research and challenge | Refinement applied |
| --- | --- | --- |
| 1 — Measurement | Google/web.dev CWV, PSI v5, CrUX, scoring, variability and web-vitals. Challenge: can an origin fallback, missing INP, or a high lab score establish route-level CWV success? | Separate field/lab evidence; p75/device targets; disclose origin fallback and PSI's insufficient-INP exception; preserve reports, versions, sample count, and metric ranges. |
| 2 — Rendering | LCP/INP/CLS guidance, image loading/priority, responsive formats, fonts, long tasks and containment. Challenge: can a byte reduction, blanket preload, or deferred widget worsen another metric? | Diagnose phases before fixes; avoid lazy LCP; constrain preloads; test font swaps, interaction-triggered cost, microtask scheduling, and post-load shifts. Replaced two inaccessible documentation paths with verified pages. |
| 3 — Delivery | TTFB, compression, MDN caching, provider cache behavior, service-worker lifecycle, third-party loading and facades. Challenge: can a fast cache violate freshness or user isolation? | Distinguish browser/shared/service-worker caches; add cache-key, two-user, invalidation, old-asset and rollback checks; retain realistic consent/vendor states. |
| 4 — Frameworks/mobile | Current Next, React, Vue, Angular and Astro docs. Challenge: does older optimization advice fit late-2026 APIs and a mobile first interaction? | Distinguish current/previous Next cache models and image props; use installed versions; validate hydration/replay/first use; require representative mobile/browser evidence instead of viewport emulation alone. |
| 5 — Regression/release | LHCI, budgets, WAI, Search Central, updated soft-navigation docs and PSI API caveat. Challenge: can incomplete evidence or a passed build be reported as deployed field improvement? | Add strict offline report gate, meaningful fixtures, lifecycle/RUM semantics, deployment status distinctions, production cache checks, rollback conditions, and late field confirmation. Separate Chrome soft-navigation series from traditional CWV. |

## Behavioral review

Reviewed these scenarios against the final instructions:

- **New site, no CrUX:** report field status unknown, collect lab baseline, plan RUM; do not count missing INP as zero.
- **PSI origin passes, a product route is slow:** preserve granularity and reproduce that route; origin results do not dismiss a route-specific problem.
- **Load TBT improves, first cart click stalls:** profile INP phases and delayed widget initialization; do not substitute TBT for field INP.
- **Next project with an older cache model:** inspect installed version/configuration; do not force new cache flags or deprecated image snippets.
- **Private dashboard with high TTFB:** investigate backend latency and safe private caching; do not add public shared caching.
- **Mobile lab improvement, shifted font/banner:** verify CLS, keyboard/zoom and real journeys before rollout.
- **New release with a green lab gate:** report lab verification separately; verify deployed assets and release-tagged RUM, then corroborate with later CrUX.

This is a manual scenario review, not an independent agent execution or a live-site benchmark. No target website was supplied or deployed.

## Executable and package validation

The deterministic Node fixture suite tests medians/outliers, absolute and regression failures, threshold equality, PSI wrappers, warnings, malformed/missing metrics, version/settings drift, unexpected URLs/redirects, duplicate samples, unsupported INP, and CLI exit codes. Fixtures are synthetic report structures and make no claim of live browser performance.

Validation outcome: **24 executable tests passed**, both scripts passed syntax checks, and structural checks passed for **11 package files**, **11 local reference links**, **45 official source URLs**, and a **454-word SKILL.md**. Checks covered frontmatter/name/description, source-ledger coverage, relative reference targets, and absence of unfinished scaffold markers. The bundled Python quick validator could not run because Python was unavailable in this environment; equivalent structural checks were performed with Node. ZIP verification checks every archived file against the source bytes and rejects unexpected entries or paths.
