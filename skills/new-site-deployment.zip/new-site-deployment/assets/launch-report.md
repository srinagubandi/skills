# Replacement website launch / remediation report

## Decision and scope

- Recommendation: hold / ready with accepted risks / ready / incident / remediation required / monitor.
- Named decision owner and recorded decision:
- Launch state, date/time/timezone, old origins, new preview and production origin:
- Migration type, deployed revision if known, critical journeys and scope exclusions:
- Work performed versus planned versus awaiting evidence:

## Evidence and coverage

| Source | Date | Evidence type | Unique URLs | Overlap/gaps | File/link |
|---|---|---|---|---|---|

Known old URL union count; mapped/retained/consolidated/retired/unresolved counts; new-only count. Counts must reconcile. Detail static candidates separately from verified historical URLs. State crawled versus supplied versus sampled coverage, templates/locales/devices tested, exclusions, access limits and unknowns. Do not describe a partial inventory as complete.

## Blockers and actions

| ID | Priority and impact | URL/journey | Observed versus expected | Evidence and timestamp | Fix | Owner / due | Status / acceptance |
|---|---|---|---|---|---|---|---|

Use pass / fail / unknown / not-applicable / accepted-risk. Record who accepted each risk and the reason; acceptance is not a test pass. Link the completed URL comparison, execution checklist and measurement matrix.

## Five refinement passes

| Pass | Gap identified | Concrete change made | Verification / unresolved evidence |
|---|---|---|---|
| SEO migration | | | |
| Analytics and marketing | | | |
| Technical deployment | | | |
| Accessibility/privacy/content | | | |
| Post-launch monitoring | | | |

## Execution and recovery

Link the ordered checklist with dependencies. Record prepared changes, current authorization, release and public verification timestamps, actual results, responsible owners and account submissions/handoffs. Record recovery artifact/revision, decision authority, triggers, procedure, expected recovery time, schema compatibility, split-traffic and new-write reconciliation, and when forward recovery is safer. Do not claim launch from a prepared runbook.

## Monitoring and closure

Link the completed monitoring plan with actual review dates/timezone, baseline cohorts, data freshness, site-specific thresholds, minimum samples, owners and incident response. Distinguish a proposed cadence from active alerts. Assign old-domain, TLS, redirect and backup retention ownership. State closure evidence, unresolved risks and the next review. Do not promise rankings or legal/accessibility certification.
