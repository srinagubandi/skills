# Pass 2 — Analytics and marketing

## Review and refine

A tag ID in a backup proves neither event delivery nor attribution. Build a measurement matrix from business outcomes, then test observed behavior with owner-approved synthetic data in a test destination. Use `assets/measurement-tests.csv`. For each journey record device, consent state, trigger, expected event/count/parameters, actual browser request, destination observation, backend receipt and evidence. If no account access, record request-level observations and keep destination acceptance unknown.

Inventory GA4 property/stream, GTM containers, hardcoded tags, server-side tagging, ad pixels, CMP, call tracking, forms/CRM, booking, commerce, email capture and thank-you routes. Preserve IDs unless a deliberate property change is approved. Check duplicate installations and automatic/enhanced versus manual pageviews, SPA navigation, stale preview origins, debug/internal-traffic filtering and event naming changes. An event firing on button click does not establish successful lead/order completion.

Use a personal-device debug session to inspect event names and parameters in GA4 DebugView; it requires debug mode and does not replace production reporting or backend reconciliation ([DebugView](https://support.google.com/analytics/answer/7201382)). Verify event configured as a key event where appropriate; annotate migration time and measurement changes in the handoff.

## Attribution and commerce

Test UTMs, click IDs and necessary linker parameters through actual redirect paths. Preserve allowed functional/attribution parameters without blindly forwarding secrets or arbitrary redirect targets. Test cross-domain booking/checkout navigation, return paths and downloads. Redirects can remove `_gl` and break cross-domain measurement ([cross-domain setup](https://support.google.com/analytics/answer/10071811)). Review payment-provider/self-referrals separately; a referral exclusion is not a substitute for working cross-domain identity ([unwanted referrals](https://support.google.com/analytics/answer/10327750)).

For commerce validate currency, value, item data, unique transaction IDs, refunds, server/browser deduplication and refresh/back-button behavior. A unique nonempty purchase transaction ID supports GA4 deduplication; a reused or empty ID can undercount. Never include customer-identifying data in it ([transaction IDs](https://support.google.com/analytics/answer/12313109)). Use sandbox payments or explicit purchase authorization; record cancellation/refund handling before any real test.

## Consent and marketing destinations

Test fresh visit/no choice, reject, accept selected categories, accept all, withdraw, and return visit, including regional rules established by the privacy owner. Inspect network requests, cookies/storage and server-side forwarding, not merely banner appearance. For Google consent mode inspect default and update ordering and applicable storage/user-data/personalization signals in Tag Assistant ([verification](https://support.google.com/analytics/answer/14218557)). Basic and advanced modes behave differently: cookieless requests can exist in advanced mode. Compare against the approved design; do not universally declare any denied-state request a failure or assume cookieless means legally exempt.

Check personal data leakage in URLs, page titles, data layers, analytics parameters, logs and form error messages. Preserve approved CMP choices and disclosure alignment. Consent mode is a technical mechanism, not a legal determination.

Inventory paid landing pages, ad conversion destinations, product feeds/Merchant Center links where applicable, social profile URLs, Google Business Profile, Bing Webmaster Tools ownership, email templates, QR codes, partner links and Open Graph/social previews. Map destinations; changing external accounts or contacting partners requires current authorization.

Pass exit: critical outcomes have explicit event criteria and backend success criteria; all untested consent states/destination access are visible unknowns rather than a blanket tracking pass.
