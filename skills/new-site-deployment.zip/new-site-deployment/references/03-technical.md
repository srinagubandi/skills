# Pass 3 — Technical deployment

## Readiness and cutover sequence

Capture current DNS zone and TTLs, old/new origin details, deployment revision, environment names, secrets references (never secret values), database/uploads versions and release owner. Distinguish web hosting from email and other domain services. Preserve MX, SPF, DKIM, DMARC, verification TXT, subdomains, DNSSEC/CAA and registrar access as applicable. Lowering a TTL immediately before launch does not expire old cached records; do it early when warranted. Verify A and AAAA, apex/www, old/new hosts, certificate coverage and renewal, and external resolution. Do not replace the entire zone for a web-only move.

Use an ordered runbook with owner, dependency, expected result, verification and reverse action for each change:

1. Verify a restorable release/configuration/data backup and retained old hosting. Rehearse restoration in isolation; existence of a ZIP is not proof of recoverability.
2. Decide content freeze or final sync, write ownership and handling of leads/orders/uploads during split traffic. Identify database/schema compatibility and point of no safe rollback.
3. Prepare redirects at the layer that receives old traffic; verify rule syntax/order using the actual server/router documentation. Keep staging authenticated/private. Arrange production-only removal of staging restrictions.
4. Verify release/build checks, environment, hostname, production integrations, capacity and health paths. Prepare cache/CDN invalidation and versioned assets.
5. Within existing authorization, apply the prepared release/DNS/routing changes in dependency order. Record exact times and revision IDs. Observe public results; stop if verification fails rather than repeating mutations.
6. Run production smoke checks below, then authorized sitemap/account changes and monitoring handoff. Keep old redirects and rollback resources until retirement criteria are met.

For hosting-only changes preserve existing URLs and verify both infrastructure and crawling after the switch ([Google hosting guidance](https://developers.google.com/search/docs/crawling-indexing/site-move-no-url-changes)). This sequencing is an operational recommendation, not a mandatory vendor procedure.

## Public verification

Test homepage, high-value routes, every template, a random nonexistent path, old URLs, downloads and representative locale/mobile journeys. Verify GET status and body; HEAD responses alone are insufficient. Capture HTTP/HTTPS and www/apex routing, TLS, mixed content, compression, caching headers, CDN/WAF challenges, regional availability, broken assets/fonts, client errors, deep links and refresh behavior. Check auth/session cookies, admin isolation, upload limits, error handling and private-page cache isolation. Confirm API/CORS/CSRF configuration is compatible with the new origin.

Check contact/booking/cart/auth flows, validation errors, duplicate submission prevention, third-party webhooks and email delivery to an approved test destination. A success toast is not delivery. A website move can disrupt mail if DNS is mishandled; preserve domain mail configuration even if web forms use an external provider.

Review security headers deliberately: CSP may break payment, analytics or embeds, so test/report before enforcing; verify framing policy, content type, referrer policy and cookie settings. Adopt HSTS/subdomain coverage only after assessing HTTPS readiness; preload is a separate consequential decision. Do not apply copied header bundles blindly ([OWASP headers](https://cheatsheetseries.owasp.org/cheatsheets/HTTP_Headers_Cheat_Sheet.html)).

Measure representative templates on mobile and desktop under recorded conditions. Separate lab diagnostics from real-user data; a Lighthouse score cannot establish field performance. Current good Core Web Vitals thresholds are LCP ≤2.5s, INP ≤200ms and CLS ≤0.1 at the 75th percentile, separately by device ([Web Vitals](https://web.dev/articles/vitals)). Establish baseline/regression budgets with the owner; do not use a universal score as the only release gate.

## Optional connectors

For GitHub inspect routes, redirect configuration, build/test outputs, deployment revision and environment protection. Respect required review gates; the skill does not authorize bypasses ([deployment review](https://docs.github.com/en/actions/how-tos/deploy/configure-and-manage-deployments/review-deployments)). For Railway confirm project/service/environment, public domain/port/TLS and deployment action availability from current docs ([public networking](https://docs.railway.com/networking/public-networking), [deployment actions](https://docs.railway.com/deployments/deployment-actions)). A startup healthcheck is not continuous public uptime monitoring ([healthchecks](https://docs.railway.com/deployments/healthchecks)). Apply equivalent checks on other providers without assuming the same controls.

## Rollback decision

Record triggers, decision authority, restore artifact, procedure, expected recovery time and data-reconciliation plan. Reverting code/DNS alone may lose or fork post-launch orders and leads; capture new writes before any restore. DNS caches can split traffic after reversal. Keep redirects/canonicals coherent with the chosen active release. A destructive data restore needs explicit authorization; if incompatible migrations make rollback unsafe, document forward recovery instead.

Pass exit: every consequential change has a verification and feasible recovery path, or an explicit blocker. Build success is not public verification.
