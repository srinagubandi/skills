# Pass 5 — Post-launch monitoring and closure

## Baseline and cohorts

Capture available pre-launch data (ideally 28 days plus a comparable seasonal period), deployment time/timezone, acquisition/campaign changes and measurement definitions. Where absent, say so and establish a forward baseline. Preserve old and new property data and aggregate them for domain moves; looking only at the old domain creates a misleading loss. Compare mapped page cohorts, template, locale, device, geography, branded/nonbranded queries and lead/revenue outcomes. Reconcile changed event definitions and consent rates before attributing a traffic drop to SEO.

Record freshness for GSC, analytics, logs and field performance. Delayed/incomplete reporting and small samples limit conclusions. Search traffic and index migration can fluctuate; there is no guaranteed recovery date ([Google site moves](https://developers.google.com/search/docs/crawling-indexing/site-move-with-url-changes)). Field Core Web Vitals is historical real-user data, may group URLs and can be absent without enough samples; a new lab run does not replace it ([GSC report](https://support.google.com/webmasters/answer/9205520)).

GSC exports can convert unavailable values to zero, and the newest performance data can be preliminary. Preserve those distinctions from the source view and record export limits; do not treat an exported zero as proven absence of demand ([performance data](https://support.google.com/webmasters/answer/17011364)). Samples/limited row lists are not complete URL inventories ([GSC data coverage](https://support.google.com/webmasters/answer/96568)).

## Proposed review cadence

Adapt these operating defaults to risk and traffic; they are not vendor guarantees or an active monitoring service. Fill `assets/monitoring-plan.csv` with actual dates, timezone, owner, source, baseline, trigger and response.

- Cutover and first hours: public availability/TLS, critical redirects, production indexability, assets, backend conversion delivery, error rates, deployment logs and consent behavior. Use independent public checks alongside provider health status.
- Daily in week 1: failed legacy routes, 4xx/5xx and soft 404s, canonical/robots surprises, sitemap fetches, conversion discrepancies, referral/attribution shifts and top landing pages. Inspect representative important URLs in GSC where available.
- Weekly through weeks 2–6: old/new indexed cohorts, selected canonical differences, crawl stats/server capacity, organic clicks/impressions, query/page mix, real outcomes and field performance. Extend for large or incomplete migrations.
- At roughly 30/60/90 days: reconcile outstanding mappings, content decisions, backlinks/marketing destinations and trends; decide whether to extend monitoring. Maintain redirect/domain/TLS renewal ownership beyond this period.

## Triggers and response

Set site-specific numeric thresholds and absolute minimum sample sizes with the owner; do not turn an arbitrary percentage drop into a universal rollback rule. Immediate incident examples: reproducible critical outage/TLS failure, broad accidental noindex, personal-data exposure, lost writes or repeated failure of a primary conversion. Investigate from public-path reproduction and logs, then narrow to deployment/configuration, crawling/indexing, measurement or demand changes. A working tag with a broken form and a working form with a broken tag need different fixes.

Log incident onset, detection, scope, evidence, mitigation, owner, next review and closure test. Roll back only using the data-safe plan from pass 3 when warranted; otherwise prepare a forward fix. Recheck affected cohorts after repair. Do not automatically reverse a migration based on a single day of search data or repeatedly request indexing for the entire site.

## Closure

Reconcile every known old URL disposition, all P0/P1 items and critical unknowns; record acceptance for residual risks. Demonstrate conversion delivery and measurement acceptance under intended consent states, stable availability and reviewed SEO cohorts. Retain the mapping, release/recovery record, evidence and future redirect/domain/TLS responsibilities. Report remaining monitoring obligations separately from migration closure. Never claim scheduled alerts or future checks have been established unless the requested automation was actually created and verified.
