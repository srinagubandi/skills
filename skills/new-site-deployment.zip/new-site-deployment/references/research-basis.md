# Research basis — checked 2026-11-14

Consult these primary sources for deeper checks. The skill combines their guidance with operational recommendations. Cadence, priorities, samples and release gates are recommendations to tailor, not vendor requirements. Recheck provider features and legal rules at use time. No actual website was audited or deployed in developing this skill.

## Research decisions

| Finding | Resulting refinement |
|---|---|
| Backup paths and destination availability cannot establish live old-host routing | Keep inferred URLs and public first-response/chain evidence separate |
| Canonicalization, crawling, rendering and indexing differ | Use distinct evidence fields instead of a single indexability verdict |
| Queries can carry content identity or attribution | Preserve exact distinctions; test functional and linker parameters |
| Analytics events can duplicate or diverge from actual outcomes | Verify event count and backend receipt independently |
| Consent technology does not determine legal applicability | Inspect storage/requests against a jurisdiction-specific approved design |
| Deployment healthchecks may run only at startup | Require independent public verification and monitoring ownership |
| Rollback can invalidate post-launch writes | Reconcile orders/leads and schema compatibility before recovery |
| Automated accessibility scans cover only part of the experience | Add manual journey tests and document untested scope |
| Search/field reports have freshness and coverage limits | Preserve dates and sample limits; avoid rollback on one data point |

## Primary source index

### SEO

- [Google URL-changing site moves](https://developers.google.com/search/docs/crawling-indexing/site-move-with-url-changes): migration staging, relevant redirects, retention and follow-up.
- [Hosting-only changes](https://developers.google.com/search/docs/crawling-indexing/site-move-no-url-changes): infrastructure branch.
- [Redirects](https://developers.google.com/search/docs/crawling-indexing/301-redirects): permanent versus temporary signals.
- [Canonicals](https://developers.google.com/search/docs/crawling-indexing/consolidate-duplicate-urls): declarations, signals and their limits.
- [Noindex](https://developers.google.com/search/docs/crawling-indexing/block-indexing) and [robots](https://developers.google.com/search/docs/crawling-indexing/robots/intro): indexing versus crawl management.
- [JavaScript SEO](https://developers.google.com/search/docs/crawling-indexing/javascript/javascript-seo-basics): rendering, initial directives and SPA errors.
- [Localized versions](https://developers.google.com/search/docs/specialty/international/localized-versions): reciprocal alternates.
- [Structured data](https://developers.google.com/search/docs/appearance/structured-data/intro-structured-data): markup and eligibility checks.
- [Facets](https://developers.google.com/crawling/docs/faceted-navigation) and [crawl budget](https://developers.google.com/crawling/docs/crawl-budget): conditional inventory controls.

### Measurement

- [DebugView](https://support.google.com/analytics/answer/7201382): device-scoped event debugging.
- [Cross-domain measurement](https://support.google.com/analytics/answer/10071811): linker/redirect behavior.
- [Unwanted referrals](https://support.google.com/analytics/answer/10327750): payment/referral classification.
- [Transaction IDs](https://support.google.com/analytics/answer/12313109): unique nonpersonal purchase identifiers and deduplication.
- [Consent verification](https://support.google.com/analytics/answer/14218557): default/update signals and Tag Assistant.

### Reliability

- [Web Vitals](https://web.dev/articles/vitals): field thresholds and percentile/device segmentation.
- [OWASP headers](https://cheatsheetseries.owasp.org/cheatsheets/HTTP_Headers_Cheat_Sheet.html): header purpose and deployment considerations.
- [Railway networking](https://docs.railway.com/networking/public-networking), [healthchecks](https://docs.railway.com/deployments/healthchecks), and [deployment actions](https://docs.railway.com/deployments/deployment-actions): startup checks are not continuous monitoring; rollback depends on retained deployments.
- [GitHub deployment review](https://docs.github.com/en/actions/how-tos/deploy/configure-and-manage-deployments/review-deployments): environment review controls.

### Quality, privacy and monitoring

- [WCAG quick reference](https://www.w3.org/WAI/WCAG22/quickref/) and [W3C preliminary checks](https://www.w3.org/WAI/test-evaluate/preliminary/): technical criteria and initial manual evaluation, not a complete audit.
- [ICO detailed storage/access guidance](https://ico.org.uk/for-organisations/direct-marketing-and-privacy-and-electronic-communications/guidance-on-the-use-of-storage-and-access-technologies/): UK-specific guidance finalized 29 April 2026. An older cookies summary still refers to consultation; use the detailed current guidance and assess exception conditions.
- [California regulator OOPS explainer](https://cppa.ca.gov/pdf/oops.pdf): applicability and opt-out preference signals including GPC. Recheck adopted rules; proposed 2026 amendments surfaced in research and are not treated as effective requirements here.
- [GSC performance data](https://support.google.com/webmasters/answer/17011364): preliminary data and export interpretation.
- [GSC data coverage](https://support.google.com/webmasters/answer/96568): samples and discrepancies between sources.
- [GSC Core Web Vitals](https://support.google.com/webmasters/answer/9205520): historical field data, URL groups and missing-data limits.

## Uncertainties

No universal traffic-drop percentage or fixed number of days establishes success. Baselines, sample sizes and follow-up ownership depend on the site. Legal applicability, vendor controls, backup completeness and live delivery need actual evidence. Inaccessible documentation was not used as support; a current accessible GitHub route replaced an obsolete route.
