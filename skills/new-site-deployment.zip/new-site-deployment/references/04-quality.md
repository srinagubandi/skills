# Pass 4 — Accessibility, privacy and content QA

## Accessibility

Record the required conformance target and jurisdiction with the owner. If unspecified, use WCAG 2.2 AA as a technical review target and label this assumption; do not claim legal applicability or certification. Use the [W3C quick reference](https://www.w3.org/WAI/WCAG22/quickref/) for relevant criteria. Sample every distinct template and critical multistep journey, including errors, menus, dialogs, consent and embedded third-party interfaces. Record browser, viewport and assistive technology.

Run automated checks, then manually test keyboard-only operation, visible/unobscured focus, logical order, skip navigation, menu/dialog dismissal and focus return; labels, names/roles/states, errors and status announcements; zoom/reflow, text/controls contrast, pointer targets, reduced motion, alternatives/captions and heading/landmark structure. Use a screen reader on critical flows. A scan cannot establish usability or whole-site conformance. Record untested templates and third-party limitations. Prioritize failures that stop users completing core tasks rather than merely counting alerts.

## Privacy

Establish audience, business location, data types, processors and approved consent/opt-out design before making legal conclusions. Review actual tags, storage, third-party embeds, forms, retention, data exports, privacy/cookie notices, withdrawal/opt-out controls and jurisdiction-specific signals where applicable. Ensure new tools/vendors and collection purposes match approved disclosures. Check that personal data is absent from public URLs, analytics payloads, screenshots and diagnostic logs. Restrict backup access and avoid publishing it as an asset or leaving it on the live host.

UK guidance is time-sensitive: the ICO's detailed [storage and access technologies guidance](https://ico.org.uk/for-organisations/direct-marketing-and-privacy-and-electronic-communications/guidance-on-the-use-of-storage-and-access-technologies/) was finalized in April 2026 and describes several conditional exceptions. Do not rely on an older simplified cookies page or assume every analytics technology is exempt. Verify the current exception, conditions and objection/consent implementation with the privacy owner. Treat this as jurisdiction-specific guidance, not a global rule. For applicable California businesses inspect opt-out preference signals using current regulator guidance (linked in research basis). Resolve legal interpretation with the responsible owner; continue technical evidence collection.

## Content and customer experience

Compare visible main content against old evidence and the approved content plan. Check service coverage, product availability/prices, hours, phone/address/name, staff/author attribution, legal notices, policy links, testimonials/permissions, dates and localization. Preserve valuable answers and intent while permitting deliberate revisions; do not copy obsolete claims merely to match a backup. Track removed sections and owner acceptance.

Inspect mobile/desktop layouts, overlays, navigation, search, 404 experience, empty/loading/error states, broken images, meaningful image alternatives, documents and essential downloads, browser history, print where relevant, and OG/social preview images. Test real responsive layouts instead of relying only on screenshots. Verify telephone/mail links and external navigation. Compare forms for field parity, required inputs, accessible errors, success confirmation, spam protection and recipient routing without sending real messages absent authorization.

Pass exit: critical journeys are usable in the tested conditions, known exclusions and privacy decisions have owners, and no automated tool result is presented as comprehensive compliance.
