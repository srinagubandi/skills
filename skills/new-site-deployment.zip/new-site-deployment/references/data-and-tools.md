# Data contracts and offline helpers

Python 3.10+; standard library only, no network requests, no site changes. Run from the skill folder, replacing example paths:

```text
python scripts/migration_tools.py inventory --backup old-site.zip --base https://old.example --out old.csv
python scripts/migration_tools.py compare --old old.csv --new new.csv --map mapping.csv --out preliminary.csv
python -m unittest discover -s scripts -p "test_*.py" -v
```

Inventory accepts a directory or ZIP. Use `--prefix public/` for a nested document root. Only .html/.htm are parsed; ZIPs are read without extraction, unsafe names/symlinks are rejected, and HTML bytes/file counts are bounded (see `--help`). Non-HTML assets need sitemap/crawl/export inventory. PHP/source, SQL, runtime routes, JavaScript rendering, base-tag resolution and non-UTF-8 encodings need other evidence. File paths become URL candidates, with index.html mapped to directory URLs. Review this inference; canonicals are evidence, never substituted for historical URLs. Inspect the printed JSON summary for skipped files. Zero HTML fails.

## CSV input

UTF-8 (BOM accepted), comma-delimited with headers. Adapt crawler exports; retain originals. URL keys are exact absolute HTTP(S) URLs without credentials/fragments. Do not normalize case, queries, ports, slashes or escaping. Duplicate URLs or mapping sources fail rather than silently overwrite.

Inventory minimum: `url`. Comparison fields: `status,final_url,redirect_chain,title,description,h1,canonical,robots,content_hash,schema_types,evidence,url_basis`. Blank means unknown. For live crawls `status` is the requested URL's first response, `final_url` its last destination, `redirect_chain` the full path. Never substitute final 200 for first status. An old baseline crawl is not post-launch redirect evidence: put new live tests of old URLs in the report separately.

Mapping headers: `old_url,new_url,disposition,reason`. Dispositions: `retain,redirect,consolidate,retire,unresolved`. Retire/unresolved have blank targets; retain targets the identical URL; redirect/consolidate require a distinct target. Sources must exist in old.csv. Reviewer supplies decisions; the utility does not guess them.

## Output

Compare emits old rows even without mappings and new-only rows for unreferenced new URLs. It carries comparison fields and flags missing targets, supplied non-200 target statuses, explicit noindex, metadata/hash/schema changes and canonical mismatch. Blank comparison fields produce unknown flags. Each row requires manual review; migration verification stays unknown. It cannot prove redirects, robots permission, semantic equivalence, schema validity, tracking or indexing. No readiness score is produced.

Enrich `assets/url-comparison.csv` with these observations plus live redirects, content intent review, header/robots/rendered tests, tracking/schema results, owner and fix. Hash difference measures source HTML difference, including scripts/formatting, not content quality. Noindex flags are triage for intended indexable targets; record intentional exceptions in the final report.

Formula-like output cells receive an apostrophe prefix; ordinary HTTP URL keys are unaffected. Redact sensitive exports. Helpers refuse existing output files, including input paths. Choose a fresh output path. Exit zero means processing succeeded, not migration approval. Errors go to stderr and return nonzero.
