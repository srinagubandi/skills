# Pass 1 — SEO migration

## Inventory and intent

Union old crawl, backup candidates, sitemaps, GSC landing pages, GA4 pages, backlinks, logs, ad destinations, PDFs and media. Keep each source/date and count unique exact URLs per source, overlaps and gaps. Crawls miss orphans; static backups miss runtime routes and header behavior. Prioritize revenue/leads, organic entrances/clicks, external links, locale variants and critical downloads. Without analytics use business importance, labeled as a proxy.

Every old URL needs a reviewed disposition: retain, redirect, consolidate, retire, or unresolved. Match meaning and user intent, not title similarity alone. Explain consolidations. Preserve meaningful query parameters, case, encoding and slash variants until behavior is verified. Strip fragments only for HTTP requests, retaining anchor QA separately. Never globally lowercase paths or discard queries. Inventory new-only and orphaned pages too.

## Decision rules

For moved pages prefer direct server-side permanent redirects (301 or 308) to relevant final URLs. Check first response, each Location and final GET response from the old public host with TLS intact. A destination returning 200 does not prove a redirect. Test legacy paths, query/host/protocol variants, exact-rule precedence over catchalls, loops, chains and open redirects. Do not redirect unrelated removed pages to the homepage. Intentionally removed pages without equivalents can return 404/410 with useful navigation; review business/backlink impact first. Unchanged URLs normally remain 200. Google treats permanent and temporary redirects differently ([redirect documentation](https://developers.google.com/search/docs/crawling-indexing/301-redirects)).

Check raw HTML and headers, including X-Robots-Tag and HTTP Link canonicals for PDFs, then rendered DOM where JavaScript matters. Test robots access separately from index directives. A robots block can prevent a crawler seeing noindex; robots.txt is not access control or reliable deindexing. Preserve intentional exclusions while removing staging-only blocks on intended production pages ([noindex](https://developers.google.com/search/docs/crawling-indexing/block-indexing), [robots](https://developers.google.com/search/docs/crawling-indexing/robots/intro)).

Align canonical, internal links, sitemap and redirects to intended production URLs. A declared canonical is a preference; verify Google's selected canonical separately in GSC. Do not canonicalize distinct language pages to English or use noindex to consolidate equivalents. Inspect conflicting canonicals, preview domains and pagination ([canonical guidance](https://developers.google.com/search/docs/crawling-indexing/consolidate-duplicate-urls)).

## Page comparison

For high-value pages and each distinct template/locale compare:

- Titles, descriptions, headings and visible main content; record intentional rewrites. Length or word-count change prompts review, not a ranking-loss conclusion. Missing descriptions or multiple H1s alone are not blockers.
- Business facts, CTAs, navigation/breadcrumbs, contextual links, documents, image URLs/alternatives, video/captions and discoverability.
- Structured-data types, required fields, visible-content consistency, entity identifiers, production URLs and test results. Valid JSON does not prove rich-result eligibility; do not add irrelevant schema or guarantee appearance ([structured data](https://developers.google.com/search/docs/appearance/structured-data/intro-structured-data)).
- Crawlable links, mobile parity, lazy-loaded content, rendered title/canonical behavior and real 404s on nonexistent routes. JavaScript removal of initial noindex may not be processed; inspect the original response ([JavaScript SEO](https://developers.google.com/search/docs/crawling-indexing/javascript/javascript-seo-basics)).
- Sitemap XML validity, indexes/media sitemaps where relevant, canonical 200 indexable targets, accurate lastmod, production hosts and robots sitemap references. Sitemap presence does not guarantee indexing.

For multilingual sites verify reciprocal fully qualified hreflang sets including self, valid language/region codes, relevant x-default and same-language canonical intent ([localized versions](https://developers.google.com/search/docs/specialty/international/localized-versions)). For shops/large sites examine facets, sorting, internal search, session IDs, pagination and empty results; avoid infinite URL spaces. Apply crawl-budget work when scale/change rate or actual evidence warrants it ([facets](https://developers.google.com/crawling/docs/faceted-navigation), [crawl budget](https://developers.google.com/crawling/docs/crawl-budget)).

## Migration operations

Use GSC Change of Address only for eligible domain/subdomain changes, checking current prerequisites; it is not for redesigns, paths, HTTP-to-HTTPS or www-only switches. Preserve old-domain ownership, DNS, TLS and redirect hosting. Google recommends keeping redirects generally at least a year; retain longer where users rely on them. Submit the new sitemap and review both properties as applicable ([site moves](https://developers.google.com/search/docs/crawling-indexing/site-move-with-url-changes)). Account changes require appropriate access and authorization; otherwise supply handoff steps.

Pass exit: all known old URLs have dispositions or explicit unresolved status; high-value unresolved routes block launch, and claimed redirects have public-path evidence or remain unverified.
