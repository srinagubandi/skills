"""Offline regression tests using generated fixtures; never contacts a website."""
import argparse
import csv
import io
import stat
import tempfile
import unittest
import zipfile
from contextlib import redirect_stderr, redirect_stdout
from pathlib import Path
from unittest.mock import patch
import migration_tools as m


class MigrationTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)

    def inv(self, entries, **options):
        backup = self.root / 'backup.zip'
        with zipfile.ZipFile(backup, 'w') as archive:
            for name, data in entries.items():
                archive.writestr(name, data)
        values = dict(backup=backup, base='https://old.example', prefix='',
                      max_files=100, max_bytes=10000, max_total_bytes=100000,
                      out=self.root / 'inventory.csv')
        values.update(options)
        args = argparse.Namespace(**values)
        summary = m.inventory(args)
        return summary, m.read_csv(args.out, ['url'])

    def comp(self, old, new, mappings):
        for name, fields, rows in [('old', ['url', 'title', 'status'], old),
                                  ('new', ['url', 'title', 'status', 'robots', 'canonical'], new),
                                  ('map', ['old_url', 'new_url', 'disposition', 'reason'], mappings)]:
            m.write_csv(self.root / (name + '.csv'), fields, rows)
        args = argparse.Namespace(**{k: self.root / (k + '.csv') for k in ('old', 'new', 'map', 'out')})
        summary = m.compare(args)
        return summary, m.read_csv(args.out, ['old_url'])

    def test_metadata_and_unknown_http(self):
        summary, rows = self.inv({'index.html': '<title>A &amp; B</title><h1><em>Service</em></h1><meta name="robots" content="noindex"><link rel="canonical" href="https://new.example/"><script type="application/ld+json">{"@graph":[{"@type":"Organization"}]}</script>'})
        self.assertEqual(rows[0]['url'], 'https://old.example/')
        self.assertEqual(rows[0]['title'], 'A & B')
        self.assertEqual(rows[0]['h1'], 'Service')
        self.assertEqual(rows[0]['schema_types'], 'Organization')
        self.assertEqual(rows[0]['status'], '')
        self.assertEqual(summary['html_files'], 1)

    def test_prefix_and_encoding(self):
        _, rows = self.inv({'public/About Us/index.htm': '<h1>About</h1>', 'else.html': ''}, prefix='public/')
        self.assertEqual(rows[0]['url'], 'https://old.example/About%20Us/')

    def test_unsafe_zip_paths_skipped(self):
        summary, rows = self.inv({'../bad.html': '', '/abs.html': '', 'C:/x.html': '', 'ok.html': ''})
        self.assertEqual(summary['skipped_unsafe'], 3)
        self.assertEqual(len(rows), 1)
        self.assertFalse((self.root / 'bad.html').exists())

    def test_zip_symlink_skipped(self):
        info = zipfile.ZipInfo('link.html')
        info.create_system = 3
        info.external_attr = (stat.S_IFLNK | 0o777) << 16
        summary, rows = self.inv({info: 'secret', 'ok.html': ''})
        self.assertEqual(summary['skipped_unsafe'], 1)

    def test_byte_limit_fails_without_output(self):
        with self.assertRaises(ValueError):
            self.inv({'a.html': 'x' * 100}, max_bytes=10)
        self.assertFalse((self.root / 'inventory.csv').exists())

    def test_file_limit(self):
        with self.assertRaises(ValueError):
            self.inv({'a.html': '', 'b.html': ''}, max_files=1)

    def test_total_limit(self):
        with self.assertRaises(ValueError):
            self.inv({'a.html': '123456', 'b.html': '123456'}, max_total_bytes=10)

    def test_source_only_fails(self):
        with self.assertRaisesRegex(ValueError, 'no HTML'):
            self.inv({'index.php': '<?php', 'db.sql': 'select'})

    def test_duplicate_inferred_url_fails(self):
        with self.assertRaisesRegex(ValueError, 'duplicate'):
            self.inv({'index.html': '', 'index.htm': ''})

    def test_directory_input(self):
        folder = self.root / 'pages'
        folder.mkdir()
        (folder / 'index.html').write_text('<title>Home</title>')
        args = argparse.Namespace(backup=folder, base='https://old.example', prefix='', max_files=10,
                                  max_bytes=1000, max_total_bytes=1000, out=self.root / 'dir.csv')
        self.assertEqual(m.inventory(args)['html_files'], 1)

    def test_invalid_json_is_not_valid_schema(self):
        _, rows = self.inv({'a.html': '<script type="application/ld+json">{bad}</script>'})
        self.assertEqual(rows[0]['schema_types'], 'INVALID_JSON_LD')

    def test_no_output_overwrite(self):
        path = self.root / 'saved.csv'
        path.write_text('preserve')
        with self.assertRaises(FileExistsError):
            m.write_csv(path, ['x'], [])
        self.assertEqual(path.read_text(), 'preserve')

    def test_formula_cell_escaped(self):
        path = self.root / 'safe.csv'
        m.write_csv(path, ['title'], [{'title': ' =1+1'}])
        self.assertEqual(m.read_csv(path, ['title'])[0]['title'], "' =1+1")

    def test_mapping_never_proves_redirect(self):
        _, rows = self.comp([{'url': 'https://old.example/a', 'title': 'Old'}],
                            [{'url': 'https://new.example/a', 'title': 'New', 'status': '200'}],
                            [{'old_url': 'https://old.example/a', 'new_url': 'https://new.example/a', 'disposition': 'redirect'}])
        self.assertEqual(rows[0]['migration_verification'], 'unknown')
        self.assertIn('title_changed', rows[0]['review_flags'])
        self.assertIn('schema_types_comparison_unknown', rows[0]['review_flags'])

    def test_unmapped_and_new_only_preserved(self):
        summary, rows = self.comp([{'url': 'https://old.example/a'}], [{'url': 'https://new.example/b'}], [])
        self.assertEqual(summary['report_rows'], 2)
        self.assertEqual(rows[0]['disposition'], 'unresolved')
        self.assertEqual(rows[1]['disposition'], 'new-only')

    def test_query_case_and_slash_preserved(self):
        urls = ['https://old.example/A?id=1', 'https://old.example/A?id=2', 'https://old.example/a/']
        _, rows = self.comp([{'url': u} for u in urls], [{'url': 'https://new.example/'}], [])
        self.assertEqual({r['old_url'] for r in rows if r['old_url']}, set(urls))

    def test_duplicate_keys_fail(self):
        with self.assertRaisesRegex(ValueError, 'duplicate'):
            m.keyed([{'url': 'https://a.example/'}, {'url': 'https://a.example/'}], 'url')

    def test_retire_cannot_hide_target(self):
        with self.assertRaisesRegex(ValueError, 'blank'):
            self.comp([{'url': 'https://old.example/a'}], [{'url': 'https://new.example/'}],
                      [{'old_url': 'https://old.example/a', 'new_url': 'https://new.example/', 'disposition': 'retire'}])

    def test_noindex_and_target_status_flagged(self):
        _, rows = self.comp([{'url': 'https://old.example/a'}],
                            [{'url': 'https://new.example/a', 'status': '404', 'robots': 'robots:none'}],
                            [{'old_url': 'https://old.example/a', 'new_url': 'https://new.example/a', 'disposition': 'redirect'}])
        self.assertIn('target_not_200', rows[0]['review_flags'])
        self.assertIn('target_explicit_noindex', rows[0]['review_flags'])

    def test_bad_urls_rejected(self):
        for url in ['file:///x', 'https://a.example/#x', 'https://u:p@a.example/', 'https://a.example:bad/', 'https://a.example/ a']:
            self.assertFalse(m.valid_url(url), url)

    def test_cli_failure_nonzero(self):
        with patch('sys.argv', ['migration_tools.py', 'inventory', '--backup', 'missing.zip', '--base', 'https://a.example', '--out', str(self.root / 'x.csv')]):
            with redirect_stderr(io.StringIO()) as output:
                self.assertEqual(m.main(), 1)
                self.assertIn('Error:', output.getvalue())

    def test_missing_target_not_silently_passed(self):
        _, rows = self.comp([{'url': 'https://old.example/a'}], [{'url': 'https://new.example/b'}],
                            [{'old_url': 'https://old.example/a', 'new_url': 'https://new.example/missing', 'disposition': 'redirect'}])
        self.assertIn('target_missing_from_inventory', rows[0]['review_flags'])

    def test_retained_same_url(self):
        url = 'https://same.example/a'
        _, rows = self.comp([{'url': url}], [{'url': url, 'status': '200'}],
                            [{'old_url': url, 'new_url': url, 'disposition': 'retain'}])
        self.assertEqual(len(rows), 1)
        self.assertEqual(rows[0]['disposition'], 'retain')

    def test_retain_changed_url_rejected(self):
        with self.assertRaisesRegex(ValueError, 'inconsistent'):
            self.comp([{'url': 'https://old.example/a'}], [{'url': 'https://new.example/a'}],
                      [{'old_url': 'https://old.example/a', 'new_url': 'https://new.example/a', 'disposition': 'retain'}])

    def test_mapping_source_outside_inventory_rejected(self):
        with self.assertRaisesRegex(ValueError, 'unknown mapping'):
            self.comp([{'url': 'https://old.example/a'}], [{'url': 'https://new.example/a'}],
                      [{'old_url': 'https://old.example/orphan', 'new_url': '', 'disposition': 'retire'}])

    def test_header_only_empty_inventory_rejected(self):
        with self.assertRaisesRegex(ValueError, 'must contain rows'):
            self.comp([], [{'url': 'https://new.example/a'}], [])

    def test_malformed_csv_rejected(self):
        path = self.root / 'broken.csv'
        path.write_text('url,title\nhttps://a.example/,A,extra\n')
        with self.assertRaisesRegex(ValueError, 'malformed'):
            m.read_csv(path, ['url'])

    def test_duplicate_headers_rejected(self):
        path = self.root / 'broken.csv'
        path.write_text('url,url\nhttps://a.example/,https://a.example/\n')
        with self.assertRaisesRegex(ValueError, 'headers'):
            m.read_csv(path, ['url'])

    def test_base_with_path_rejected(self):
        with self.assertRaisesRegex(ValueError, 'origin'):
            self.inv({'a.html': ''}, base='https://old.example/subdir/')


if __name__ == '__main__':
    unittest.main()
