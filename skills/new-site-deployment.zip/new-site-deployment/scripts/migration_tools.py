#!/usr/bin/env python3
"""Bounded offline HTML inventory and explicit URL-map comparison. No network I/O."""
import argparse
import csv
import hashlib
import json
import re
import stat
import sys
import zipfile
from html.parser import HTMLParser
from pathlib import Path, PurePosixPath
from urllib.parse import quote, urlsplit

FIELDS = ['url', 'status', 'final_url', 'redirect_chain', 'title', 'description',
          'h1', 'canonical', 'robots', 'content_hash', 'schema_types', 'evidence', 'url_basis']
DETAILS = FIELDS[1:]
DISPOSITIONS = {'retain', 'redirect', 'consolidate', 'retire', 'unresolved'}


def valid_url(value):
    try:
        parts = urlsplit(value)
        _ = parts.port
        return (parts.scheme in {'http', 'https'} and bool(parts.hostname)
                and parts.username is None and parts.password is None
                and not parts.fragment and not re.search(r'[\s\x00-\x1f\x7f]', value))
    except ValueError:
        return False


def write_csv(path, fields, rows):
    # Exclusive creation prevents clobbering inputs or previous reports.
    with Path(path).open('x', encoding='utf-8-sig', newline='') as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        for row in rows:
            safe = {}
            for key in fields:
                value = str(row.get(key, ''))
                if value.lstrip().startswith(('=', '+', '-', '@')) or value.startswith(('\t', '\r', '\n')):
                    value = "'" + value
                safe[key] = value
            writer.writerow(safe)


def read_csv(path, required):
    with Path(path).open(encoding='utf-8-sig', newline='') as handle:
        reader = csv.DictReader(handle)
        headers = reader.fieldnames or []
        if len(headers) != len(set(headers)) or not set(required) <= set(headers):
            raise ValueError(f'{path}: missing or duplicate headers; requires {required}')
        rows = []
        for line, row in enumerate(reader, 2):
            if None in row or any(v is None for v in row.values()):
                raise ValueError(f'{path}:{line}: malformed CSV row')
            rows.append({k: v.strip() for k, v in row.items()})
        return rows


def keyed(rows, field):
    result = {}
    for row in rows:
        url = row[field]
        if not valid_url(url):
            raise ValueError(f'invalid {field}: {url!r}')
        if url in result:
            raise ValueError(f'duplicate {field}: {url}')
        result[url] = row
    return result


class Page(HTMLParser):
    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.title = []
        self.h1 = []
        self.description = []
        self.canonical = []
        self.robots = []
        self.schemas = []
        self.capture_title = False
        self.capture_h1 = False
        self.capture_schema = False
        self.schema_buffer = []

    def handle_starttag(self, tag, attrs):
        a = dict(attrs)
        if tag == 'title':
            self.capture_title = True
        if tag == 'h1':
            self.capture_h1 = True
        if tag == 'meta':
            name = a.get('name', '').lower()
            if name == 'description':
                self.description.append(a.get('content', ''))
            if name in {'robots', 'googlebot', 'bingbot'}:
                self.robots.append(name + ':' + a.get('content', ''))
        if tag == 'link' and 'canonical' in a.get('rel', '').lower().split():
            self.canonical.append(a.get('href', ''))
        if tag == 'script' and a.get('type', '').lower() == 'application/ld+json':
            self.capture_schema = True
            self.schema_buffer = []

    def handle_endtag(self, tag):
        if tag == 'title':
            self.capture_title = False
        if tag == 'h1':
            self.capture_h1 = False
            self.h1.append(' | ')
        if tag == 'script' and self.capture_schema:
            self.capture_schema = False
            try:
                data = json.loads(''.join(self.schema_buffer))
                def visit(value):
                    if isinstance(value, dict):
                        types = value.get('@type', [])
                        if isinstance(types, str):
                            types = [types]
                        if isinstance(types, list):
                            self.schemas.extend(t for t in types if isinstance(t, str))
                        for child in value.values():
                            visit(child)
                    elif isinstance(value, list):
                        for child in value:
                            visit(child)
                visit(data)
            except (ValueError, RecursionError):
                self.schemas.append('INVALID_JSON_LD')

    def handle_data(self, data):
        if self.capture_title:
            self.title.append(data)
        if self.capture_h1:
            self.h1.append(data)
        if self.capture_schema:
            self.schema_buffer.append(data)

    def metadata(self):
        clean = lambda parts: ' '.join(''.join(parts).split()).strip(' |')
        return dict(title=clean(self.title), h1=clean(self.h1),
                    description=' | '.join(self.description),
                    canonical=' | '.join(self.canonical), robots=' | '.join(self.robots),
                    schema_types=' | '.join(sorted(set(self.schemas))))


def safe_name(name):
    return (bool(name) and '\\' not in name and ':' not in name
            and not name.startswith('/') and '..' not in PurePosixPath(name).parts)


def candidate_url(base, name):
    if name.lower().endswith(('index.html', 'index.htm')) and PurePosixPath(name).name.lower() in {'index.html', 'index.htm'}:
        name = name[:name.rfind('/') + 1] if '/' in name else ''
    return base.rstrip('/') + '/' + quote(name, safe='/')


def inventory(args):
    if not valid_url(args.base):
        raise ValueError('--base must be an absolute HTTP(S) origin')
    parts = urlsplit(args.base)
    if parts.path not in {'', '/'} or parts.query:
        raise ValueError('--base must be an origin; use --prefix for backup document root')
    if args.max_files < 1 or args.max_bytes < 1 or args.max_total_bytes < 1:
        raise ValueError('limits must be positive')
    prefix = args.prefix.strip('/')
    if prefix and not safe_name(prefix):
        raise ValueError('unsafe prefix')
    prefix = prefix + '/' if prefix else ''
    root = Path(args.backup)
    rows, total = [], 0
    summary = {'html_files': 0, 'skipped_non_html_or_prefix': 0, 'skipped_unsafe': 0,
               'bytes_read': 0, 'url_basis': 'inferred-file-path'}

    def consume(name, size, read, unsafe=False):
        nonlocal total
        if unsafe or not safe_name(name):
            summary['skipped_unsafe'] += 1
            return
        if not name.startswith(prefix) or PurePosixPath(name).suffix.lower() not in {'.html', '.htm'}:
            summary['skipped_non_html_or_prefix'] += 1
            return
        relative = name[len(prefix):]
        if len(rows) >= args.max_files or size > args.max_bytes or total + size > args.max_total_bytes:
            raise ValueError('backup exceeds configured HTML limits; narrow prefix or review limits')
        raw = read(args.max_bytes + 1)
        if len(raw) > args.max_bytes or total + len(raw) > args.max_total_bytes:
            raise ValueError('HTML byte limit exceeded')
        page = Page()
        page.feed(raw.decode('utf-8-sig', errors='replace'))
        page.close()
        total += len(raw)
        rows.append(dict(url=candidate_url(args.base, relative), **page.metadata(),
                         content_hash=hashlib.sha256(raw).hexdigest(),
                         evidence=f'observed-backup:{root.name}!{name}',
                         url_basis='inferred-file-path'))

    if root.is_dir():
        # Do not follow symlink directories, including Windows junctions.
        import os
        for parent, dirs, files in os.walk(root, followlinks=False):
            safe_dirs = [d for d in dirs if not (Path(parent) / d).is_symlink()
                         and not getattr((Path(parent) / d).lstat(), 'st_file_attributes', 0) & 1024]
            summary['skipped_unsafe'] += len(dirs) - len(safe_dirs)
            dirs[:] = sorted(safe_dirs)
            for filename in sorted(files):
                path = Path(parent) / filename
                unsafe = path.is_symlink() or bool(getattr(path.lstat(), 'st_file_attributes', 0) & 1024)
                name = path.relative_to(root).as_posix()
                def read(limit, p=path):
                    with p.open('rb') as handle:
                        return handle.read(limit)
                consume(name, path.lstat().st_size, read, unsafe)
    else:
        with zipfile.ZipFile(root) as archive:
            if len(archive.infolist()) > 100000:
                raise ValueError('too many ZIP entries')
            for entry in archive.infolist():
                if entry.is_dir():
                    continue
                def read(limit, e=entry):
                    with archive.open(e) as handle:
                        return handle.read(limit)
                consume(entry.filename, entry.file_size, read,
                        stat.S_ISLNK(entry.external_attr >> 16))
    if not rows:
        raise ValueError('no HTML found; backup may be source-only or prefix may be wrong')
    keyed(rows, 'url')
    rows.sort(key=lambda row: row['url'])
    write_csv(args.out, FIELDS, rows)
    summary.update(html_files=len(rows), bytes_read=total)
    return summary


def compare(args):
    old = keyed(read_csv(args.old, ['url']), 'url')
    new = keyed(read_csv(args.new, ['url']), 'url')
    mappings = keyed(read_csv(args.map, ['old_url', 'new_url', 'disposition', 'reason']), 'old_url')
    if not old or not new:
        raise ValueError('old and new inventories must contain rows')
    for url, item in mappings.items():
        target, disposition = item['new_url'], item['disposition']
        if url not in old or disposition not in DISPOSITIONS:
            raise ValueError(f'unknown mapping source or disposition: {url}')
        if disposition in {'retire', 'unresolved'}:
            if target:
                raise ValueError(f'{disposition} must have blank new_url: {url}')
        elif not valid_url(target):
            raise ValueError(f'invalid mapping target: {target!r}')
        elif (disposition == 'retain') != (target == url):
            raise ValueError(f'disposition inconsistent with target: {url}')

    fields = ['old_url', 'new_url', 'disposition', 'reason']
    fields += [prefix + key for prefix in ('old_', 'new_') for key in DETAILS]
    fields += ['review_flags', 'migration_verification', 'review_state']
    rows, referenced = [], set()
    for url, source in old.items():
        mapping = mappings.get(url, dict(old_url=url, new_url='', disposition='unresolved', reason='No mapping supplied'))
        target = mapping['new_url']
        destination = new.get(target, {})
        flags = []
        if target:
            referenced.add(target)
            if not destination:
                flags.append('target_missing_from_inventory')
            elif not destination.get('status'):
                flags.append('target_status_unknown')
            elif destination['status'] != '200':
                flags.append('target_not_200')
            robots = destination.get('robots', '').lower()
            if re.search(r'\b(noindex|none)\b', robots):
                flags.append('target_explicit_noindex_review_intent')
            if destination.get('canonical') and destination['canonical'] != target:
                flags.append('canonical_differs_review_resolution')
            for key in ('title', 'description', 'h1', 'content_hash', 'schema_types'):
                if not source.get(key) or not destination.get(key):
                    flags.append(key + '_comparison_unknown')
                elif source[key] != destination[key]:
                    flags.append(key + '_changed')
        else:
            flags.append('retirement_requires_live_check' if mapping['disposition'] == 'retire' else 'mapping_unresolved')
        row = {k: mapping.get(k, '') for k in ('old_url', 'new_url', 'disposition', 'reason')}
        for key in DETAILS:
            row['old_' + key] = source.get(key, '')
            row['new_' + key] = destination.get(key, '')
        row.update(review_flags=';'.join(flags), migration_verification='unknown', review_state='manual review required')
        rows.append(row)
    for url in sorted(set(new) - referenced):
        row = dict(old_url='', new_url=url, disposition='new-only', reason='',
                   review_flags='new_page_requires_QA', migration_verification='unknown', review_state='manual review required')
        row.update({'new_' + key: new[url].get(key, '') for key in DETAILS})
        rows.append(row)
    write_csv(args.out, fields, rows)
    return {'old_urls': len(old), 'new_urls': len(new), 'report_rows': len(rows), 'migration_verified': False}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    commands = parser.add_subparsers(dest='command', required=True)
    inv = commands.add_parser('inventory', help='Read static HTML from a ZIP or directory')
    inv.add_argument('--backup', required=True)
    inv.add_argument('--base', required=True, help='Historical HTTP(S) origin; paths are inferred')
    inv.add_argument('--prefix', default='', help='Backup document-root directory, e.g. public/')
    inv.add_argument('--max-files', type=int, default=10000)
    inv.add_argument('--max-bytes', type=int, default=2 * 1024 * 1024)
    inv.add_argument('--max-total-bytes', type=int, default=100 * 1024 * 1024)
    inv.add_argument('--out', required=True)
    comp = commands.add_parser('compare', help='Compare inventories using reviewed explicit mapping')
    for option in ('old', 'new', 'map', 'out'):
        comp.add_argument('--' + option, required=True)
    args = parser.parse_args()
    try:
        print(json.dumps(inventory(args) if args.command == 'inventory' else compare(args), sort_keys=True))
    except (OSError, ValueError, csv.Error, zipfile.BadZipFile, RuntimeError) as error:
        print(f'Error: {error}', file=sys.stderr)
        return 1
    return 0


if __name__ == '__main__':
    sys.exit(main())
