"""Check that packaged templates remain usable and their references resolve."""
import csv
import re
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


class AssetTests(unittest.TestCase):
    def test_local_markdown_links_resolve_inside_skill(self):
        for path in ROOT.rglob('*.md'):
            for target in re.findall(r'\]\(([^)]+)\)', path.read_text(encoding='utf-8')):
                if '://' in target or target.startswith('#'):
                    continue
                resolved = (path.parent / target.split('#')[0]).resolve()
                self.assertTrue(resolved.is_relative_to(ROOT), (path, target))
                self.assertTrue(resolved.is_file(), (path, target))

    def test_csv_templates_rectangular_and_unique_headers(self):
        for path in (ROOT / 'assets').glob('*.csv'):
            with path.open(encoding='utf-8-sig', newline='') as handle:
                rows = list(csv.reader(handle, strict=True))
            self.assertTrue(rows, path)
            self.assertEqual(len(rows[0]), len(set(rows[0])), path)
            for row in rows[1:]:
                self.assertEqual(len(row), len(rows[0]), (path, row))

    def test_seed_tasks_are_unknown_and_dependency_graph_is_ordered(self):
        path = ROOT / 'assets' / 'execution-checklist.csv'
        with path.open(encoding='utf-8', newline='') as handle:
            rows = list(csv.DictReader(handle))
        seen = set()
        for row in rows:
            self.assertEqual(row['status'], 'unknown')
            self.assertNotIn(row['task_id'], seen)
            for dep in filter(None, row['depends_on'].split(';')):
                self.assertIn(dep, seen, row)
            seen.add(row['task_id'])

    def test_monitoring_is_not_preclaimed(self):
        path = ROOT / 'assets' / 'monitoring-plan.csv'
        with path.open(encoding='utf-8', newline='') as handle:
            rows = list(csv.DictReader(handle))
        for row in rows:
            self.assertEqual(row['status'], 'unknown')
            self.assertEqual(row['last_observed_at'], '')
            self.assertTrue(row['response'])
            self.assertTrue(row['closure_criterion'])


if __name__ == '__main__':
    unittest.main()
