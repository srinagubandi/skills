# Website Design — research and validation

Version 1.0.0, November 10, 2026. Requested window: May 10–November 10, 2026.

## Five research and refinement passes

1. **Provider baseline.** Located public Anthropic, OpenAI and Google skills; read key source files. Separated visual direction, concept fidelity, and persistent design-system responsibilities. Outcome: one portable workflow rather than provider-specific dependencies.
2. **Recent YouTube workflow discovery.** Searched dates and topics, opened direct videos, then inspected available mirrored descriptions and chapters after retrieval failures. Rejected April 2026 and 2025 videos as outside the requested window. Outcome: a dated lead list with explicit access levels. Full-video deep review remains incomplete.
3. **Broader public skills and conflicts.** Compared Vercel, Impeccable, and Taste Skill; checked current repository material and recent changelog entries. Outcome: task-sensitive defaults, no mandatory animation or full-screen sections, and no automated execution of upstream hooks.
4. **Quality and evidence.** Checked W3C accessibility and Google's performance guidance against practical interface-review categories. Outcome: a test matrix, hard-failure checks, mockup versus implementation distinction, and no false compliance/conversion claims. These standards are foundational, not newly published research.
5. **Synthesis and forward check.** Authored the skill and references; used a separate agent on a dental-agency brief with missing proof, and initiated a hotel-navigation handoff scenario whose result was unavailable after an environment change. The first returned distinct directions, preserved mockup scope, and labeled sample reporting. Validation is qualitative and limited; it does not establish superiority over other skills or production design quality.

## What this package is

An original, reusable website-design skill with a conditional design playbook, quality gates, handoff template, and source register. It supports website and campaign-page design, desktop/mobile concepts, refinement, implementation direction, and critique. It is not a bundle of third-party skills.

## Limitations

Five passes were performed, but full transcript/footage review was not completed. Some repository publication dates remain unverified; current content is not proof of a recent change. No comparative benchmark or finished website was produced for this task. The phrase best in class describes the intended bar, not a demonstrated result. Structural validation and archive checks are recorded in VALIDATION.txt. Automatic installation status is separate from ZIP readiness.

## How to use

Extract the archive. The website-design folder contains SKILL.md and references. Import that folder through the skill mechanism supported by your agent, or ask a coding agent to read SKILL.md and follow its linked references. This package has no runtime dependencies or executable hooks. agents/openai.yaml is optional UI metadata; the core instructions are Markdown.

Example: Use website-design to produce three genuinely different desktop/mobile mockups. Preserve the existing logo and verified offer. Do not code yet.

Example: Use website-design to refine this landing page, keep the brand, and give a coding agent exact tokens, copy, responsive behavior, and acceptance checks.

Do not assume downloading the ZIP installs it automatically. Do not deploy websites merely because this package is imported.
