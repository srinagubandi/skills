# Design handoff template

Use relevant sections only; save completed handoffs with the target project.

## Brief
Audience; visitor task; action; routes; output mode; devices; verified copy and sources; brand constraints; assumptions; open factual questions.

## Direction
Organizing idea; audience rationale; focal element; typography; imagery; reference sources and their contributions; deliberately avoided patterns and reasons.

## Design system
Brand assets/rights. Colors: token, exact value, role, allowed pairings. Typography: role, family/fallback, weight, size range, line height. Layout: containers, gutters, columns, collapse rules, reading order. Spacing and geometry. Components and states. Media sources, crop, aspect ratio, alt intent, fallback. Motion purpose, trigger, timing, interruption, reduced variant.

## Content inventory
Section | visitor question | exact copy | asset | action | mobile change.
Record prices, exclusions, program terms, promotion dates, and evidence provenance. Distinguish illustrative examples from publishable claims.

## Implementation mapping
Routes/components; reusable existing components; data/integration dependencies; prototype-only behavior; approved deviations and reasons.

## Acceptance
Requirement | evidence | tested viewport/state | status | unresolved issue.
Explicitly mark unavailable checks not tested.

## Delivery
What changed; why; what was verified; what needs confirmation; artifact links.
