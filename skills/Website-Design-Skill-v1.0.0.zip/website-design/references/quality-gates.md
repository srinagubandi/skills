# Quality gates

Use WCAG 2.2 AA as a technical target absent another specified target, not as a statement about applicable law. Mockup review is not implementation verification.

## Hard failures

Do not call a build complete with a blocked primary task, missing required content, keyboard-inaccessible controls, unreadable essential text, false submission success, or damaging overflow. Report unavoidable blockers.

## Visual evidence

Where feasible inspect 1440, 1024, 768, 390, and 320 CSS-pixel widths, recording height too. Adapt to supported devices and inspect intermediate widths near layout changes. Compare actual renders to the chosen reference for copy, hierarchy, geometry, type, media, crop, color, and states. Test long names, enlarged text, missing images, and empty content. Do not conceal overflow by blindly clipping the entire page.

## Accessibility subset

Check structure, labels, native controls, meaningful alternative text, keyboard order, visible focus, menu/dialog dismissal, and focus return. Ensure sticky regions do not obscure focus. Check text contrast: 4.5:1 normal and 3:1 large text; applicable UI contrast: 3:1. Check 320 CSS-pixel reflow and text enlargement. Meet the WCAG 2.2 AA 24-by-24 CSS-pixel target-size criterion or its defined exceptions; prefer larger comfortable touch areas. Respect reduced motion and applicable pause/stop requirements. Provide error identification and recovery. Placeholders are not labels.

This is a subset, not a conformance audit. Combine automated tools with manual keyboard, assistive-technology, and complete-flow review.

## Functional states

Forms: empty, valid, invalid, submitting, success, network failure, retry, duplicate submission. Preserve values after recoverable errors. Verify real integrations in an appropriate environment without unauthorized messages or submissions.

Navigation: current route, collapsed/expanded menu, keyboard use, dismissal, deep links, back navigation. Async content: loading, empty, unavailable, retry, successful result. Label simulated data in prototypes.

## Performance

Google's good-experience field thresholds are LCP at most 2.5 seconds, INP at most 200 milliseconds, and CLS at most 0.1 at the 75th percentile, segmented by device category. These are targets, not observations of the current site. Lab results are diagnostic; record device/network settings and do not treat a Lighthouse score as field INP or conversion evidence. Reserve media dimensions, avoid unnecessary downloads, and check expensive animation or script work. Do not lazy-load the primary content image by default.

## Review record and rubric

Record requirement | route/artifact | viewport/state | observation | status | next action. Status: passed, failed, not tested, not applicable. A missing tool is not tested.

Score audience clarity, brand specificity, hierarchy, composition, responsive adaptation, and fidelity from 0–4 with reasons. 0 absent/broken; 1 major issues; 2 usable/uneven; 3 coherent; 4 unusually well resolved for this brief. This is an editorial rubric, not an industry benchmark. Hard failures override totals.

Batch inspection, fixes, and confirmation. Keep before/after evidence. Continue only for defects, changes, or requested refinement. Never invent test results.

Foundational sources reviewed November 10, 2026: https://www.w3.org/TR/WCAG22/ and https://web.dev/articles/vitals . Both predate the six-month research window.
