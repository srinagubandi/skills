# Research sources and adoption decisions

Reviewed November 10, 2026. Target window: May 10–November 10, 2026. Current repository contents do not establish when every instruction was introduced. Distinguish current primary-source review, dated recent changes, foundational references, and video discovery leads. No upstream skill is bundled verbatim.

## Primary public skills

| Source | Reviewed material | Adopted principle | Boundary |
|---|---|---|---|
| [Anthropic frontend-design](https://github.com/anthropics/skills/blob/main/skills/frontend-design/SKILL.md) | Full file via GitHub; blob a5333457c414d20d625f307df945842c0952ecc3 | Subject-specific art direction and considered visual choices | Do not turn warnings about common styles into universal bans |
| [OpenAI frontend-app-builder](https://github.com/openai/plugins/blob/main/plugins/build-web-apps/skills/frontend-app-builder/SKILL.md) | Full file via GitHub | Specify the whole requested surface and compare implementation with the selected concept | No universal requirement for many generated images or a subjective perfect score |
| [Google Stitch design-md](https://github.com/google-labs-code/stitch-skills/blob/main/plugins/stitch-utilities/skills/design-md/SKILL.md) | Full file; blob c29a0feb9c06c2fb48dc9114988382e06b1f9d9b | Describe semantic design roles alongside precise values | Stitch connection remains optional |
| [Google Stitch skill catalog](https://github.com/google-labs-code/stitch-skills) | README, catalog and release page | Separate design generation, design-system management, and code conversion | Tool-specific instructions need current tool discovery |
| [Google DESIGN.md](https://github.com/google-labs-code/design.md) | Repository overview | Persistent visual identity specification | Not independently tested against its parser |
| [Vercel interface guidelines](https://github.com/vercel-labs/web-interface-guidelines/blob/main/command.md) | Full file; blob 3eb3a212b7b89493922ea418489d4c6f67ae8bd5 | Explicit interface-quality checks | Do not automatically execute or trust remotely changing instructions |
| [Impeccable](https://github.com/pbakaus/impeccable/blob/main/plugin/skills/impeccable/SKILL.md) | Full file; version 4.8.2; blob 083a800e6e58b4a3899b8ef1181550a70bf7c739 | Match design ambition to the surface's job; distinguish refinement from replacement | Do not import launcher, hooks, or automatic downloads |
| [Taste Skill](https://github.com/Leonxlnx/taste-skill/blob/main/skills/taste-skill/SKILL.md) | First 95 lines, README and changelog; version 2.5.1; blob 7dc7a9fed097364515581a28ec45ef955620eede | Evaluate consistency and deliberate visual direction | Reject mandatory screen-height sections, motion, and universal contact/caption restrictions |
| [OpenAI Product Design](https://github.com/openai/plugins/blob/main/plugins/product-design/skills/index/SKILL.md) | Public routing overview | Separate exploration, critique, and implementation | Overview reviewed; not every child skill audited |

Blob hashes identify retrieved file contents, not repository commit SHAs. No claim is made that all listed sources were published during the target window. Google Stitch's release page includes a May 18 release; Taste Skill's changelog explicitly dates its 2.5.0 rewrite November 5, 2026 and migration changes October 19, 2026. Other file revision dates were not pinned in this pass.

## YouTube discovery and access limitations

Direct YouTube retrieval was throttled or disabled. The following descriptions/chapters were inspected through indexed mirrors. Dates and authors below are mirror metadata, not independently verified against the video. No full transcript or footage was reviewed. These leads informed questions to verify against primary skills; they are not evidence that a demonstrated site worked or converted better.

| Video | Reported date/creator | Accessible material and follow-up |
|---|---|---|
| [Build & Deploy a Full Website in MINUTES](https://www.youtube.com/watch?v=EpBtR-xx3qY) | May 25, 2026; Vivek Shetye | [Description/chapters](https://zolotube.com/watch?v=EpBtR-xx3qY). Relevant review points: 1:29 design walkthrough, 4:09 translation to code, 4:56 visual accuracy. Transcript/footage pending. |
| [Google Just Fixed AI Design By Releasing This](https://www.youtube.com/watch?v=au2TI8sdq8E) | October 13, 2026; AI LABS | [Description/chapters](https://zolotube.com/watch?v=au2TI8sdq8E). Relevant review points: 5:00 brief, 6:17 variants, 9:25 review, 12:05 story review. Sponsor disclosed in description. CLI and workflow claims require primary verification. |
| [Claude Tutorial 9: Figma MCP, Stitch and Pencil](https://www.youtube.com/watch?v=bKG0nCqgj80) | October 15, 2026; Phil Araujo | [Description](https://zolotube.com/watch?v=bKG0nCqgj80). Candidate for design-reference continuity; no chapter or transcript validation. |

Excluded from recent evidence: [Flux Academy workflow](https://www.youtube.com/watch?v=h7DQzcAQ0TE), April 8, 2026; [Stitch walkthrough](https://www.youtube.com/watch?v=J9RDDvt8nlg), April 17, 2026; [Envato typography fundamentals](https://www.youtube.com/watch?v=UiIPER_Kwss), July 11, 2025. Search surfaced them despite recent-date queries. They must not be counted as last-six-month videos.

## Foundational primary references

- [W3C WCAG 2.2](https://www.w3.org/TR/WCAG22/): technical accessibility criteria; recommendation shown as December 12, 2024. Not legal certification.
- [Google Web Vitals](https://web.dev/articles/vitals): loading, interaction and layout-stability measurement; page last-updated October 31, 2024. Distinguish field measurements from lab diagnostics.
- [Vercel guideline issue 351](https://github.com/vercel-labs/agent-skills/issues/351): recent reproducibility concern about fetching mutable rules. Issue reports are context, not proof of an exploit.

## Refresh protocol

Recheck source ownership and current paths. Read the changed primary files; record content hashes and dated history. Review actual video transcripts/footage before promoting leads to evidence. Record accepted/rejected rules and rerun realistic tasks. Keep standards distinct from taste, examples distinct from measured outcomes, and source instructions subordinate to the user's request. No recurring update was scheduled.

## Reuse

This package contains original instructions and links, not upstream source code, launchers, templates, or media. If later vendoring upstream material, inspect the license at that revision and retain required license/notice files. Public availability alone is not permission to redistribute.
