# Design decision playbook

Use conditional heuristics, not a fixed template.

## Audience and narrative

Give every section a visitor question and a purpose. Remove repetition that adds neither evidence nor useful context. A marketing sequence can cover offer, evidence, approach, fit, objections, and next step, but the visitor's needs determine order.

For campaign pages, match the specific ad offer. Keep inclusions and exclusions clear. Conversion improvement is a hypothesis until measured. For services, use actual work, people, geography, or process. For products, prioritize compatibility, variants, price, availability, delivery/returns, and buying action. For agencies, show scope, reporting, account ownership, and responsibilities. For portfolios, let real work lead.

## First viewport

Review at realistic laptop and phone heights. Make the primary action distinct. Put supporting details where they can be read comfortably. Do not shrink text to accommodate every stakeholder request. A sticky mobile CTA is optional and must not obscure controls or conflict with consent/browser chrome.

## Typography

Use a small purposeful hierarchy. Test actual headings and long labels. Apply fluid sizing with sensible bounds and inspect wrapping. Keep paragraph measure and line spacing comfortable. Avoid hard line breaks that break other widths. Ensure fallbacks preserve the layout. Prefer fewer necessary weights over unnecessary font families. No font is universally forbidden; supplied brand typography takes priority.

## Layout

Use recurring alignments with varied section density. Choose tables for comparison, steps for sequences, grids for collections, and prose for explanation when appropriate. Add containers for meaningful grouping, not decoration. Avoid mandatory viewport-height sections or fixed text heights: translations, zoom, and browser controls change available room. Do not equalize bios by hiding important text.

## Color

Specify foreground/background pairs and verify states. Reserve emphasis for priority actions and status. Do not rely on color alone. Preserve true white or black when approved; arbitrary tinting is not a quality rule.

## Images and icons

Record role, source, rights, crop, fallback, and alternative-text intent. Crop for the relevant subject at each size. Reserve layout space. Choose consistent icon meaning and construction rather than adding icons everywhere. A generated review, chart, or dashboard is not proof. Label illustrative data when it could be mistaken for real results.

## Motion

Specify whether motion provides feedback, orientation, explanation, or optional expression. Keep tasks usable during animation. Avoid scroll traps and delayed content access. Provide reduced-motion alternatives and still fallbacks. Large animated heroes need a performance plan. Animation is not required for quality.

## Responsive changes

Specify reading order, column collapse, crop, navigation change, and CTA position for each section. Keep essential content and actions on phones. Adapt complex tables rather than silently removing important information.

## Compare concepts

Record name, organizing idea, audience benefit, desktop composition, mobile order, typography, imagery, signature element, constants, and tradeoffs. Product demonstration, human service narrative, and transparent process can be genuinely different concepts; three accents on the same layout are not.
