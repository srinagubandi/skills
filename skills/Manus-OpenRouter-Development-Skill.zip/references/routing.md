# Routing and Manus setup
Research checked 2026-11-10. Treat model IDs, prices and UI support as changeable.

## Compatibility probe
Inspect configuration and public metadata first. Before any paid diagnostic request, establish the estimated budget and agreed ceiling. Count diagnostic calls against that ceiling.
1. Check whether the user's Manus workspace exposes Flex with OpenRouter. Verify the selected provider/model in configuration and a bounded diagnostic request's usage evidence.
2. Test whether role-specific model selection is available. A single primary-model setting does not prove per-stage switching.
3. If not, use explicit HTTPS calls from a permitted execution tool to https://openrouter.ai/api/v1/chat/completions (or the documented Responses endpoint). Keep the key in the secret store/environment, never a browser bundle.
4. Determine whether the Manus orchestrator itself uses OpenRouter. Explicit subcalls alone cannot satisfy an all-inference policy if the outer agent uses another route. Report the limitation and request a setup change, not an invented guarantee.
5. Standard Git/Railway/browser calls need no LLM. Avoid Railway Agent or other AI wrappers unless their inference is also verified through OpenRouter.
6. Report native Manus credits separately: Flex documentation says non-inference services/infrastructure can still consume credits.

## Role policy
| Role | Eligibility | Effort |
| --- | --- | --- |
| P1/P2/S1/S2 | Verified high-tier Claude, typically Opus-class | High if supported and budgeted |
| Implementation/fixes/summaries | High-capability open-weight model with verified weights/license and coding/tool support | Task-appropriate; high for difficult implementation |
| Test design/review | Verified medium-tier Claude, typically Sonnet-class | Medium if supported |
| Extra diagnosis | High-tier Claude, targeted input only | Budgeted separately |

At setup query GET https://openrouter.ai/api/v1/models. Filter candidates locally by capabilities, inspect current author/model cards and licenses to establish open weights, and verify exact IDs. Candidate families to investigate include Qwen, DeepSeek and Kimi; family names are not eligibility evidence. Select among high-capability candidates on representative repository tasks and total accepted-slice cost, not lowest price or largest context. Do not run a large benchmark for every feature; reuse dated project results until conditions change.

Record an explicit allowlist for each role and eligible fallback. Pin concrete model IDs for a feature. Distinguish provider fallback for the same model from model fallback. Allow only providers meeting privacy, tool and parameter requirements. Use provider.require_parameters=true when required options must not be ignored. Use data_collection=deny and/or ZDR only if project policy requires them; verify availability before work and never relax silently.

## Request shape
Construct from validated runtime values, not copied placeholder IDs:
```json
{
  "model": "<exact role-eligible model ID>",
  "messages": [
    {"role": "system", "content": "<stable role instructions>"},
    {"role": "user", "content": "<compact stage packet>"}
  ],
  "max_tokens": 8192,
  "provider": {"require_parameters": true, "allow_fallbacks": false},
  "reasoning": {"effort": "high"}
}
```
This is an illustrative planning request, not a universal setting. Check model/endpoint support; omit unsupported optional fields rather than claiming they work. The total output cap must leave room for visible results plus reasoning. Do not set both reasoning.effort and reasoning.max_tokens. Validate responses and reject truncated or empty stage artifacts. Keep necessary tool-call/reasoning continuation fields intact where the provider requires them; do not manually edit opaque protocol blocks.

Use stable per-role session IDs where supported. Different roles have different contexts; no cross-model cache assumption. Never retry auth, invalid request or exhausted-balance errors blindly. At most two transient retries with backoff/jitter, respecting Retry-After. Before replaying an uncertain tool side effect, inspect its actual state.

## Manus use
Import the skill folder through Manus Skills → Add → Upload a skill, then select it via slash command. Manus documentation also describes .skill/.zip and public GitHub imports. Importing the folder does not configure Flex, keys, model routing, hooks or production permissions. Check those separately. Do not assume ChatGPT installation installs it in Manus.
