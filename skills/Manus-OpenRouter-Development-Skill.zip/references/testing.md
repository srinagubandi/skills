# Verification
Claude medium owns test design and independent evidence review; local tools/CI execute tests. Review source and requirements, not just screenshots or a developer's summary.

| Change | Minimum meaningful evidence |
| --- | --- |
| Business logic | Boundary/negative examples plus focused unit tests |
| API or database | Contract/integration checks, validation, errors, transaction behavior |
| Auth or multi-tenant | Unauthorized/forbidden cases, cross-tenant access and server enforcement |
| UI flow | Browser behavior at relevant desktop/mobile sizes, keyboard flow, error/loading/empty states |
| Migration | Representative staging data, backward compatibility and recovery procedure |
| Deployment/config | Actual target SHA/config, startup/readiness and critical route smoke test |
| AI feature | Routing/role guard, output validation, timeout/rate-limit behavior, secret isolation |

Run baseline checks once and record pre-existing failures. Build and typecheck with existing commands/lockfile. Favor tests of observable behavior over tests that repeat implementation. Do not add broad brittle suites for cosmetic-only changes; still obtain medium-tier verification appropriate to the change.

Browser checks: discover selectors from rendered state; prefer accessible roles/labels and web-first assertions. Use meaningful readiness conditions, not arbitrary sleeps or blanket networkidle (Playwright discourages networkidle for testing). Capture screenshots and console/network errors where useful. A screenshot alone does not verify a submit operation.

Run the focused suite while iterating, then required regression/build checks at integration. Any final source/config/dependency change invalidates affected evidence. Associate all results with exact code and environment. Skipped/cancelled/no-tests-found results are not passes. Never invent test counts.
