# Git and Railway delivery
## Git
Inspect status, branch, remotes and base SHA first. Do not overwrite/stash/discard someone else's changes automatically. Use a feature branch; use git worktree for independent writers when useful. One behavior per commit; explicitly stage relevant paths, inspect the staged diff, and never use broad git add blindly.
Keep secrets/build output out of Git; commit lockfiles and minimal environment examples without values. Record scope, tests and risks in PR descriptions. Enforce required checks through branch protection/rulesets where permitted. AI skeptic approval does not replace GitHub's required reviewer.
Do not rewrite shared history or force-push by default. Fetch and resolve integration changes deliberately; revalidate affected code. Verify the exact pushed/merged SHA and check results; old green checks are insufficient. Keep PRs small and avoid needless framework/dependency replacement.

## Railway preflight
Resolve workspace, project, environment, service, source repository/branch, root directory, start/build commands, variables and database dependencies. A supplied resource URL takes precedence over a possibly unrelated local link. Read back scope before changes. Reuse existing resources unless new ones are needed; avoid duplicate paid services.
Prefer explicit IDs with CLI/MCP. Check installed CLI help instead of inventing flags. Direct CLI/MCP operations avoid extra AI inference. Do not dump variable values into logs.

## Build and release
Use the repository's pinned runtime and lockfile. Bind the app to the correct network interface and Railway PORT. Configure readiness, graceful shutdown, timeouts and structured logs. Keep secrets server-side and separate staging/production credentials and databases.
Use PR/staging environments only where appropriate; verify they do not share production data or send real emails/payments. Estimate ongoing infrastructure cost and remove owned temporary resources after their purpose ends, within authorization.
For GitHub autodeploy, enable Wait for CI where available and ensure CI runs on push to the deployment branch, as well as PRs. Inspect the actual workflows: Railway considers workflow conclusions and can treat cancelled/skipped runs differently from failures. Required migration steps must not depend on a cancellable workflow alone.
Run migrations in a deliberate deployment step using locking/idempotency and expand–migrate–contract strategy. Railway pre-deploy runs in a separate container with no mounted volumes and no persistent filesystem changes; ensure dependencies exist and bound its timeout. Test destructive migrations and backup/recovery separately. Never auto-run destructive database work merely because a deploy was requested.
Deploy only within the user's authorization. Existing production authorization persists. If absent, finish the concrete staging/test result and seek the production decision at the last step.

## Verify and recover
Read back the exact deployment ID, target and source SHA. Wait for a terminal successful state, then smoke-test the actual URL and critical behavior. Queued/build-passed/CLI-timeout is not success. Railway deployment healthchecks do not continuously monitor a live service; configure ongoing monitoring separately.
For failure, inspect bounded build/runtime logs, identify a new hypothesis and avoid repeated unchanged deployments. Report ambiguous status accurately.
Before release, record a known-good rollback target and verify it remains within plan retention. Current Railway docs describe rollback restoring the deployment image and custom variables; inspect other config/infrastructure differences. Database data/schema recovery is a separate operation, not implied by app rollback. Check backward compatibility before rollback. Never promise zero downtime for a service with attached volumes.

## Completion evidence
Repository/branch/commit/PR; CI checks and SHA; Railway target IDs and deployment ID/status; live URL and smoke result; migration/backup state; residual risks; cleanup and cost ownership.
