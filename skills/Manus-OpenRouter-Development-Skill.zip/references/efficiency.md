# Token and total-cost discipline
## Before calls
- Read the shortest useful repository instructions, current handoff and slice contract. Search symbols/file paths before opening files. Exclude dependencies, build outputs and generated assets from searches unless relevant.
- Send selected file excerpts, interfaces, tests and error context. Retain access paths to complete evidence. Do not repeatedly paste the whole repository or research dossier.
- Use existing scripts and --help before reading their full implementation. Run formatters, parsers, searches and calculations directly.
- Resolve unknowns cheaply with read-only inspection before speculative implementation.
- Keep instructions and tool schemas stable within a role/session. Put dynamic task state at the end. Do not add timestamps to the beginning of every prompt.
- Separate planner, skeptic, implementer and tester contexts. A short handoff is cheaper than transferring every discussion.
- Use caching only where supported. Check actual cached-token usage; cache writes have costs, minimum lengths and expiry. Do not pad prompts to chase caching. Never assume a cache transfers across models/providers.

## During work
One acceptance criterion at a time. Reuse verified evidence for an unchanged SHA/environment; rerun when code, dependencies, config or underlying state invalidates it. Save full logs to files and return only bounded relevant excerpts with paths. Preserve the first meaningful error and failed hypotheses to prevent repeated dead ends.
Do not rerun all planning stages for each slice, repeatedly inspect unchanged files, retry identical failing prompts, poll long logs every second, or regenerate whole files to alter a few lines.
Compact at natural slice boundaries using a verified checkpoint. Avoid removing unresolved issues, IDs, criteria, or reproducible failure commands. Do not overwrite an in-flight tool conversation's protocol history.

## Estimate then cap
Estimate tokens and current rates separately for P1/S1/P2/S2, each implementation slice, each medium-tier test pair, and a retry reserve. Include cache-write/read and provider/request costs where applicable; label assumptions. Agree a total ceiling and per-stage reservations before paid calls. An estimate is not a promise of final cost.
Reserve predicted worst-case call cost before dispatch. Serialize spending or atomically reserve budget for concurrent calls. At 80% of ceiling, report remaining work and forecast; at the ceiling stop new paid calls. These percentages are workflow defaults, not vendor facts.
Use actual usage.cost when returned. Missing accounting or ambiguous timeouts require reconciliation before further unbounded spending. Never count reasoning tokens twice when already included in completion tokens. Provider/key limits provide stronger protection than a prompt.

## Measures
Track total spend per accepted slice; first-pass acceptance; repair count; input/output/reasoning/cached tokens; wall time; escaped defects; and test coverage of acceptance criteria. Include failed work in total cost. Do not claim savings without a comparable baseline and equivalent acceptance quality. Report Manus platform and Railway resource costs separately from OpenRouter inference.
