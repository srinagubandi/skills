# Research evidence and four refinement passes
Checked 2026-11-10. These were research/design passes performed in the authoring session, not four paid Claude executions. No Manus/OpenRouter inference integration was run during authoring. No measured token-savings claim is made.

## Pass 1 — Foundations and transferable skills
Question: Which established practices transfer across agents?
Reviewed OpenAI skill structure/CI repair, Anthropic coding/context guidance and webapp-testing, Google Gemini skill guidance, and Manus context engineering.
Revision: keep a small entry point, load references on demand, use deterministic tools, and require test evidence and resumable file-based state.
Rejected: copying every vendor's native CLI behavior into Manus. Those capabilities are not interchangeable.

## Pass 2 — Model routing and economics
Question: Can every required role really use OpenRouter?
Reviewed Manus Flex and OpenRouter models, parameter routing, caching, reasoning and accounting documentation.
Revision: add outer-harness routing verification; separate model tier from reasoning effort; pin role-eligible IDs; preserve unknown costs; estimate first with an agreed ceiling.
Rejected: assuming explicit API subcalls prove all Manus inference routes through OpenRouter, or that a model-family label establishes open weights.

## Pass 3 — Small slices, Git and Railway
Question: What prevents cheap coding from producing expensive failures?
Reviewed Git worktrees, GitHub protected branches, Railway environments, pre-deploy, CI gating and rollback.
Revision: one behavior per slice; independent Claude-medium test design/review; exact-SHA evidence; stage only owned files; explicit target IDs; separate database recovery.
Rejected: treating pushed code, a completed build, or a queued deployment as a verified release.

## Pass 4 — Contradictions and failure cases
Question: Where can a superficially compliant workflow still waste money or falsely pass?
Cross-checked Manus import docs, Playwright readiness, Railway healthcheck scope/Wait-for-CI edge cases, OpenRouter output/reasoning budgets and usage accounting.
Revision: replace blanket networkidle with web assertions, add runtime monitoring distinction, reject truncated review artifacts, cap retries, and preserve unknown charges.
Found conflict: Anthropic's public webapp-testing example uses networkidle; Playwright's API explicitly discourages it for tests. Follow the tool's maintained readiness guidance.
Found conflict: older OpenRouter help mentions usage.include, while detailed accounting docs say it is deprecated and usage is automatic. Read response usage without depending on the old flag.
Boundaries: four mandatory high-tier calls are this user's policy, not a vendor-validated optimum. Numeric slice sizes, repair caps and budget warning thresholds are tunable engineering defaults.
Validation: bundled script is exercised with known, missing, zero and invalid costs; skill schema and links are checked; independent dry-run scenario evaluates routing, budget and deployment gates. Independent dry-run correctly blocked unverified outer Manus routing and unspecified models/budget, preserved existing production authorization and dirty files, and rejected BUILDING as success. It exposed two ambiguities now corrected: all inference explicitly includes the outer orchestrator, and paid diagnostic probes require the agreed budget first. Live integration remains untested.

## Source map
All links below are primary sources; paraphrased techniques are adapted, not copied skill implementations. Read only the relevant source when refreshing facts.

| Source | Applied finding |
| --- | --- |
| [OpenAI skill guide](https://developers.openai.com/codex/skills/) | Modular instructions/resources and targeted activation |
| [OpenAI skill creator](https://github.com/openai/skills/blob/main/skills/.system/skill-creator/SKILL.md) | Concise core and progressive disclosure |
| [OpenAI gh-fix-ci](https://raw.githubusercontent.com/openai/skills/main/skills/.curated/gh-fix-ci/SKILL.md) | Inspect actionable failing CI evidence; its separate approval defaults were not imported |
| [Anthropic coding guidance](https://code.claude.com/docs/en/best-practices) | Tests and enforceable controls are stronger than prompt promises |
| [Anthropic context engineering](https://www.anthropic.com/engineering/effective-context-engineering-for-ai-agents) | Curate task context and preserve long-task state |
| [Anthropic webapp-testing](https://raw.githubusercontent.com/anthropics/skills/main/skills/webapp-testing/SKILL.md) | Script-based browser inspection and evidence; readiness advice cross-checked |
| [Google Gemini skill guidance](https://geminicli.com/docs/cli/skills-best-practices/) | Scoped instructions, deterministic helpers, concise output and reviewed dependencies |
| [Google public skill guidance source](https://github.com/google-gemini/gemini-cli/blob/main/docs/cli/skills-best-practices.md) | Public reusable skill-authoring practices |
| [Manus context engineering](https://www.manus.im/blog/Context-Engineering-for-AI-Agents-Lessons-from-Building-Manus) | Stable prefixes, recoverable file-based context and remembered failure evidence |
| [Manus Flex](https://manus.im/blog/introducing-manus-flex) | OpenRouter partner support; provider inference billing distinct from platform services |
| [Manus skill import](https://help.manus.im/en/articles/14753565-how-to-share-and-use-skills-in-manus) | Folder/archive/GitHub imports and explicit skill selection |
| [OpenRouter official skills](https://openrouter.ai/skills/) | Model discovery and usage tooling; inspect relevant skills rather than loading all |
| [OpenRouter models](https://openrouter.ai/docs/guides/overview/models) | Live catalog, supported parameters, prices and context |
| [Provider routing](https://openrouter.ai/docs/guides/routing/provider-selection) | Required-parameter and fallback controls |
| [Prompt caching](https://openrouter.ai/docs/guides/best-practices/prompt-caching) | Stable provider/session routing; check actual cache usage |
| [Reasoning budgets](https://github.com/OpenRouterTeam/docs/blob/main/guides/best-practices/reasoning-tokens.mdx) | Reasoning can consume output cap and leave no visible answer |
| [Usage accounting](https://github.com/OpenRouterTeam/docs/blob/main/cookbook/administration/usage-accounting.mdx) | Actual cost and token fields; missing cost is not zero |
| [Cost-quality evaluation](https://openrouter.ai/blog/insights/cost-vs-quality-tradeoff-framework-for-agent-models/) | Choose among quality-qualified models using task evidence and actual cost |
| [Git worktrees](https://git-scm.com/docs/git-worktree) | Isolated working directories for branches |
| [GitHub branch protection](https://docs.github.com/en/repositories/configuring-branches-and-merges-in-your-repository/managing-protected-branches/about-protected-branches) | Required checks and reviews |
| [Railway environments](https://docs.railway.com/environments) | Separate deployment configuration scopes |
| [Railway pre-deploy](https://docs.railway.com/deployments/pre-deploy-command) | Separate container; no persistent local files/volumes |
| [Railway autodeploy/CI](https://docs.railway.com/deployments/github-autodeploys) | Push-triggered CI and workflow-conclusion limitations |
| [Railway healthchecks](https://docs.railway.com/deployments/healthchecks) | Readiness before activation; no ongoing endpoint monitoring |
| [Railway rollback](https://docs.railway.com/deployments/deployment-actions) | Prior image/custom variables and retention limits |
| [Playwright page API](https://playwright.dev/docs/api/class-page) | Web assertions rather than networkidle for tests |

## Refresh protocol
At project setup, recheck exact model availability/pricing/license, Manus routing controls and any platform feature actually used. Refresh stale evidence before changing model selections. Rerun skill scenarios after changes to workflow gates. Do not install all upstream skills automatically or run their scripts without inspection.
