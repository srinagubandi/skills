#!/usr/bin/env python3
"""Summarize sanitized OpenRouter JSONL records; no network or credentials."""
import argparse
import json
from decimal import Decimal, InvalidOperation
from pathlib import Path

def summarize(records):
    total = Decimal("0")
    unknown = 0
    roles = {}
    for record in records:
        role = record.get("role", "unknown")
        bucket = roles.setdefault(role, {"calls": 0, "known_cost_usd": Decimal("0"), "unknown_cost_calls": 0})
        bucket["calls"] += 1
        usage = record.get("usage") or {}
        cost = usage.get("cost")
        if cost is None:
            unknown += 1
            bucket["unknown_cost_calls"] += 1
            continue
        try:
            amount = Decimal(str(cost))
        except (InvalidOperation, ValueError):
            raise ValueError("Invalid usage.cost")
        if not amount.is_finite() or amount < 0:
            raise ValueError("Cost must be finite and nonnegative")
        total += amount
        bucket["known_cost_usd"] += amount
    for bucket in roles.values():
        bucket["known_cost_usd"] = str(bucket["known_cost_usd"])
    return {"known_cost_usd": str(total), "unknown_cost_calls": unknown, "complete": unknown == 0, "by_role": roles}

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("ledger", type=Path)
    args = parser.parse_args()
    try:
        records = []
        with args.ledger.open(encoding="utf-8-sig") as source:
            for number, line in enumerate(source, 1):
                if not line.strip():
                    continue
                item = json.loads(line)
                if not isinstance(item, dict) or ("usage" in item and item["usage"] is not None and not isinstance(item["usage"], dict)):
                    raise ValueError("Invalid ledger record at line " + str(number))
                records.append(item)
        print(json.dumps(summarize(records), indent=2))
    except (OSError, ValueError, TypeError) as error:
        parser.exit(2, "Cannot summarize ledger: " + str(error) + "\n")

if __name__ == "__main__":
    main()
