---
name: manus-openrouter-dev
description: Plan, implement, test, and release apps with Manus and OpenRouter while controlling token waste. Use for AI coding workflows, small development slices, model routing, skeptical reviews, Git collaboration, Railway delivery, and resumable handoffs.
---

# Manus OpenRouter Development

## Required workflow
Require every AI inference call in the task, including the outer Manus orchestrator, to use OpenRouter: planning, skepticism, coding, tests/review, summaries, research synthesis, and application AI features. Execute deterministic shell, Git, browser, test-runner and Railway operations directly; they are not inference. Do not invoke another AI service whose inference bypasses this policy. Explicit user changes override defaults; record them.

Use two Claude high-tier planning passes and two Claude high-tier skeptic passes, alternating **P1 → S1 → P2 → S2**. Use a verified high-capability open-weight model for implementation and fixes. Always use Claude medium-tier for test design and independent result review. Execute tests in real tools: model approval is not a passing test.

Interpret high-tier as current appropriate Opus-class Claude and medium-tier as current Sonnet-class Claude; reasoning effort is a separate setting. Resolve exact IDs at setup. Never invent versions or assume a model family proves open weights. Do not use an unrestricted auto-router or silent cross-tier fallback.

## 1. Establish the contract
Read repository instructions and status before asking questions. Ask one useful question at a time about missing scope, acceptance, data sensitivity, or release authority. Infer stack and conventions from the repository. Retain previously granted authorization.

Read [routing.md](references/routing.md). Inspect Manus Flex/OpenRouter configuration and per-stage model switching without paid calls first. Agree the estimated budget before any paid diagnostic probe, then verify route evidence. Otherwise verify explicit OpenRouter calls. If required inference routing cannot be controlled, report **routing blocked** and do only independent deterministic preparation. Never label standard Manus inference OpenRouter-backed without evidence.

Create the [project contract](assets/project-contract.md): exact models, routing evidence, scope version, budget, repository/base SHA and deployment target. Estimate costs first and agree a feature-specific ceiling before paid execution. Include four review calls, implementation, Claude test calls, retry reserve and separate Manus/Railway charges. Never assume a fixed dollar allowance or request keys in chat.

## 2. Plan and challenge in four stages
Use [review-prompts.md](references/review-prompts.md). Execute real calls to configured high-tier Claude through OpenRouter; do not role-play multiple model calls.

| Stage | Deliverable | Exit condition |
| --- | --- | --- |
| P1 | Requirements, alternatives, minimal architecture, risks, slices, tests, estimate | Acceptance criterion for every requirement |
| S1 | Independent objections, evidence, severity, counterexamples, proposed checks | Blocking assumptions explicit |
| P2 | Revised plan and disposition of every S1 finding | Implementable slices, budget and release strategy |
| S2 | Adversarial check against original requirements and P2 | No unresolved critical/high blockers |

Give skeptics original requirements and raw evidence plus the plan, in separate contexts. Do not coach approval. Record request IDs, models, scope version and artifact paths. P2 addresses S1, not a redundant brainstorm. If S2 blocks, resolve that blocker before dependent implementation; label additional corrective reviews explicitly.

Run all four stages once per agreed feature scope, including small tasks with short outputs. Do not repeat them for every already-approved slice. Restart on material requirement, architecture, security-boundary or migration-strategy change; ordinary fixes remain within scope.

## 3. Implement small vertical slices
Use [slice.md](assets/slice.md). Each slice delivers one testable behavior, with file boundaries, dependencies, acceptance checks and rollback. Prefer small reviewable diffs; 1–5 implementation files or roughly 300 changed lines is a split warning, not a hard correctness rule. Exclude generated files/lockfiles when assessing size.

Use the high-capability open-weight developer through OpenRouter with only relevant contract, slice, interfaces, files and failure evidence. Reuse repository conventions and dependencies. Avoid speculative abstractions and unrelated cleanup. Validate inputs, authorize on the server, protect tenant boundaries, handle timeouts, and make retried side effects idempotent where needed.

Keep one writer per slice by default. Parallelize only independent work with clear file ownership and separate branches/worktrees. Never use delegation merely to create activity.

## 4. Test independently, repair within bounds
Have Claude medium derive tests from requirements before reading the developer's success claims. Then supply patch/source for coverage review. Execute meaningful checks using [testing.md](references/testing.md). Record command, environment, exit code, SHA/diff identity and evidence paths. Claude medium reviews actual results and residual risks. Distinguish passed, failed, not run and blocked. Never weaken tests to manufacture a pass.

Allow two repair attempts per distinct failure by default. Each needs a new hypothesis and observable change. On repeated failure, stop, shrink the slice or obtain targeted high-tier diagnosis through OpenRouter; preserve the medium test gate and open-weight implementation role. Bound transient transport retries separately and count their cost.

## 5. Preserve Git and Railway integrity
Read [git-railway.md](references/git-railway.md) before committing, PRs or deployment. Preserve others' work and stage only owned paths. Require checks for the exact release SHA. Resolve Railway workspace/project/environment/service and actual source branch before mutation. Verify staging before an authorized production release. A queued build is not a successful deployment.

## 6. Control context, costs and resumability
Read [efficiency.md](references/efficiency.md). Keep current state short and detailed evidence on disk. Search before reading, bound logs, use deterministic scripts, preserve stable prompt prefixes, and load only relevant references. Do not discard acceptance criteria or failed hypotheses to save tokens.

Record each AI call in JSONL: role, requested/returned model, request ID, scope/slice, usage, cost or unknown, and retry reason. Exclude secrets, prompts and raw reasoning from routine logs. Use scripts/summarize_usage.py. Missing cost stays unknown, never zero. Enforce limits in the calling layer/provider controls; Markdown is not a billing or security boundary.

Update current status after accepted slices: verified SHA, completed/current/next tasks, failure hypotheses, evidence, spend and release state. Append meaningful detail to the project changelog without reloading it all. Resume by comparing the handoff with actual repository and deployment state.

## Completion
Report behavior, actual tests, unresolved risks, costs/unknowns, commit/PR and deployment status. Distinguish implemented, tested, pushed and deployed. Never invent model calls, tests, savings or deployments.

Read [research.md](references/research.md) only to audit provenance/four research passes or update the skill. Recheck changing platform/model details at setup; no scheduled update is implied.
