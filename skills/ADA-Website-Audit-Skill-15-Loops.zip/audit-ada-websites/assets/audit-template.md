# Website accessibility audit

## Scope and decision

- Website/source/build/deployment:
- Date/evaluator:
- Mode: audit-only / prepare-fixes / remediate
- Operator/jurisdiction and verified applicability:
- Required baseline and separate recommended target:
- Current legal sources and verification date:
- Audit depth: preliminary / representative / comprehensive
- Essential tasks, accounts/roles, languages:
- Exclusions, unknowns, blocked access and reasons:
- Release authorization and required signoff:

## Executive readout

Describe impact, confirmed barriers, work completed, remaining coverage and next steps. Do not add a compliance percentage or certificate.

## Environment

| OS/device | Browser/version | AT/version | Viewport/zoom/settings | Tools/versions | Build/time |
|---|---|---|---|---|---|

## Sample and state manifest

| ID | URL/template/role | State or complete task | Selection rationale/method | Tested method | Evidence | Gaps/reason |
|---|---|---|---|---|---|---|

## Criterion coverage

Create one row per relevant criterion/version using references/criterion-matrix.csv; add state-specific subrows as needed. Initialize to not-tested.

| Criterion/version/level | Applicable scope | Method | Outcome | Evidence | Evaluator/date | N/A or coverage-gap reason |
|---|---|---|---|---|---|---|

## Finding record

- Finding ID/title/root component and all known occurrence locations:
- Task/disability impact and severity:
- Classification: confirmed failure / suspected barrier / recommendation
- WCAG criterion/version/level and primary source:
- Prerequisites and exact reproduction:
- Actual and expected behavior:
- Evidence paths/raw result IDs:
- Fix/diff, owner, dependencies, target date:
- Lifecycle and reason for deferral if any:
- Retest acceptance, environment, date, actual result and evidence:

## Release and maintenance

- Completed fixes and retest coverage:
- Unresolved findings and blocked/not-tested items:
- Full-process regression results:
- Vendor/media/document ownership:
- Release gate result and accountable decisions:
- Accessibility statement/contact verification:
- Maintenance owner/cadence (proposed versus active):

## Status and changelog

| Date | Change or investigation | Evidence/result | Remaining work/owner |
|---|---|---|---|

## Exception and decision register

| Content/task | Technical outcome and evidence | Claimed legal provision | Supporting facts | Responsible decision-maker/date | Scope/expiry/review | Remaining access obligation and action |
|---|---|---|---|---|---|---|

Keep a failed technical criterion visible even where a responsible legal decision accepts an exception. Record archived-content facts individually. An evaluator cannot approve an exception by changing fail to pass.

## Evidence closure

For each resolved finding retain original evidence, tested build, exact retest procedure, observed result, evaluator/environment/date, and linked evidence. Tie scanner evidence to its manifest digest. Never overwrite the original failure. A screenshot alone cannot close a keyboard or AT finding. A changed selector or removed component requires checking the replacement task and adjacent states; absence from the latest scan is not closure. Record third-party fixes against the deployed version actually retested. Redact secrets, patient/payment data and authentication tokens from shared evidence.
