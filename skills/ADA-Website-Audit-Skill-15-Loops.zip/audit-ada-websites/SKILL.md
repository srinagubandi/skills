---
name: audit-ada-websites
description: Audit and remediate US website accessibility for ADA Title II and Title III with evidence-based WCAG testing. Use for ADA reviews, accessible UI/UX and frontend fixes, keyboard and screen reader testing, booking and checkout flows, third-party widgets, accessibility statements, and developer handoffs. Support audit-only, fix preparation, and authorized remediation. Route Section 508 separately when federal scope applies. Exclude SEO and legal certification.
---

# ADA Website Audit and Remediation

Operate as an agency accessibility director combining accessible design, engineering, content, and testing. Investigate barriers to independent use. Produce reproducible evidence and implement authorized fixes. Never promise a scanner, overlay, score, or this skill makes a site legally compliant.

## Scope first

1. Obtain URL/source and ask only for missing facts affecting scope: operator type, US jurisdiction, key tasks, authenticated areas, applicable contract/settlement, and desired mode. Reuse conversation answers.
2. Select audit-only, prepare-fixes, or remediate. If asked for all, audit and implement reversible source fixes where authorized source access exists; otherwise deliver patches and handoff. Follow existing production release authorization; source access alone is not release authorization.
3. Read [legal applicability](references/legal-applicability.md). Default to WCAG 2.2 A/AA as engineering target; maintain a separate 2.1 A/AA track for Title II. Apply stricter relevant contracts/orders. Do not count 2.2-only defects as 2.1 failures.
4. Verify current DOJ regulations/dates and W3C versions online before time-sensitive conclusions. Record URLs and verification date. Reference snapshot: 2026-11-05. If browsing fails, identify unverified legal facts and continue technical work.
5. Inventory routes, templates, components, languages, documents, media, embeds, external task domains, and dynamic states. Record build/deployment, account role, tools, OS/browser/AT versions, viewport, and zoom.
   If native mobile applications are present, inventory them and route to platform-specific testing; web scans or responsive checks cannot evaluate native app conformance.
6. Distinguish preliminary review, representative audit, and comprehensive evaluation. A homepage scan is preliminary. Use structured and recorded random sampling plus complete processes; expand when random results expose uncovered patterns. Do not invent a universal page quota or extrapolate sampled passes to every URL.

## Reference routing

Read [manual protocol](references/manual-testing.md) for every substantive audit. Use [criterion matrix](references/criterion-matrix.csv) to create a coverage ledger for every A/AA criterion in the target version. Filter by introduced version and removed_in; retain legacy 4.1.1 handling for a dated incorporated baseline as described in research-sources.md. Read linked W3C criteria and exceptions before disputed decisions; the matrix does not replace the standard.

Read [frequently missed tests](references/less-obvious-tests.md) and [complete journeys](references/complex-journeys.md) when planning coverage. Read [remediation](references/remediation.md) before fixes and [reporting/release](references/reporting-release.md) before conclusions. Read [scanner procedure](references/scanner.md) when running the optional Node/Playwright helper. Consult [research/sources](references/research-sources.md) for provenance and the fifteen research passes. Copy [audit template](assets/audit-template.md) into the client project; keep client evidence and status there, never inside this skill.

## Five execution passes

These execution passes are separate from the fifteen research passes used to create the skill. Repeat passes when new evidence or fixes change results.

### 1. Applicability and coverage

Record assumed legal profile and missing facts. Prioritize contact, booking, purchasing, account access, applications, benefits, documents, and support. Include mobile navigation, consent banners, chat, search, dialogs, loading/error/empty/success states, recovery, and external checkout. Inventory media/documents even if specialist testing is pending.

### 2. Automated and source inspection

Use available rendered-browser tools and maintained axe integration. Record exact versions, tags, URL/state, timestamp, exclusions, scan errors, and raw results. Scan opened/changed states as well as initial pages. Include selected-version A/AA tags and separately labeled best practices. Keep engine `incomplete` for human review. Deduplicate shared defects while preserving occurrence locations.

Inspect source/accessibility trees for semantics, names, labels, focus, hidden content, routes, and live regions. Neither source nor accessibility trees prove screen reader behavior. Mark inaccessible/cross-origin frames and untested shadow content as gaps. If tools are unavailable, continue scoped manual/source work and specify blocked tests. Never fabricate executions.

### 3. Manual and assistive technology testing

Execute the manual protocol for selected tasks/states. Cover keyboard, screen reader, low vision, speech/name alignment, touch, cognitive usability, media, and documents. Test enlargement, reflow, spacing, focus obscuring, and overlays. Record observed results. Viewport resizing does not prove actual browser zoom or mobile AT behavior.

Use NVDA with a supported Windows browser and VoiceOver/Safari where available; expand combinations for audience, contract, risk, or observed issues. Mark unavailable tests `not-tested`/`blocked` and hand them to humans. Include disabled-user usability evaluation for significant services when feasible; never impersonate a user test panel.

### 4. Prioritize and remediate

Record each finding's task/disability impact, reproduction, expected/actual behavior, evidence, criterion/version/level, normative source, severity, scope, owner, fix, and retest criteria. Separate confirmed failures, suspected barriers, and recommendations. Do not equate scanner impact with legal risk.

Prioritize blocked essential tasks/traps and shared root causes. Preserve content, functionality, security, and branding. Implement authorized reversible fixes or prepare exact diffs/tickets. Never hide useful controls from AT, add blanket ARIA, or use an overlay as a compliance fix. Escalate vendor defects with evidence and repair/replacement plans.

### 5. Retest and handoff

Repeat original failed procedures and adjacent states/templates/full flows. Rerun relevant automated/manual/AT checks. Separate `implemented-unverified` from `retested-fixed`. Restore testing settings and remove synthetic data where authorized.

Deliver executive readout, applicability note, page/state manifest, criterion ledger, findings, source changes/handoff, evidence, dependencies, and maintenance plan. Maintain dated status/changelog for sustained work. Use release gates in the reporting reference. Continue authorized preparation while unresolved essential-task failures or required signoff prevent release.

## Claim integrity

- Use `pass`, `fail`, `not-applicable`, `not-tested`, `blocked` for outcomes; require reasons for the latter three. Keep finding lifecycle separate.
- Never report a percentage of legal compliance. Tool/sample metrics must disclose their denominator and limits. Zero automated violations does not prove conformance.
- Do not say ADA certified, lawsuit-proof, fully compliant, or guaranteed accessible. Make scoped WCAG claims only with evidence for all applicable criteria and conformance requirements. Record residual usability issues separately.
- Separate enhanced/AAA/advisory practices from A/AA obligations: 44px targets, enhanced focus appearance, preferred font sizes, and reduced-motion conventions are not universal AA mandates.
- Never automatically approve exceptions, undue burden, fundamental alteration, religious/private-club exclusions, or alternate-version strategies. Route factual/legal decisions to the responsible owner/counsel.
- Do not place real orders, send messages, or create live bookings merely to test. Use authorized test systems/accounts; disclose an untested final step when no safe path exists.
- Exclude SEO unless separately requested. Evaluate titles, headings, alternatives, and timing/performance behavior for accessibility.

