import fs from 'node:fs/promises';
import path from 'node:path';
import { createRequire } from 'node:module';
import { createHash } from 'node:crypto';
import { chromium } from 'playwright';
import AxeBuilder from '@axe-core/playwright';

async function main() {
// Explicit manifest only: no crawling, form submission, or arbitrary JS actions.
// Review each URL and non-transactional disclosure selector before execution.
const [manifestFile, outputDirectory] = process.argv.slice(2);
if (!manifestFile || !outputDirectory) {
  console.error('Usage: node scan.mjs manifest.json output-directory');
  process.exit(2);
}
const manifestText = await fs.readFile(manifestFile, 'utf8');
const manifest = JSON.parse(manifestText);
if (!Array.isArray(manifest.pages) || !manifest.pages.length) throw Error('pages must be nonempty');
const baseline = manifest.baseline ?? '2.2';
if (!['2.0','2.1','2.2'].includes(baseline)) throw Error('Unsupported WCAG baseline');
const tags = ['wcag2a','wcag2aa'];
if (baseline !== '2.0') tags.push('wcag21a','wcag21aa');
if (baseline === '2.2') tags.push('wcag22a','wcag22aa');
const ids = new Set();
for (const item of manifest.pages) {
  if (typeof item.id !== 'string' || !/^[a-z0-9-]+$/.test(item.id) || ids.has(item.id)) throw Error('Page IDs must be unique lowercase slugs');
  ids.add(item.id);
  if (!['http:','https:'].includes(new URL(item.url).protocol)) throw Error('HTTP(S) URLs required');
  if (typeof item.readySelector !== 'string' || !item.readySelector.trim()) throw Error('A meaningful readySelector is required');
  if (item.expectedUrl && !['http:','https:'].includes(new URL(item.expectedUrl).protocol)) throw Error('HTTP(S) expectedUrl required');
  if (item.openDisclosure && manifest.safeDisclosuresReviewed !== true) throw Error('Review disclosure actions before execution');
  if (item.openDisclosure && (!item.state || item.state === 'initial' || !item.stateReadySelector)) throw Error('Disclosure needs an explicit changed state and stateReadySelector');
}
await fs.mkdir(outputDirectory, { recursive: true });
const output = await fs.mkdtemp(path.join(path.resolve(outputDirectory), 'ada-scan-'));
const require = createRequire(import.meta.url);
const pkgVersion = async name => {
  let directory = path.dirname(require.resolve(name));
  while (true) {
    try {
      const pkg = JSON.parse(await fs.readFile(path.join(directory, 'package.json'), 'utf8'));
      if (pkg.name === name) return pkg.version;
    } catch (error) { if (error.code !== 'ENOENT') throw error; }
    const parent = path.dirname(directory);
    if (parent === directory) throw Error('Cannot locate package metadata for ' + name);
    directory = parent;
  }
};
const summary = {
  started: new Date().toISOString(), baseline, tags,
  manifestSha256: createHash('sha256').update(manifestText).digest('hex'),
  versions: { playwright: await pkgVersion('playwright'), axeIntegration: await pkgVersion('@axe-core/playwright') },
  limitation: 'Automated selected-state review only. No legal compliance or full WCAG conformance conclusion. Manual and AT evaluation required.',
  pages: []
};
const launch = { headless: true };
if (process.env.ADA_BROWSER_EXECUTABLE) launch.executablePath = process.env.ADA_BROWSER_EXECUTABLE;
let browser;
try {
  browser = await chromium.launch(launch);
  summary.versions.browser = browser.version();
  for (const item of manifest.pages) {
    let context;
    const record = { id: item.id, requestedUrl: item.url, expectedUrl: new URL(item.expectedUrl ?? item.url).href, readySelector: item.readySelector, stateReadySelector: item.stateReadySelector, state: item.state ?? 'initial', status: 'scan-error', manualOutcome: 'not-tested' };
    summary.pages.push(record);
    try {
      context = await browser.newContext({ viewport: item.viewport ?? { width: 1280, height: 800 } });
      const page = await context.newPage();
      const response = await page.goto(item.url, { waitUntil: 'domcontentloaded', timeout: 30000 });
      record.url = page.url();
      record.httpStatus = response?.status();
      if (record.httpStatus >= 400) throw Error('HTTP error ' + record.httpStatus);
      if (item.readySelector) await page.locator(item.readySelector).waitFor({ state: 'visible', timeout: 15000 });
      if (page.url() !== record.expectedUrl) throw Error('Unexpected final URL: ' + page.url());
      if (item.openDisclosure) {
        const control = page.locator(item.openDisclosure);
        const tag = await control.evaluate(el => el.tagName.toLowerCase());
        const type = await control.getAttribute('type');
        const expanded = await control.getAttribute('aria-expanded');
        if (tag !== 'button' || type !== 'button' || expanded !== 'false') {
          throw Error('Disclosure must be an explicit non-submit button with aria-expanded=false; use task-specific reviewed tests for other interactions');
        }
        await control.click();
        await control.and(page.locator('[aria-expanded="true"]')).waitFor({ state: 'visible', timeout: 15000 });
        if (!item.stateReadySelector) throw Error('Opened state needs stateReadySelector');
        await page.locator(item.stateReadySelector).waitFor({ state: 'visible', timeout: 15000 });
      }
      if (page.url() !== record.expectedUrl) throw Error('Unexpected URL after state transition: ' + page.url());
      const results = await new AxeBuilder({ page }).withTags(tags).analyze();
      const rawFile = item.id + '.axe.json';
      await fs.writeFile(path.join(output, rawFile), JSON.stringify(results, null, 2));
      record.status = 'scanned';
      record.timestamp = new Date().toISOString();
      record.viewport = page.viewportSize();
      record.rawFile = rawFile;
      record.axeVersion = results.testEngine.version;
      record.violations = results.violations.length;
      record.incomplete = results.incomplete.length;
      record.frames = await page.locator('iframe').count();
      record.manualOutcome = 'not-tested';
      record.frameCoverage = 'Review raw frame errors/incomplete and verify frame tasks manually; frame presence does not establish coverage';
    } catch (error) {
      record.error = error.message;
    } finally {
      await context?.close();
    }
  }
} catch (error) {
  summary.fatalError = error.message;
} finally {
  await browser?.close();
  summary.finished = new Date().toISOString();
  await fs.writeFile(path.join(output, 'summary.json'), JSON.stringify(summary, null, 2));
  console.log(output);
}
// Exit 0 means scan execution finished, never accessibility conformance.
process.exitCode = summary.fatalError || summary.pages.some(p => p.status !== 'scanned') ? 2
  : summary.pages.some(p => p.violations || p.incomplete) ? 1 : 0;
}
main().catch(error => { console.error(error.message); process.exitCode = 2; });
