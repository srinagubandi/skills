# Manual evaluation protocol

## Sampling and setup

Use the [WCAG-EM 2.0 procedure](https://www.w3.org/TR/WCAG-EM/) to define product boundaries, representative samples, complete processes, and reporting. Record random selection method/seed and selected URLs. Include shared templates, high-impact tasks, unusual content and authenticated roles. Expand the sample if random pages expose new components. Preserve all URLs and states that were tested, skipped, redirected, or inaccessible.

Record OS, browser, screen reader/version, device, viewport, zoom, user settings, build, role, time, and test data. Avoid personal/patient information in screenshots/logs. Use synthetic accounts and test modes. Inspect essential flows through completion only where safe and authorized.

## Keyboard procedure

Start from a fresh page with mouse set aside. Use Tab/Shift+Tab, Enter, Space, arrows, Escape, and documented widget keys. Verify bypass navigation, logical focus, visible focus, reaching/activating functions, and escaping components. Test sticky elements and consent/chat overlays while tabbing. Reopen dialogs repeatedly and test return focus after closing, cancellation, validation, and component removal.

Use native button/link behavior and appropriate APG conventions as implementation guidance. A deviation from a convention is not automatically a 2.1.1 failure if functionality is keyboard operable; identify the actual failed requirement. Do not label correct modal containment as a trap when users can dismiss it.

Authority: [Keyboard 2.1.1](https://www.w3.org/WAI/WCAG22/Understanding/keyboard.html), [modal dialog pattern](https://www.w3.org/WAI/ARIA/apg/patterns/dialog-modal/).

## Screen reader tasks

Read title, page language, landmarks, headings, lists, tables, image purposes, controls and errors. Navigate both reading/browse mode and interaction/focus mode. Complete primary tasks and recovery paths. Verify name/role/state/value, expanded/collapsed changes, selection, invalid/required states, and status announcements. Check hidden backgrounds in dialogs and hidden duplicate mobile navigation.

For NVDA: use heading/landmark/control navigation, Tab, and NVDA+Space when appropriate; record speech output or transcript as evidence. Verify commands in the [NVDA documentation](https://api.nvaccess.org/releases/2026.2/documentation/en/keyCommands.html) for the installed version. For iOS VoiceOver: use rotor headings/links/form controls and swipe/touch navigation; consult [Apple's guide](https://support.apple.com/en-euro/guide/iphone/iphe4ee74be8/ios). Do not treat AI image recognition or browser reader modes as evidence that the underlying page is accessible.

Test status messages without forcing focus to every notification. Record whether AT announces loading, results counts, errors, cart updates, and success once at the appropriate urgency. Do not make an entire chat transcript an assertive live region. [Status messages 4.1.3](https://www.w3.org/WAI/WCAG22/Understanding/status-messages.html).

## Low vision and visual presentation

| Test | Procedure and acceptance |
|---|---|
| Text contrast | Measure rendered foreground/background, including states and overlays: 4.5:1 normal; 3:1 large (18pt/24px regular or 14pt/about 18.67px bold). Apply defined exceptions; do not round failures upward. Check gradients/images at worst-case areas. |
| Non-text contrast | Measure 3:1 against adjacent colors for visual information needed to identify active controls/states and meaningful graphics; not every decorative border. Inactive/unmodified UA controls have exceptions. |
| Enlargement | Test text scaling up to 200% without loss; include intermediate zoom where defects appear. Record method; mobile layout alone does not prove enlarged text works. |
| Reflow | Test vertical content at 320 CSS px equivalent (e.g. 1280-wide browser at 400% zoom); horizontal content at 256 CSS px height equivalent. Except genuinely necessary two-dimensional regions, not whole pages by convenience. |
| Spacing | Override line height 1.5, paragraph following space 2em, letter spacing .12em, word spacing .16em together; inspect clipping/overlap/lost functions. These need not be default design values. Apply relevant language exceptions. |
| Color | Identify errors, selection, charts, links, and required states without relying only on color. |
| Focus obscuring | Check sticky header/footer, cookie consent, chat, and drawers. 2.4.11 AA prohibits entirely obscured focused components, subject to its notes; fully unobscured is enhanced AAA. |
| Hover/focus additions | Check tooltips/popovers for dismissibility without moving focus/pointer where required, hoverability, and persistence; assess criterion exceptions. |

Authorities: [contrast](https://www.w3.org/WAI/WCAG22/Understanding/contrast-minimum.html), [non-text contrast](https://www.w3.org/WAI/WCAG22/Understanding/non-text-contrast.html), [resize](https://www.w3.org/WAI/WCAG22/Understanding/resize-text.html), [reflow](https://www.w3.org/WAI/WCAG22/Understanding/reflow.html), [spacing](https://www.w3.org/WAI/WCAG22/Understanding/text-spacing.html), [obscuring](https://www.w3.org/WAI/WCAG22/Understanding/focus-not-obscured-minimum), [hover/focus](https://www.w3.org/WAI/WCAG22/Understanding/content-on-hover-or-focus.html).

## Forms, authentication, and transactions

Test blank, invalid, valid, loading, server error, and success paths. Check persistent labels/instructions, programmatic associations, group names, input purpose, error identification/correction, preserved data, focus, and status output. A placeholder is not the label strategy. Avoid triggering real email/SMS or booking finalization without authorization.

Test password managers, paste, OTP entry/autofill, recovery, MFA, conditional challenges, and accessible alternatives. 3.3.8 AA permits specified alternatives/assistance and exceptions; a CAPTCHA's mere presence is not proof of failure. Transcription-only OTP without assistance can be a barrier. Test every authentication step, not just the password screen.

For a repeated entry in the same process, verify automatic population or selectable prior information unless essential/security/invalid-data exceptions apply. Browser autocomplete alone does not establish 3.3.7 compliance. For applicable financial/legal/data submissions, verify reversal, input checking/correction, or review/confirmation. Test time limits and warnings against 2.2.1, including its stated exceptions.

Sources: [validation](https://www.w3.org/WAI/tutorials/forms/validation/), [authentication](https://www.w3.org/WAI/WCAG22/Understanding/accessible-authentication-minimum), [redundant entry](https://www.w3.org/WAI/WCAG22/Understanding/redundant-entry.html), [error prevention](https://www.w3.org/WAI/WCAG22/Understanding/error-prevention-legal-financial-data.html), [timing](https://www.w3.org/WAI/WCAG22/Understanding/timing-adjustable.html).

## Touch, speech, motion, and cognitive usability

Check portrait/landscape, screen reader touch navigation, pointer cancellation, non-path-based gesture alternatives, and visible-label/name alignment for speech input. At 2.2 AA assess 24x24 CSS px targets OR the criterion's spacing/equivalent/inline/UA/essential exceptions; recommend 44x44 for important touch controls separately. Dragging needs a single-pointer non-drag alternative unless excepted; keyboard support alone does not satisfy 2.5.7.

Inspect animation/autoplay, pause controls, flashing, and time-dependent content. Under 2.2.2, automatically moving content lasting over five seconds alongside other content needs pause/stop/hide unless essential; auto-updating has a separate rule without that five-second threshold. Honor reduced motion as a design recommendation and inspect exact criteria before claiming an AA failure. Do not use a global animation kill switch that breaks functional events.

Check plain instructions, predictable actions, recovery, and consistent help. Consistent Help 3.2.6 governs repeated help mechanisms' relative order; it does not mandate adding a help widget to every page.

## Images, media, documents, and vendors

Inspect image purpose in context. Decorative/redundant images generally need empty alternatives; functional images name the action/destination; complex graphics need an equivalent explanation/data. Never manufacture unverified image descriptions or stuff alt text with keywords. [W3C image decision tree](https://www.w3.org/WAI/tutorials/images/decision-tree/).

Review captions for accuracy, timing, speakers, and meaningful sounds. At AA assess audio description for important visual information in prerecorded synchronized media; an existing complete audio track may suffice, while a transcript alone does not generally satisfy 1.2.5. Assess live/prerecorded and audio/video-only cases separately. Test accessible media controls and pause behavior. Sources: [media planning](https://www.w3.org/WAI/media/av/), [captions](https://www.w3.org/WAI/WCAG22/Understanding/captions-prerecorded.html), [description](https://www.w3.org/WAI/WCAG22/Understanding/audio-description-prerecorded.html).

Inventory PDFs/Office files; test tags, headings, language/title, reading/tab order, real text/OCR quality, tables, alternatives, forms and keyboard/AT use with appropriate document tooling. OCR alone is not remediation. [PDF reading order](https://www.w3.org/WAI/WCAG21/Techniques/pdf/PDF3), [GSA document testing](https://www.section508.gov/test/documents/).

Include vendor scheduling/payment portals, maps, CAPTCHA, consent management, accessibility widgets, chat, iframes, and embedded media. If a frame cannot be inspected automatically, test the actual task manually or record blocked coverage. Vendor marketing/VPAT is supporting evidence, not a substitute for testing the deployed integration.
