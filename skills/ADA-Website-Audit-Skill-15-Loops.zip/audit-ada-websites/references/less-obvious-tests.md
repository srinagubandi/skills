# Frequently missed manual requirements

Use alongside the main manual protocol and criterion matrix. Link every test to the exact version and criterion; mark applicability, observed outcome and evidence rather than checking a topic off because it was mentioned. These are targeted additions from research pass 12.

| Criterion | Test procedure | Decision boundary and evidence |
|---|---|---|
| 1.3.3 Sensory instructions | Read instructions without depending on color, shape, sound or spatial position; locate the named controls using reading order/AT. | Add semantic identifying information where the instruction relies solely on a sensory cue. Unambiguous “below” matching reading order is not automatically a failure. |
| 1.3.4 Orientation | Operate key tasks with the device held in either orientation; inspect application-imposed rotation messages/locks. | Distinguish an author restriction from the user's OS orientation setting. Record any claimed essential exception. A screenshot at a narrow width is not this test. |
| 1.3.5 Input purpose | Inventory fields about the current user that match the defined input-purpose taxonomy; inspect programmatic purpose, e.g. appropriate autocomplete tokens. | A generic email type can describe data format without identifying whose email is expected. Not every search/filter field needs a personal-data autocomplete token. |
| 1.4.2 Audio | Check automatic sound lasting over three seconds, including embeds; find pause/stop or independent volume control using keyboard/AT. | System-wide mute can silence the screen reader too and does not establish the required control. Record autoplay conditions and timing. |
| 2.1.4 Character shortcuts | Inspect documented shortcuts/event handling; try printable-character shortcuts and sequences outside their intended component focus. | Verify disable, remap to include a non-printable key, or focus-only activation. Shift used to generate a printable symbol does not automatically exempt it. |
| 2.3.1 Flashing | Inventory animation/video/GIF effects; inspect suspicious assets with appropriate flash-analysis expertise/tooling at relevant presentation size. | Check frequency OR general/red-flash thresholds, not merely whether animation exists. Do not expose photosensitive testers to suspected hazardous content to prove a failure. Record blocked specialist analysis instead of guessing. |
| 2.4.5 Multiple ways | Identify the set of pages and demonstrate distinct usable routes to relevant pages, such as navigation and search/site map. | Process steps/results have an exception. A search box is one possible method, not mandatory on every website. |
| 2.5.2 Pointer cancellation | In a safe fixture/test environment, press, move away and release; inspect whether functions commit on press and whether abort/undo/reversal exists. | Evaluate the criterion's permitted alternatives and essential down-event exception. Do not make real payments to test cancellation. |
| 2.5.4 Motion | Identify shake/tilt/camera-gesture input; operate the same function with conventional UI and disable motion response. | Apply supported-interface/essential exceptions. This is not a prohibition on animations or ordinary finger movement. |
| 3.1.2 Language changes | Review meaningful foreign-language passages against markup and AT pronunciation; verify the language tag actually matches the passage. | Account for proper names, technical terms, indeterminate language and assimilated words; do not flag every borrowed word. |
| 3.2.1 Focus | Tab and programmatically focus relevant controls without activating them; record navigation, window changes or unsolicited focus relocation. | Receiving focus must not itself change context. Showing additional inline content is not automatically a context change. |
| 3.2.2 Input | Change select/checkbox/text values while testing error and dependent-field paths; inspect any prior notice of context changes. | A change in a control's setting cannot unexpectedly change context without prior advice. Activating a submit button is not the same as changing an input's setting. |

Primary W3C references, reviewed 2026-11-05:

- [Sensory characteristics](https://www.w3.org/WAI/WCAG22/Understanding/sensory-characteristics.html)
- [Orientation](https://www.w3.org/WAI/WCAG22/Understanding/orientation.html)
- [Input purpose](https://www.w3.org/WAI/WCAG22/Understanding/identify-input-purpose.html)
- [Audio control](https://www.w3.org/WAI/WCAG22/Understanding/audio-control.html)
- [Character shortcuts](https://www.w3.org/WAI/WCAG22/Understanding/character-key-shortcuts.html)
- [Flash thresholds](https://www.w3.org/WAI/WCAG22/Understanding/three-flashes-or-below-threshold.html)
- [Multiple ways](https://www.w3.org/WAI/WCAG22/Understanding/multiple-ways.html)
- [Pointer cancellation](https://www.w3.org/WAI/WCAG22/Understanding/pointer-cancellation.html)
- [Motion actuation](https://www.w3.org/WAI/WCAG22/Understanding/motion-actuation.html)
- [Language of parts](https://www.w3.org/WAI/WCAG22/Understanding/language-of-parts.html)
- [On focus](https://www.w3.org/WAI/WCAG22/Understanding/on-focus.html)
- [On input](https://www.w3.org/WAI/WCAG22/Understanding/on-input.html)

## Cross-check before an all-criteria conclusion

For every applicable matrix row, link the tested page/state and a repeatable procedure to the evidence. Use the main protocol plus the criterion's normative text for topics not detailed here. A group-level note such as “forms checked” cannot close every form-related criterion. Likewise a single screen reader pass does not establish every keyboard, visual, speech or touch requirement.
