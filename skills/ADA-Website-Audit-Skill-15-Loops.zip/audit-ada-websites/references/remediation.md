# Accessible design and engineering playbook

## Repair the source and define acceptance

For each change record the affected component/template, current behavior, proposed behavior, applicable criterion, regression risk, and user-level acceptance test. Use the project's existing framework and style system. Fix root causes in shared components before patching individual pages. Do not sacrifice functionality to make automated findings disappear.

Prefer semantic HTML. ARIA describes semantics but does not provide interaction; custom roles require corresponding behavior. Validate name calculation when adding labels, especially overrides of visible text. Do not make every container focusable or use positive tabindex to rearrange a broken DOM order. [APG principles](https://www.w3.org/WAI/ARIA/apg/practices/read-me-first/).

## Component decisions

| Component | Recommended repair | Acceptance evidence |
|---|---|---|
| Action/navigation | Use button for an action; anchor with href for navigation; provide clear name | Operable with expected input; AT exposes actual role/name; visible label is contained in accessible name |
| Page structure | Represent real headings, regions, lists and tables in markup; meaningful title/lang; bypass repeated content | Reading order and heading/landmark navigation match information structure |
| Navigation disclosure | Use a button with accurate expanded state and controlled visibility; keep hidden links out of sequential focus | Keyboard/touch open/close works; links remain navigable; state agrees with display |
| Dialog/drawer | Prefer native dialog where suitable; name it; choose meaningful initial focus; constrain true modal interaction; restore logical focus | Open/read/operate/close/reopen with keyboard and AT; background inert only while modal |
| Tabs | Use linked tablist/tab/tabpanel roles with selection and focus model; choose manual activation for slow-loading content | Arrow/Tab flow, selection and associated panel remain synchronized |
| Combobox/autocomplete | Prefer native select when it meets needs; otherwise implement the full chosen APG interaction | Suggestions, selection, active option, dismissal and text editing work with supported AT |
| Form field | Use a persistent associated label, helpful instructions and correct input semantics; group related controls | Name/instructions/required state understood without placeholder/color reliance |
| Error handling | Associate inline errors and provide navigable summary where helpful; preserve entered data | Error becomes discoverable/announced and correction succeeds without starting over |
| Async feedback | Provide an appropriately scoped status region or deliberate focus transition | Loading/results/success announced without repeated interruption or unsolicited focus jumps |
| Image/icon | Apply contextual alternative; hide decorative icons appropriately; name icon-only controls | Task and information survive without seeing the graphic; no redundant speech |
| Data display | Use actual headers/captions/associations and alternatives for charts | A row/cell can be understood with AT; information not conveyed by color alone |
| Responsive layout | Use flexible dimensions, wrapping, resilient grid/flex children, scrollable exceptions only where needed | No lost content/functions under enlargement/reflow/spacing tests |
| Consent/chat widgets | Correct stacking, name/state, focus/close behavior and trigger size | Do not obscure focused controls or block essential tasks after dismissal |

Pattern sources: [disclosure](https://www.w3.org/WAI/ARIA/apg/patterns/disclosure/), [dialog](https://www.w3.org/WAI/ARIA/apg/patterns/dialog-modal/), [tabs](https://www.w3.org/WAI/ARIA/apg/patterns/tabs/), [combobox](https://www.w3.org/WAI/ARIA/apg/patterns/combobox/), [form notifications](https://www.w3.org/WAI/tutorials/forms/notifications/), [headings](https://www.w3.org/WAI/tutorials/page-structure/headings/).

## Framework and CSS traps to inspect

- Keep stable unique component IDs and correct label references across repeated items, portals and hydration. Classify actual semantic/name failures rather than calling every duplicate ID an automatic WCAG failure.
- Test client-side navigation title changes, focus landing, history/back behavior, announcements and pending states. Avoid an announce-everything router implementation.
- Inspect CSS visual reordering versus DOM/reading order, clipped focus rings, focusable hidden menus, inert/aria-hidden ancestors, and overflow clipping. `aria-hidden` does not remove keyboard focus.
- Match JS-controlled open/closed state to CSS visibility and accessibility state. Validate transitions with reduced motion; do not rely on animation end events that may disappear.
- Use robust focus indicators across light/dark/image backgrounds and forced colors. Do not suppress outline without an effective replacement. Treat enhanced focus geometry as an optional stronger target rather than mislabeling it AA.
- Avoid fixed-height text cards and clipped bios that lose information under zoom or spacing. Offer accessible expansion when truncation is appropriate; an equal-height design is not a reason to discard content.
- Check loading/skeleton states, icon fonts failing to load, late content, network errors, and duplicated responsive content. Keep status text outside visually decorative skeletons.
- Avoid disabling zoom, paste, password managers, or platform assistive features. Do not add security exceptions without evaluating their actual necessity and the criterion's scope.

## Invalid shortcuts

Reject blanket aria-label insertion, keyword alt text, hidden duplicate accessible pages, body-wide role=application, accessibility overlays as the completion strategy, removal of problematic functionality, and hiding known defects from scanners. Do not present a toll-free number as sufficient proof of equivalent web access.

An overlay can be evaluated as another component, but cannot replace source repair or human testing. The [FTC accessiBe order](https://www.ftc.gov/news-events/news/press-releases/2025/04/ftc-approves-final-order-requiring-accessibe-pay-1-million) addresses unsupported automated compliance claims; it does not establish that every accessibility feature or widget is unlawful.

## Supplier remediation

Create a vendor ticket containing the deployed URL/version, account role, affected task, actual steps, AT/browser versions, evidence, expected result, criterion, severity, and target date. Ask for a testable fixed version and retest the integration. Track replacement options and interim accessible service arrangements without calling them permanent legal substitutes. Do not mark a defect closed solely because a vendor supplied an ACR or promised a release.
