# Research provenance and refresh map

Reviewed 2026-11-05. Focus: US ADA websites, accessible UI/UX, engineering, and verification. SEO excluded by user instruction. Prefer operative government rules and W3C normative standards over supplier marketing. Supporting APG, tutorials and Understanding pages are informative; assess the normative success criterion before deciding an issue. Source publication dates differ from verification dates.

## Fifteen research and review passes

| Pass | Investigation | Result incorporated | Primary evidence |
|---|---|---|---|
| 1 | Legal applicability and dates | Separate Title II, Title III and federal procurement; April 2026 extension replaces stale deadlines | DOJ fact sheet; Federal Register 2026-07663; GSA applicability |
| 2 | Standard version and criterion coverage | Distinguish 2.1 legal track from 2.2 practice target; generate 55 current A/AA matrix entries; handle obsolete parsing separately | WCAG 2.2; parsing guidance; W3C FAQ |
| 3 | Audit design and evidentiary scope | Use structured/random sampling, complete processes and explicit limits; no homepage-wide compliance claim | WCAG-EM 2.0; WAI evaluation overview; conformance guidance |
| 4 | Visual and low-vision testing | Add contrast/zoom/reflow/spacing test conditions and exceptions; do not confuse design defaults with override tests | W3C criterion-specific Understanding pages |
| 5 | Interaction and authentication | Add non-drag pointer alternative, target-size exceptions, repeated entry, conditional authentication and focus handling | W3C 2.2-specific guidance; APG patterns |
| 6 | Enforcement and unsupported promises | Require actual remediation/evidence/ownership; distinguish case-specific settlements from universal rules; reject overlay guarantees | DOJ Fashion Nova; Springfield Clinic; Meijer; Robles; FTC accessiBe |
| 7 | Third parties, media and documents | Include deployed vendor processes, current service documents, captions/description and PDF reading order | DOJ small entity guide; WAI media/PDF guidance; GSA document testing |
| 8 | Assistive technology and reproducibility | Separate accessibility-tree/source review from real AT testing; use versioned environment records and human handoffs | NV Access docs; Apple VoiceOver guide; GSA Trusted Tester |
| 9 | Recent-change and technical sanity review | Incorporate July 2026 WCAG-EM 2.0; identify September WCAG 3 draft; verify runtime package availability; retain human evaluation limits | WAI news/update pages; WCAG 3 draft; Playwright and axe primary docs |
| 10 | Practical skill evaluation and revision | Validate structure, criterion inventory and references; exercise realistic audit requests with the actual skill; revise coverage/claim defects found | Local validation and forward-test evidence, summarized in the project status |
| 11 | Legal edge cases | Add dated incorporation, alternate-version limits, written decisions, minimal-impact distinctions and four archive conditions | eCFR 28 CFR 35.104 and 35.200-35.205; legal-applicability.md |
| 12 | Missed manual criteria | Add twelve explicit procedures for sensory cues, orientation, input purpose, audio, shortcuts, flash, navigation, motion, pointer cancellation, language and context changes | Twelve W3C Understanding pages linked in less-obvious-tests.md |
| 13 | Scanner reliability | Require readiness and expected final URL; await asynchronous disclosure state; reject incomplete action manifests; preserve manifest digest | Playwright navigation/hydration and locator API; ten synthetic regression scenarios |
| 14 | Complex service journeys | Add booking/calendar, payments/applications, recovery/MFA, consent/chat and search/upload states; distinguish authentication exceptions and actual AT evidence | W3C APG date picker and SC 3.3.8; complex-journeys.md |
| 15 | Evidence closure and adversarial review | Retain original failures, require behavioral retesting, separate exception decisions; evaluate clinic booking closure request | Audit template, independent forward test, structure/reference validation and scanner tests |

These passes are investigation/revision cycles, not fifteen full audits of a client website. No live client website was provided for testing this skill. A runnable audit still needs its URL/source and access to the appropriate tools and human testing.

## Legal and enforcement sources

- [DOJ Title II fact sheet](https://www.ada.gov/resources/2024-03-08-web-rule/) — technical scope and current deadline summary.
- [Federal Register 2026-07663](https://www.govinfo.gov/content/pkg/FR-2026-04-20/html/2026-07663.htm) — April 20, 2026 interim final rule.
- [DOJ small entity guide](https://www.ada.gov/resources/small-entity-compliance-guide/) — exceptions, vendors and continuing duties; read full rule for decisions.
- [DOJ web guidance](https://www.ada.gov/resources/web-guidance/) — business obligations and manual/automated checks; pre-2024 Title II discussion is not the current technical rule.
- [GSA applicability](https://www.section508.gov/blog/do-section-508-accessibility-standards-apply-to-mywebsite/) — federal scope and ADA distinction.
- [Access Board ICT standards](https://www.access-board.gov/ict/) — incorporated WCAG 2.0 and other ICT requirements.
- [DOJ Fashion Nova statement](https://www.justice.gov/opa/pr/department-justice-opposes-unfair-class-action-settlement-involving-accessibility-website) — February 2026 objection to vague relief without meaningful verification, not a new universal technical standard.
- [DOJ Springfield Clinic](https://www.justice.gov/crt/case/us-v-springfield-clinic-llc) — 2024 healthcare portal settlement, coordination, training and WCAG 2.1 AA commitments.
- [DOJ Meijer](https://www.justice.gov/crt/case/meijer-inc) — booking accessibility and independent access under a particular agreement.
- [Robles appellate opinion](https://cdn.ca9.uscourts.gov/datastore/opinions/2019/01/15/17-55504.pdf) — read holding and jurisdiction rather than generalizing from commentary.
- [FTC final accessiBe order](https://www.ftc.gov/news-events/news/press-releases/2025/04/ftc-approves-final-order-requiring-accessibe-pay-1-million) — substantiation of automated compliance representations.

## Standards and evaluation

- [WCAG 2.2](https://www.w3.org/TR/WCAG22/) — current Recommendation; includes A/AA/AAA, not all required for AA.
- [WCAG-EM 2.0](https://www.w3.org/TR/WCAG-EM/) — July 23, 2026 Group Note; evaluation methodology, not additional requirements.
- [WAI evaluation overview](https://www.w3.org/WAI/test-evaluate/) — need for knowledgeable human evaluation.
- [Conformance guidance](https://www.w3.org/WAI/WCAG22/Understanding/conformance.html) — full pages/processes, supported technologies and non-interference.
- [Parsing](https://www.w3.org/WAI/WCAG22/Understanding/parsing.html) and [WCAG FAQ](https://w3c.github.io/wai-website/standards-guidelines/wcag/faq/) — obsolete/removed 4.1.1. For a legally incorporated dated version, record its exact requirements and any relevant authority rather than silently rewriting the incorporation. Retain legacy coverage when needed; report functional semantic failures under applicable criteria.
- [WAI updates](https://www.w3.org/WAI/update/) and [WCAG 3 draft](https://www.w3.org/TR/wcag-3.0/) — recent developments; drafts are not adopted audit baselines.
- [GSA testing](https://www.section508.gov/test/) and [Trusted Tester](https://www.section508.gov/test/trusted-tester/) — repeatable testing and credential boundaries.
- [Playwright accessibility testing](https://playwright.dev/docs/accessibility-testing) and [axe-core](https://github.com/dequelabs/axe-core) — automated execution and limits; use alongside manual testing.

## Technical supporting sources

Use the criterion matrix for individual Understanding URLs. Additional primary references are linked next to their procedures in manual-testing.md and remediation.md: image purpose, captions/description, forms/notifications, modal/disclosure/tabs/combobox, PDF order, NVDA and VoiceOver.

## Refresh procedure

Before each audit: verify DOJ/Federal Register operative rules and deadlines; confirm relevant contracts/orders; verify W3C Recommendation/errata status and evaluation methodology; record installed tools/AT versions. Check recent 30–60-day government/WAI changes when updating the skill, while retaining foundational material where it remains authoritative. Revisit ambiguous findings through normative text and deployed behavior. Record changed advice, reasons and sources in the project status; update this skill only when explicitly asked. No recurring update has been scheduled by this skill.


