# Reporting, issue lifecycle, and release

## Evidence model

Maintain three linked records: page/state manifest, per-criterion coverage, and issue register. Preserve raw scan data separately from human-confirmed findings. A scan rule may map to more than one criterion; confirm actual applicability before classification. Group repeated defects by root cause but retain all affected locations and retest representatives plus changed variants.

For each criterion record version/level, applicable states, method, result, evidence IDs, evaluator/date, and reason for N/A or missing coverage. A single failing occurrence makes that criterion fail for that evaluated scope. Unchecked states cannot inherit a pass from a checked state. Default new ledger entries to `not-tested`.

Outcomes: `pass`, `fail`, `not-applicable`, `not-tested`, `blocked`.

Finding lifecycle: `open`, `planned`, `implemented-unverified`, `retested-fixed`, `reopened`, `deferred`. Deferral is not conformance; retain impact, owner, reason, and follow-up date. A test blocked by tool/access limitations is not an automatic website defect.

## Agency severity model

| Severity | Meaning | Handling |
|---|---|---|
| Critical | Essential task impossible or severe trapping/safety barrier | Immediate escalation; block affected release |
| High | Significant information/action unavailable to a disability group or repeated severe friction | Fix before affected release; retest full journey |
| Medium | Substantial localized barrier with a feasible workaround | Prioritize with owner/date; still a failure if criterion violated |
| Low | Limited impact defect | Track and fix; do not call optional if it violates an applicable criterion |
| Recommendation | Advisory/AAA/usability improvement without demonstrated target criterion failure | Separate improvement backlog |

Severity reflects user impact, reach, frequency, essentiality, and workaround—not a dollar estimate of legal liability. Criteria level and legal applicability are separate fields. Distinguish compliance obligations from proposed operational service levels.

## Required deliverables

1. Executive readout: operator/target, date/build, scope, highest-impact barriers, completed changes, and residual limitations.
2. Applicability note with verified primary sources and unresolved decisions.
3. Inventory/sample manifest: templates, selection method, random sample, roles, states, third-party boundaries, exclusions and reasons.
4. Criterion ledger and evidence-linked findings, with version-specific results and manual coverage.
5. Remediation plan/diffs: acceptance tests, component owner, priority, dependency and estimate clearly labeled if unverified.
6. Retest record: old/new behavior, procedures, environment, outcomes, regression findings, unresolved tests.
7. Dated status/changelog and maintenance ownership, especially for multi-session projects.

Use complete plain-language descriptions, real headings, accessible tables, descriptive links, and accessible exported documents. Avoid tiny screenshots as the sole evidence; include text reproduction. Redact secrets and personal data.

## Release gates

Confirm scope/version/source revision; no unresolved critical/high essential-task blockers for the affected release; changed components and full affected processes retested; no new material regressions; vendor/media/document work accounted for; manual/AT coverage completed where required by the agreed release criteria. Record residual risks and accountable owner decisions. Missing required manual tests remain unresolved even with a clean scan. Never imply lower-severity WCAG failures become conforming merely because an owner accepts release risk.

Prepare a reviewable change before any final release permission that is genuinely missing. Respect prior authorization; do not repeatedly request it. Keep audit/fix work progressing when deployment is outside scope.

## Conclusions and statements

Prefer: “The evaluated sample has the following confirmed WCAG 2.2 A/AA failures. These states and AT combinations remain untested.” After successful repair: “The listed findings were retested in the stated scope and environment.”

Do not convert an automated score, a sample audit, or code review into a blanket ADA conformance statement. WCAG conformance also considers full pages, complete processes, accessibility-supported technology and non-interference. Consult [W3C conformance guidance](https://www.w3.org/WAI/WCAG22/Understanding/conformance.html) before a claim; identify the exact scope/version/date and technologies relied on. Accessibility can still need usability improvement beyond criterion conformance.

Draft accessibility statements with honest current status, scope, testing date/method, known limitations, accessible contact channel, issue/request process and responsible owner. Do not invent certification, response guarantees, disabled-user testing, or a conformance claim. Have the owner verify the contact process before publication.

## Maintenance proposal

Recommend accessibility checks in component acceptance, relevant CI tests, content publishing, procurement, and major releases. Propose periodic manual task reviews and disabled-user feedback appropriate to risk. Define the actual owner and cadence in each project. Do not schedule automations or claim ongoing monitoring is active unless explicitly requested and created successfully.
