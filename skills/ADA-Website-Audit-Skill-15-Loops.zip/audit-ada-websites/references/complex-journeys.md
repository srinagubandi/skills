# Complete journey testing

Choose processes by client service and user impact. Record every state, account role, domain, integration and transition; a collection of clean page scans cannot establish a usable end-to-end task. The following are agency test designs, not extra WCAG requirements. Map observed barriers to the normative criterion before deciding failure.

| Journey | States and adverse conditions | Acceptance evidence |
|---|---|---|
| Appointment booking | Provider/service selection, calendar opening, month change, selected/unavailable dates, time zone, no slots, validation, review, confirmation, rescheduling | Complete keyboard and actual AT walkthrough; verify date names and selection, focus on opening/closing, understandable unavailable slots, retained values after errors. Use approved test booking infrastructure; stop and disclose an untested real confirmation step. |
| Checkout or application | Cart/options, address, review/correction, vendor handoff, declined payment, return/cancel, session expiry, duplicate submission prevention | Track each domain/frame and recovery route. Check error identification, review/correction appropriate to 3.3.4, focus and status announcements. Use test payment credentials and prevent real charges/submissions. |
| Account recovery and MFA | Login, wrong credentials, recovery link, expired link, password reset, OTP entry, resend, alternative authentication | Evaluate every authentication step, password-manager/paste support and accessible alternatives. A blocked paste action alone needs context: assess available assisting mechanisms and exceptions before declaring 3.3.8 failure. Never disable security as a remediation shortcut. |
| Consent and support overlays | First visit, reject/accept/preferences, revisit preferences, chat open/minimize, notification, nested dialog | Operate underlying essential tasks after each state. Check keyboard escape routes, meaningful focus order, focus restoration, visible focus, enlargement and whether controls obscure focused elements. Consent choices must remain operable without accepting unrelated services. |
| Search, tables and uploads | No results, loading, filter changes, sort, pagination/virtualization, upload progress/error/retry | Verify understandable labels and state changes with AT; ensure virtualized content does not silently disappear from navigation. Confirm upload errors identify the file/problem and preserve recoverable work. Do not announce every progress tick or move focus merely to announce status. |

## Calendar review

Inspect the deployed widget rather than copying an APG demonstration into production. For a dialog/grid design, test focus entry and return, date navigation, month/year changes, selected-date semantics and announcements. Test direct text entry if supplied, including format instructions and invalid dates. Native inputs and alternative designs need their own supported-device tests; the APG key map is not a universal WCAG mandate. Mobile AT support must be observed separately.

Primary pattern reference: [W3C date picker dialog](https://www.w3.org/WAI/ARIA/apg/patterns/dialog-modal/examples/datepicker-dialog/).

## Authentication decisions

WCAG 2.2 SC 3.3.8 addresses cognitive-function tests in authentication of existing users. Evaluate alternatives, assisting mechanisms and the object-recognition/personal-content exceptions. Record the actual working option at each step; do not infer that a password field or any CAPTCHA automatically fails. Distinguish AA minimum from more inclusive recommendations and AAA 3.3.9. Account creation is outside this criterion's stated focus but still needs other applicable accessibility checks.

Primary reference: [W3C accessible authentication minimum](https://www.w3.org/WAI/WCAG22/Understanding/accessible-authentication-minimum.html).

## Evidence and boundaries

For each transition record starting state, intended action, expected state, actual state, focus location, announcement observed with named AT, and evidence ID. DOM assertions are useful regression evidence but cannot be labeled as heard screen-reader output. HTTP 200, a visible shell, or a login page at the right domain does not prove intended content loaded. Use a page-specific readiness marker and expected final URL; even these guards require evaluator review. Treat unavailable accounts, opaque vendor frames and inaccessible test environments as coverage gaps with owners.

Readiness source: [Playwright navigation and hydration](https://playwright.dev/docs/navigations#hydration). Client-side rendering can continue after load, and visible controls can precede working event handlers. A failed interaction may indicate a readiness defect, not a confirmed accessibility criterion failure.
