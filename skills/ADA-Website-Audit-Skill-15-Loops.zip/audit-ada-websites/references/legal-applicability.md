# US applicability and claim boundaries

Snapshot verified 2026-11-05. Recheck authoritative regulations and dates at each audit. This reference supports technical scoping; do not present a legal opinion or certification.

| Operator/context | Audit track | Guardrail |
|---|---|---|
| State/local government, including covered public services | ADA Title II; WCAG 2.1 A/AA baseline plus separate 2.2 improvements | Include provided/contracted content and mobile apps; establish entity/population rather than guessing from traffic |
| Private public accommodation | ADA Title III; recommend WCAG 2.2 A/AA; inspect contracts/orders | DOJ maintains web accessibility obligations, but no uniform Title III web technical regulation was identified in this review |
| Federal agency ICT/federal procurement | Section 508 overlay, scoped to applicable ICT | Revised 508 incorporates WCAG 2.0 A/AA and other ICT requirements; 2.2 engineering target does not replace procurement requirements |
| Nonprofit | Determine actual operator/services and funding/contract facts | 501(c)(3) status does not itself establish exemption or technical standard |
| Healthcare/education/federally funded service | ADA track plus separate applicability inquiry | Flag possible Section 504/1557/state obligations; verify their current rules independently before conclusions |

## Title II dates

The April 20, 2026 interim final rule extends the technical-rule compliance date to April 26, 2027 for public entities with population 50,000 or more; April 26, 2028 for those below 50,000 and special district governments. Existing nondiscrimination/effective-communication obligations continue before these dates. Verify which population rule applies to a school district; do not classify every district as a special district.

Primary authority: [DOJ fact sheet](https://www.ada.gov/resources/2024-03-08-web-rule/) and [2026 Federal Register text](https://www.govinfo.gov/content/pkg/FR-2026-04-20/html/2026-07663.htm).

## Title II exceptions: fact checklist, never blanket exemptions

Evaluate archived content, preexisting conventional documents, unaffiliated third-party postings, individualized password-protected conventional documents, and preexisting social posts against every regulatory condition. Record facts and the responsible decision-maker. Current application/service documents may remain covered despite age. Contracted vendors are not automatically unaffiliated third parties. Password protection does not exclude an entire portal. Existing effective communication duties survive exceptions.

Require owner/counsel review for undue burden, fundamental alteration, equivalent facilitation, and restricted conforming alternate versions. Do not authorize a separate text-only site or phone-only service as a blanket substitute.

Authority: [DOJ small entity guide](https://www.ada.gov/resources/small-entity-compliance-guide/). Open the full rule linked there when an exception is material.

## Title II legal determinations versus technical results

Apply [28 CFR 35.200–35.205](https://www.ecfr.gov/current/title-28/chapter-I/part-35/subpart-H) to exception decisions. Section 35.200 incorporates the dated June 2018 WCAG 2.1 text; do not silently substitute later editorial interpretations for that legal incorporation.

Section 35.202 limits conforming alternate versions to technical or legal limitations preventing direct accessibility. Section 35.204 requires an undue-burden/fundamental-alteration decision by the entity head or designee, considering available program resources and supported by written reasons; other feasible accessibility action remains required. An agency developer cannot approve this merely because a fix exceeds their estimate.

Section 35.205 has a narrow minimal-impact provision assessed against equivalent timeliness, privacy, independence and ease of use. A low scanner severity or small violation count does not establish it. Preserve the technical WCAG failure even if an authorized legal determination concludes the regulatory provision is met. Track the provision, facts, evidence, decision-maker and date separately from the technical outcome.

Create an exception register per item, never per convenient file extension or vendor category. Keep unsupported exception requests unresolved while remediation planning continues.

For archives, record all four factual conditions in [35.104](https://www.ecfr.gov/current/title-28/chapter-I/part-35/subpart-A/section-35.104): eligible age of content or reproduced physical material, exclusive reference/research/recordkeeping use, no changes after archiving, and a clearly identified dedicated archive area. Moving a live service form into an archive folder does not establish these conditions.

## Title III: avoid jurisdiction overclaims

Do not repeat “all courts treat all websites as places of public accommodation.” Court approaches differ, including physical-location nexus questions for online services. Ask jurisdiction and physical/service relationship when relevant; review binding local authority for legal conclusions. Continue technical remediation despite unresolved legal scope.

[Robles v. Domino's, Ninth Circuit opinion](https://cdn.ca9.uscourts.gov/datastore/opinions/2019/01/15/17-55504.pdf) addressed a website/app connected to physical restaurants; it is not a nationwide holding that every standalone site is a public accommodation. [DOJ web guidance](https://www.ada.gov/resources/web-guidance/) states DOJ's enforcement position; its old Title II discussion must be read with the newer rule.

## Distinguish standards and evidence

Use WCAG 2.2 as recommended engineering baseline without silently changing Title II's incorporated version. WCAG 3 is a working draft, not the replacement legal baseline. Techniques/APG are informative ways to meet requirements, not compulsory code recipes. Accessibility usability recommendations may exceed WCAG.

Section 508 is separate from ADA and Section 503. Federal contractor status alone does not make every public marketing page federal ICT. Inspect procurement terms and actual use. An Accessibility Conformance Report using a VPAT template is a disclosure, not certification; do not claim Trusted Tester credentials without an actual certified evaluator.

Authorities: [Access Board ICT standards](https://www.access-board.gov/ict/), [GSA applicability](https://www.section508.gov/blog/do-section-508-accessibility-standards-apply-to-mywebsite/), [Trusted Tester](https://www.section508.gov/test/trusted-tester/).

## Maintenance

At every audit verify authoritative versions and operative deadlines, not search snippets alone. For a material legal dispute record law/regulation, date, jurisdiction, order/contract, and unresolved questions. If recent sources conflict with this snapshot, update the affected conclusion with evidence; never substitute a vendor blog for operative law. Do not create a recurring automation unless requested.
