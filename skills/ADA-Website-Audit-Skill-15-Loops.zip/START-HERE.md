# ADA Website Audit and Remediation — 15-pass package

This reusable agent skill covers US ADA Title II/III website accessibility,
accessible design, development, testing and remediation. Section 508 is a
separate applicability track. SEO is excluded.

## Use with an agent

Extract the ZIP and give your coding agent the audit-ada-websites/SKILL.md file.
For a platform supporting local skills, install the entire audit-ada-websites
folder using that platform's skill import instructions. Automatic installation
in ChatGPT has not been completed because authenticated access was unavailable.
The downloadable package is complete and independent of that installation.

Example request:
"Use audit-ada-websites to review https://YOUR-SITE. We are a private US clinic.
Audit the full booking process, including external vendors. Use WCAG 2.2 A/AA
as the engineering target, record untested items, and prepare source fixes and
an evidence-based report. Ask for missing jurisdiction/account/test details."

For a government client, identify the entity and population and retain its
separate WCAG 2.1 legal track. Confirm current law and relevant contracts.

## Included resources

- SKILL.md: scope, workflow, reference routing and claim boundaries.
- references/: legal applicability, full criterion matrix, manual procedures,
  frequently missed tests, complete journeys, remediation, release/reporting,
  scanner instructions and the fifteen-pass research/source ledger.
- assets/: audit report template and selected-state scan manifest.
- scripts/: optional Node/Playwright/axe helper with pinned dependency lock.
- agents/: skill display metadata.

Read references/scanner.md before running the optional helper. Node and a
compatible browser are required; dependencies and browser binaries are not
bundled. Copy the helper into a client tooling directory and use npm ci as
documented. Configure meaningful readiness selectors and explicit page states.

## Validation and limits

The skill structure and internal reference links were validated. Ten local
synthetic scanner scenarios passed, covering known violations, delayed opened
state, WCAG 2.1 tag isolation, HTTP errors, unsafe/invalid manifests, redirect
guards, missing readiness and missing content. An independent booking-case
exercise correctly retained coverage gaps and required actual behavioral retests.

Research was checked November 5, 2026; reverify time-sensitive rules at use.
Fifteen passes are research/revision cycles, not fifteen client audits.
No live client website or actual screen-reader session was tested in producing
this package. Automated scans do not establish ADA compliance or full WCAG
conformance. Manual and assistive-technology testing remain essential.
