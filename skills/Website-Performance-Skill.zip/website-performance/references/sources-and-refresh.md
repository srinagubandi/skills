# Evidence, freshness, and research refresh

## Package provenance

This package was reconstructed on 2026-11-12 after the earlier in-memory artifact could no longer be recovered. It preserves the retained workflow requirements and research conclusions, but is not a byte-for-byte recovery of the original four-file draft. The original detailed source ledger was not retained. Do not describe this reconstruction as a newly completed five-loop literature review or as independently live-tested on every platform. Its executable five-pass workflow is provided in SKILL.md.

The earlier conversation recorded research into web.dev/Chrome, framework/platform docs, public performance skills, search/AI crawler guidance, social metadata, and four text-only scenarios. Those notes are not a substitute for a reproducible source ledger. Re-open the relevant primary sources before relying on time-sensitive claims. No video is claimed as watched in this reconstructed package. No public skill code has been copied into this package.

## Primary reference starting points

The links below are source entry points, not a claim that each was freshly retrieved on the packaging date.

| Topic | Primary source |
|---|---|
| Core Web Vitals | https://web.dev/articles/vitals |
| LCP diagnosis | https://web.dev/articles/optimize-lcp |
| INP diagnosis | https://web.dev/articles/optimize-inp |
| CLS diagnosis | https://web.dev/articles/optimize-cls |
| Responsive images | https://web.dev/learn/images |
| Performance fundamentals | https://web.dev/learn/performance |
| Lighthouse | https://developer.chrome.com/docs/lighthouse |
| Chrome performance traces | https://developer.chrome.com/docs/devtools/performance |
| CrUX | https://developer.chrome.com/docs/crux |
| PageSpeed Insights | https://developers.google.com/speed/docs/insights/v5/about |
| Google JavaScript SEO | https://developers.google.com/search/docs/crawling-indexing/javascript/javascript-seo-basics |
| Google metadata | https://developers.google.com/search/docs/crawling-indexing/special-tags |
| Google canonicalization | https://developers.google.com/search/docs/crawling-indexing/consolidate-duplicate-urls |
| Google structured data | https://developers.google.com/search/docs/appearance/structured-data/intro-structured-data |
| Google AI search guidance | https://developers.google.com/search/docs/appearance/ai-features |
| Bing official updates | https://blogs.bing.com/webmaster |
| Bing URL submission | https://www.indexnow.org/documentation |
| OpenAI crawlers | https://platform.openai.com/docs/bots |
| Open Graph protocol | https://ogp.me/ |
| Meta sharing | https://developers.facebook.com/docs/sharing/webmasters/ |
| Meta debugger | https://developers.facebook.com/tools/debug/ |
| LinkedIn inspector | https://www.linkedin.com/post-inspector/ |
| X Cards | https://developer.x.com/en/docs/x-for-websites/cards/overview/abouts-cards |
| Pinterest | https://developers.pinterest.com/ |
| Slack unfurls | https://api.slack.com/reference/messaging/link-unfurling |
| Bluesky external embeds | https://docs.bsky.app/docs/advanced-guides/posts |
| Mastodon | https://docs.joinmastodon.org/ |
| Next.js | https://nextjs.org/docs |
| React | https://react.dev/ |
| WordPress performance | https://developer.wordpress.org/advanced-administration/performance/ |
| Shopify theme performance | https://shopify.dev/docs/storefronts/themes/best-practices/performance |
| Cloudflare caching | https://developers.cloudflare.com/cache/ |
| Public skill discovery | https://github.com/anthropics/skills and https://github.com/openai/skills |

A moved/inaccessible page is an evidence gap: locate its current official replacement rather than silently treating it as verified. Vendor marketing claims require independent measurement. Community posts and public skills provide hypotheses, not authoritative platform specifications.

## Five research loops for future updates

Use a rolling six-calendar-month window with extra attention to the most recent 30-60 days. Record the exact window and timezone. Include older foundational specifications with explicit older-reference labels. Never fabricate publication dates for evergreen docs.

1. **Discovery:** search primary vendor docs, release notes, conference videos, official developer channels, public skills, credible technical blogs, and community failure reports. Build a candidate ledger.
2. **Evidence extraction:** read complete relevant sections; obtain transcripts for videos; capture publication/update/retrieval dates and timestamped claims. Mark video metadata-only or transcript-only review accurately.
3. **Contradiction and gaps:** test claims against current primary docs and installed software versions. Check mobile constraints, field-versus-lab disagreement, bot rendering, cache privacy, metadata platform omissions, and future-effective announcements.
4. **Implementation evaluation:** translate supported findings into decision rules. Test representative fixtures and site journeys. Remove generic or unsupported instructions; document counterexamples and limits.
5. **Skeptic release review:** independently challenge conclusions, verify links and example output, review coverage gaps, and publish with a reproducible evidence table and actual validation record.

For each source record: URL, title, author/vendor, source type, date published/updated, date retrieved, covered period, reviewed sections/timestamps, exact claim, caveat, implementation change, confidence, and corroborating source. Keep direct quotations short and respect licenses when borrowing skill structure or code.

For videos include channel, URL, publication date, transcript availability, reviewed time ranges, and whether visuals were actually inspected. For public skills include commit/version, license, adopted idea, and test result. For Reddit/social threads distinguish anecdotal outcomes from controlled evidence.

## Refresh acceptance

A refresh is complete only when all five loops produce artifacts, citations support their associated claims, unsupported findings are removed or labeled, examples match current APIs, and the platform gap register is updated. Never equate freshness of a search result crawl date with freshness of its underlying advice.
