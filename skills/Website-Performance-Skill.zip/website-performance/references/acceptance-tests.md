# Acceptance tests

## Website test matrix

Record route, browser/device, viewport/DPR, network/CPU profile, login state, consent state, locale, cache state, build commit, timestamp, expected behavior, actual behavior, and evidence path.

- Mobile and desktop cold/warm visits to representative templates.
- Initial source HTML, final response headers, and rendered DOM metadata.
- LCP resource selection, priority, load timing, render delay, and breakpoint variation.
- Keyboard/touch/pointer menu, search, filtering, forms, validation, consent, cart, and checkout.
- Layout stability after loading fonts, images, embeds, banners, and lazy content.
- Reduced motion, zoom, focus visibility, accessible names, and keyboard navigation.
- Login/logout, two users, currencies, locales, query variants, CDN hits/misses, and cache purge.
- Back/forward navigation, offline/service-worker transitions where applicable, and errors.
- Social image fetch without cookies; MIME/dimensions; title/canonical/locale consistency.
- Real previews in prioritized social platforms; explicit untested states elsewhere.
- Production analytics/CMP behavior using controlled test events, without real purchases or false leads.

## Forward-test prompts

Use these as evaluation inputs. Keep scoring criteria separate when providing the prompt to a testing agent.

### Scenario A
A new React dental site has no CrUX data, a hero inserted by JavaScript, a consent manager, a booking embed, and a client request for guaranteed 100 mobile Lighthouse and AI citations. Propose the build/release plan.

### Scenario B
A mobile trace reports LCP 4.2 seconds, of which 3.1 seconds is element render delay. The developer proposes compressing every image and lazy-loading the hero and cart code. Decide what to inspect and change first.

### Scenario C
A multilingual Next.js store has authenticated content, external image delivery, lab score 98, and a reported field INP of 480 ms with no percentile/window information. The proposed fix is cache-everything at the CDN. Plan diagnosis and safe validation.

### Scenario D
A French page canonicalizes to English, has duplicate titles, and exposes OG metadata only after hydration. Its social image is an expiring AVIF response labeled image/jpeg with incorrect dimensions. HTTP headers say noindex while HTML says index. The developer wants to remove all metadata for speed. Produce a prioritized repair plan.

## Scoring criteria

A passing response identifies missing measurement context; avoids guarantees; distinguishes field and lab; diagnoses the dominant bottleneck; preserves consent and transactions; protects cache privacy; checks initial HTML and HTTP headers; validates actual preview images; handles language/canonical relationships; and provides repeatable tests plus rollback.

An automatic failure is claiming completed field validation without data, caching private responses across users, stripping required metadata without justification, fabricating platform tags, or claiming every social platform was tested without evidence.

## Packaging validation

Confirm frontmatter name/description, referenced files, no empty documents, readable UTF-8, and ZIP root structure. Read each archive entry and verify its checksum or successful decompression. Keep packaging checks distinct from live website tests.

This reconstructed package has not been run against a production site. The four scenarios are reusable test fixtures; their presence does not by itself certify a new independent evaluation.
