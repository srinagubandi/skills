# Search, AI, and social metadata

## Route data contract

Define title, description, canonical URL, indexing policy, locale/language, social title/description/image/alt, content type, author/publisher when appropriate, timestamps, and structured data. Keep visible facts and metadata consistent. Use absolute HTTPS URLs for canonical and preview assets. Model multiple images intentionally; avoid conflicting duplicates from templates and plugins.

A starting social image such as 1200 x 630 is a project default, not a universal platform guarantee. Confirm current platform requirements, crop behavior, supported MIME types, file-size limits, and aspect ratios. JPEG/PNG are practical compatibility fallbacks; test modern image formats before using them as the only unfurl asset.

## HTML delivery example

Replace every example value before publishing. Include only facts supported by the page.

```html
<title>Specific page title | Brand</title>
<meta name="description" content="Accurate, page-specific summary.">
<link rel="canonical" href="https://example.com/service/">
<meta name="robots" content="index,follow">
<meta property="og:type" content="website">
<meta property="og:url" content="https://example.com/service/">
<meta property="og:title" content="Specific page title">
<meta property="og:description" content="Accurate sharing summary.">
<meta property="og:site_name" content="Brand">
<meta property="og:locale" content="en_US">
<meta property="og:image" content="https://example.com/social/service.jpg">
<meta property="og:image:type" content="image/jpeg">
<meta property="og:image:width" content="1200">
<meta property="og:image:height" content="630">
<meta property="og:image:alt" content="Meaningful image description">
<meta name="twitter:card" content="summary_large_image">
<meta name="twitter:title" content="Specific page title">
<meta name="twitter:description" content="Accurate sharing summary.">
<meta name="twitter:image" content="https://example.com/social/service.jpg">
<meta name="twitter:image:alt" content="Meaningful image description">
```

Use name for Twitter Card metadata and property for Open Graph. Do not invent account handles. Add appropriate article/product properties only when supported and truthful. Ensure declared image dimensions and MIME match the delivered file. Check redirects and final Content-Type, not only the filename.

## Coverage matrix

This matrix defines audit scope; it does not claim a live test of every platform or a universal tag contract. Revalidate documentation and record actual preview evidence per destination.

| Destination | Website metadata or mechanism | Required validation |
|---|---|---|
| Facebook / Messenger | Open Graph; platform fetch and preview cache | Sharing Debugger where accessible; crawlable page/image, crop, cache refresh |
| Instagram | External link surfaces differ from native feed/Reels | Test the actual link-sharing surface; website OG does not populate native post captions or media |
| Threads | Link previews may derive from page metadata | Test actual post surface; do not invent Threads-only HTML tags |
| WhatsApp | Link unfurl behavior depends on client/context | Test real clients and message contexts; avoid guaranteeing full OG field display |
| LinkedIn | Page metadata/Open Graph and cached previews | Post Inspector, actual post, final URL, image availability |
| X | Twitter Card tags plus documented fallbacks | Check current Card documentation, actual card, image access, account fields |
| Pinterest | Pin/Rich Pin mechanisms depend on content type | Verify current article/product/recipe requirements, visible content consistency, image eligibility |
| Bluesky | External embeds include title, description, thumbnail in record/client workflow | Inspect actual external card; do not assume a website tag alone creates every embed |
| Mastodon / fediverse | Instance-specific preview/oEmbed behavior | Test target instances; optional author attribution must follow actual supported specifications |
| Reddit | Submission/client-specific preview extraction | Test link post; do not invent Reddit-specific meta names |
| Discord | Unfurl uses fetched page/embed data | Test public channel or controlled test, image crop, cache, crawler accessibility |
| Slack | Classic unfurls versus app-provided unfurls | Test pasted link in intended workspace; app unfurls can override website metadata |
| Telegram | Preview fetching/caching/client behavior | Test actual client, page/image fetch, refresh limitations |
| iMessage / Apple link previews | Link presentation from fetched content | Test Apple devices; verify accessible images and fallback titles |
| Microsoft Teams | Link preview and app integration vary | Test target tenant/client; no universal Teams-specific website tag promise |
| YouTube | Native video metadata is separate | Validate upload title, description, thumbnail, captions; VideoObject applies to appropriate web video pages |
| TikTok | Native upload/profile/link surfaces are separate | Validate native video fields and actual link surface; no invented TikTok HTML tags |
| Snapchat | Native content/deep-link/preview behavior varies | Test intended share workflow; no invented universal tags |
| Google Search | title, description, canonical, robots, hreflang, structured data | Search Console URL Inspection and supported rich-result validators |
| Bing Search | same foundational crawl/index signals plus current Bing guidance | Webmaster Tools inspection, robots/header behavior, IndexNow only for eligible URL updates |
| AI search / assistants | accessible text, supported crawler policy, search indexing | Separate search access, user-initiated fetch, and training policies; no promise of citation |

For other platforms, add a row identifying the actual surface, documented extraction mechanism, source URL/date, and observed result. Mark unknown behavior rather than extrapolating from one platform.

## Crawl and preview debugging

1. Fetch the final URL without authentication. Record status, redirect chain, response headers, robots.txt, canonical, and initial HTML.
2. Inspect rendered DOM separately. Metadata present only after hydration may be invisible to unfurlers. Confirm framework metadata streaming behavior for relevant bots against installed-version docs.
3. Fetch each image directly with no cookies. Check final status, MIME, actual bytes, dimensions, redirects, signed-URL expiry, hotlink protection, WAF, and CDN cache.
4. Compare normal and documented crawler requests where permitted. User-agent impersonation is a diagnostic, not proof of genuine platform access; confirm with platform tools/logs.
5. Check protocol, www/non-www, trailing slash, case, query variants, localization, pagination, and redirect destinations. Avoid redirect loops and canonical chains.
6. Re-scrape using supported platform tools. Do not assume changing HTML purges a platform preview cache. If using versioned image URLs, ensure URLs remain stable and publicly retrievable.
7. Save preview evidence and timestamp, noting truncation/crop rather than expecting identical output everywhere.

## Indexing and localization

Check meta robots together with X-Robots-Tag headers; conflicting directives can prevent indexing. Blocking crawling with robots.txt can prevent a crawler from seeing noindex. Do not use robots.txt to protect private content; use authentication.

Use correct page language, canonical, and reciprocal hreflang relationships for real localized equivalents. Open Graph locale uses a different formatting convention than hreflang. Do not canonicalize every language to English by default. Preserve UTM handling, pagination semantics, and genuine product-variant differences.

Structured data must describe visible, accurate content and use supported types. Do not invent ratings, awards, reviews, credentials, prices, medical claims, or availability. Schema validity does not guarantee a rich result. Keep JSON-LD lean and deduplicated without deleting relevant entities blindly.

## AI controls and misinformation guardrails

Check current official crawler documentation by provider. Distinguish OpenAI search bots, training bots, and user-initiated agents rather than treating all AI requests as one crawler. Apply the same distinction to other vendors using their documented controls. Do not promise that robots directives revoke previously collected data.

Treat llms.txt as an experimental convention unless a specific provider documents support; it is not a substitute for crawlable content, sitemaps, or robots policies. Verify announcement date versus effective date before applying new search/AI controls. Do not label announced future rules as active.

## Gap register

For every uncovered item record platform/surface, missing field, business impact, documented versus observed behavior, exact evidence, proposed repair, owner, and next test. Explicitly include inaccessible documentation and login-limited tools. All-platform coverage means a scoped inventory and honest unknowns, not claiming unsupported certainty.
