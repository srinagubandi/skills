# Performance diagnostics and implementation

## LCP decision tree

1. Identify the LCP element in a trace for each relevant viewport. Check whether it is text, an image, video poster, or CSS background.
2. If TTFB dominates, inspect redirects, DNS/TLS, cache misses, backend/database time, origin geography, and server capacity. Use Server-Timing where available. Compare CDN hit/miss, authenticated/anonymous, and geographic segments.
3. If resource load delay dominates, expose the resource in initial HTML. Avoid JS-only insertion, lazy-loading the likely LCP image, or discovering it only after a stylesheet downloads. Consider a correctly targeted preload for an otherwise late-discovered critical resource.
4. If transfer duration dominates, optimize dimensions, compression, responsive selection, format, and CDN delivery. Inspect selected currentSrc at real device pixel ratios. A large source served into a tiny viewport is wasteful.
5. If render delay dominates, inspect render-blocking CSS, web fonts, main-thread work, hydration, opacity animations, hidden slides, and content gates. Smaller image bytes alone will not fix a long hidden-element delay.

Use fetchpriority="high" selectively on the likely LCP image. Do not set every image high. Do not lazy-load above-the-fold critical content. Use loading="lazy" for genuinely offscreen images and embeds, with width/height or aspect-ratio. Validate that responsive preload imagesrcset/imagesizes match actual image selection, otherwise duplicate downloads can result.

## INP and JavaScript

Capture realistic interactions and inspect long tasks and forced synchronous layout. Reduce work before adding scheduling workarounds. Remove unused dependencies and duplicate SDKs, split by route/feature, avoid expensive rendering in event handlers, and reduce unnecessary React updates. Break long tasks using supported scheduling APIs; feature-detect and provide a fallback. A Promise microtask alone does not yield to rendering. Move suitable CPU work to a worker, accounting for transfer overhead and DOM access limitations.

Avoid replacing every event listener with passive listeners; handlers that must cancel default behavior need appropriate handling. Avoid delaying all scripts until the first user interaction, which can create a large first-interaction stall. Test typing, pointer, touch, and keyboard paths on constrained devices.

## CLS and fonts

Reserve space for images, embeds, ads, consent UI, banners, and async recommendations. Preserve viewport position when content loads. Inspect font swaps, fallback metrics, late CSS, image intrinsic dimensions, and layout-changing animation. Prefer transform/opacity animation where appropriate but still measure paint/compositing cost. Respect reduced motion.

Use WOFF2 where appropriate, subset only with language coverage verified, minimize variants, and preload only essential faces. Confirm CORS and crossorigin behavior on font preloads. Evaluate font-display and fallback metric overrides against visible behavior. A tiny Latin subset that drops required language glyphs is not an optimization success.

## Network and caching

Version immutable static assets and give them long-lived caching. Use an intentional HTML freshness and invalidation policy. Validate Cache-Control, CDN overrides, Vary, ETag, compression, and redirects. Check actual compressed bytes and prevent duplicate compression.

Never cache authenticated HTML, account data, carts, CSRF tokens, or personalized responses across users. Test cookie, authorization, language, currency, device, and query-key behavior. Do not drop cache-key parameters until proving they do not affect content. Stale-while-revalidate is a consistency choice, not universally safe. Prevent private API responses from entering service-worker caches.

Test back/forward navigation and bfcache eligibility. Check service-worker version upgrades, stale assets, offline fallbacks, and rollback interaction. Measure preconnect hints; too many consume connection resources. Prefetch and prerender only suitable routes, account for consent and side effects, and never speculate transactional GET requests that incorrectly mutate state.

## Third parties and consent

Inventory initiator, bytes, CPU, connection count, purpose, owner, consent category, and revenue dependency. Load below-the-fold embeds on demand using accessible facades. Coordinate CMP and tag-manager changes so consent state is honored on every navigation. Verify deduplication, form events, conversion events, and navigation tracking. Test accept, reject, no response, and changed consent. Do not send a production conversion during a test without a documented test method.

Use progressive enhancement for scheduling and chat. Retain a fallback link or contact method if an embed fails. Record attribution and conversion changes separately from performance changes.

## Stack-specific checks

| Stack | High-value checks | Common regression |
|---|---|---|
| HTML/static | critical CSS, image discovery, fonts, caching, shared includes | stale HTML pointing to removed assets |
| React SPA | route splitting, hydration alternative, expensive rerenders, initial HTML | blank content and metadata for crawlers |
| Next.js | installed-version image and metadata APIs, server/client boundaries, streaming, cache invalidation | user data cached across requests; unsupported config copied from another version |
| WordPress | theme/plugin duplication, page cache exclusions, image sizing, database queries, cron, builder CSS | broken checkout/admin, duplicate SEO metadata, cache serving logged-in content |
| Shopify | theme/app scripts, Liquid image filters, sections, cart and variant logic, app embeds | deferred scripts breaking variant selection, cart, pixels, or accelerated checkout |
| CDN/server | cache keys, compression, purge strategy, edge redirects, TLS, origin latency | private content leakage or stale pricing |

For any framework, consult current official documentation for the installed version before editing. Do not assume an API is stable because a blog used it six months earlier.

## Budgets and release

Set measurable project budgets with route ownership. Include compressed initial JS/CSS, image bytes/pixels, font requests, third-party CPU, lab LCP/CLS/TBT, and field CWV. Explain tradeoffs rather than imposing arbitrary universal byte limits.

Measure multiple cold and warm runs. Keep production builds, browser versions, throttling profiles, test geography, consent, login state, and content comparable. Track p75 field metrics with sample size and segments, plus business errors/conversion guardrails. Stop or roll back if a critical journey, privacy boundary, or accessibility requirement fails even when lab scores improve.
