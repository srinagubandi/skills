---
name: website-performance
description: Audit and improve website page speed, Core Web Vitals, crawlable metadata, and social link previews for new and existing websites. Use for performance planning, slow-page diagnosis, launch checks, regressions, and metadata repair on HTML, React, Next.js, WordPress, and Shopify sites. Preserve accessibility, consent, analytics, forms, and commerce behavior.
---

# Website performance

## Operating contract

Optimize real user outcomes and critical journeys. Do not promise a Lighthouse score of 100, instant rankings, AI citations, or a field-metric pass from a single lab run. Do not remove useful content, accessible controls, consent requirements, or business-critical scripts merely to improve a score.

Read [diagnostics.md](references/diagnostics.md) for performance implementation, [metadata.md](references/metadata.md) for platform coverage and metadata validation, and [sources-and-refresh.md](references/sources-and-refresh.md) before making time-sensitive claims. Use [acceptance-tests.md](references/acceptance-tests.md) for release validation.

## Intake

Ask the highest-impact missing question first; proceed with independent inspection while waiting. Establish:

- New build or existing website; production and preview URLs; repository; stack/version; hosting/CDN.
- Revenue or conversion journeys, audiences, major devices, countries, languages, accessibility needs.
- Existing CrUX, Search Console, RUM, analytics, performance budgets, and incident history.
- Required third parties: consent manager, CRM, forms, call tracking, chat, scheduling, pixels, payment widgets.
- Priority sharing destinations and content types. A link preview is different from a native social post.
- Deployment authority, rollback method, and baseline commit. Avoid unnecessary credentials or private customer data.

Inventory representative routes: homepage, landing page, product/service, category/search, article, location, contact, account/cart/checkout when applicable. Include the highest-traffic route and the slowest template. Record actual templates, not only URLs.

## Five-pass execution

Use five explicit passes. Each must record evidence, a finding, a concrete change or rejected hypothesis, and a verification result. Five headings without new investigation do not constitute five passes.

1. **Baseline and research:** inspect architecture, field/lab evidence, waterfall, source HTML, headers, third parties, current official guidance. Separate recent announcements from established reference material.
2. **Build or repair:** address the highest-impact measured bottleneck. Implement the metadata data model and initial HTML delivery. Keep changes small enough to attribute results.
3. **Adversarial review:** challenge cache safety, localization, consent, hydration, image priorities, crawler behavior, false score improvements, and broken critical journeys.
4. **Cross-platform verification:** test mobile/desktop, cold/warm cache, content variants, sharing previews, accessibility, errors, slow networks, and key interactions.
5. **Release and observation:** compare repeatable lab results, release with rollback, monitor RUM and business metrics, and schedule field re-evaluation. Do not report field improvement before fresh field observations exist.

## New website path

Choose architecture by actual requirements. Prefer server-delivered HTML or static generation for public content where practical. Budget route JavaScript and third-party cost before selecting animation libraries or embedding video. Render main content without requiring a client-only fetch. Keep genuinely interactive islands small; do not hydrate the entire page for a menu.

Define provisional budgets per template, device/network profile, and market. Label byte/request budgets as project choices, not universal Google rules. Include actual transferred versus uncompressed bytes, image pixels, font variants, execution time, and critical requests. Test a realistic content-heavy route before cloning the template across the site.

Provide a performant no-JavaScript content baseline where feasible, then enhance interactions. Generate route-specific metadata from the same source of truth as visible content. Reserve stable layout space for images, banners, advertisements, embeds, and async UI. Design an explicit poster and playback policy for hero video.

## Existing website path

Capture baseline commit, headers, waterfalls, traces, screenshots, and critical journey behavior before modifying. Segment poor field performance by template, device, geography, browser, and release. Prioritize impact x frequency x confidence, balanced against regression risk and implementation effort. Do not replace an entire stack before demonstrating that architecture is the limiting factor.

Make one coherent change set at a time. Retest the same routes, content, location, throttling, cache, and consent state. Record medians and spread across repeated runs, not the best run. Maintain a rollback and compare conversions, errors, accessibility, and cache behavior alongside speed.

## Measurement and diagnosis

Use LCP <= 2.5 seconds, INP <= 200 milliseconds, and CLS <= 0.1 as good Core Web Vitals thresholds, assessed at the 75th percentile in field data. Separate mobile and desktop populations. State URL-level versus origin-level data, sample/window, and missing coverage. CrUX's rolling aggregation is not an immediate deployment measurement.

Use lab tests to reproduce bottlenecks. Lighthouse TBT is a diagnostic and is not a substitute for real INP. Missing CrUX data means insufficient evidence, not a passing site. Capture navigation and interactions: menu, accordion, carousel, filter, search, consent action, form validation, cart changes, and checkout initiation.

Break LCP into TTFB, resource load delay, resource load duration, and element render delay. Inspect the actual LCP element; it may change by breakpoint, consent state, personalization, or language. Break slow interactions into input delay, processing, and presentation. Diagnose CLS using shift clusters, including shifts after scrolling and interactions.

Follow evidence in the linked diagnostics reference. Do not blanket-preload, blanket-lazy-load, or use cache-everything without examining correctness.

## Metadata integration

Treat metadata as a route-level product contract. Validate final HTTP status, response headers, source HTML, rendered DOM, canonical destination, image response, and real preview behavior. Search crawlers and social unfurlers have different rendering capabilities; do not assume they all run JavaScript.

Use one owner for each metadata family. Eliminate duplicate titles, canonicals, robots tags, Open Graph tags, and conflicting plugins. Resolve redirects, localization, pagination, product variants, and consent behavior deliberately. Never strip metadata as a speed optimization without measuring its cost and preserving required semantics.

Do not assert that every platform has a unique HTML tag. Maintain an explicit coverage matrix with verified, inferred, unsupported, inaccessible, and needs-live-test statuses. Read the metadata reference for platform-specific distinctions.

## Output and handoff

Provide a concise outcome followed by:

- Scope, tested routes, environment, timestamp, baseline/release commits, and evidence paths.
- Prioritized findings: symptom, measured cause, fix, expected benefit, risk, owner, verification.
- Before/after lab measurements with identical conditions and variability; field results separately.
- Metadata inventory with exact route, expected value, actual value, delivery layer, platform, and status.
- Completed versus unverified checks, rollback procedure, and remaining monitoring work.

Never claim a deployment, install, upload, passing test, watched video, or completed research loop without evidence. Do not confuse structural validation of this skill with validation of a production website.
